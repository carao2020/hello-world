IBM WebSphere Transformation Extender 
Command Server Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the command server. You will
use the command server to execute a map. A command-driven server is a 
server that processes data manually.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

cmndsrvr.mms:   This map source file will be built to create the 
                cmndsrvr.mmc executable map file. It is executed in 
                the cmndsrvr.msd system definition file. It reads the 
                employee.txt file, whose structure is defined by the 
                cmndsrvr type tree, and uses the employee first and 
                last name contained in it to match against the 
                employee first and last name listed in the 
                allemps.txt file. When it finds the match, it 
                extracts the related timesheet data and writes it to 
                the output emphours.txt file along with the first and 
                last name.

cmndsrvr.msd:   This system definition file executes the cmndsrvr 
                map, which performs the entire match/extract process.

allemps.txt:    This text file contains detailed timesheet 
                information for all employees. It is used to extract 
                the timesheet details for the employee in the 
                employee.txt file.

employee.txt:   This text file contains the employee first and last
                name to which to match in the allemps.txt file.

cmndsrvr.mtt:   This type tree describes the structure of the input 
                and output files.

readme.txt:     This file

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example will use these sample files to support the following 
example scenario:

The command server will be used to execute the cmndsrvr.mmc compiled 
map by using a command file. When the command server is called with 
the command file, it will execute the cmndsrvr.mmc compiled map, 
which will access the employee.txt file located in the input 
subdirectory. You may have to first create the input subdirectory,if 
it doesn't already exist, and then place a copy of the employee.txt 
in it. See step 5) below.

The employee first name and last name in the employee.txt file is 
used to match to the same employee first name and last name in the 
allemps.txt file. When the match is found, it will extract the 
employee's timesheet data from the allemps.txt file for that same 
employee in the employee.txt file. It will write the employee's name 
and the total number of hours that the employee worked for the week 
to the emphours.txt file located in the output subdirectory. You may 
have to first create the output subdirectory, if it doesn't already
exist.

How to run the example:

Scenario - Retrieve timesheet information for a specific employee.

1)  From the Integration Flow Designer (IFD), open the cmndsrvr.msd
    system file.

2)  Select Command as the Execution Mode to indicate the system will 
    run on the Command Server and generate a text command file.

3)  Build the cmndsrvr map to create the cmndsrvr.mmc compiled map 
    using the IFD by selecting System > Build Maps.
    
    Note:  You may have to edit the Map Source File value in the 
           cmndsrvr Map Component to match the path in which the 
           cmndsrvr map source file resides.

4)  Deploy the cmndsrvr map in the IFD by selecting System > Deploy >
    cmndsrvr. 
    
    Note:  You may need to edit the Deploy Script to specify the 
           command file name and server path to which you want the 
           command file to be generated and transferred. 

    The IFD will create a text command file with the name you 
    specified in the Deploy Script. As an example, you can specify
    the name cmndsrvr.txt. This is the Command Server system 
    file used for controlling the compiled cmndsrvr.mmc map and 
    processing the data files. This file will be placed in the 
    default directory where you last created a .msl file.

5)  Place a copy of the employee.txt file into the input subdirectory.
   
    Note: You may first have to create the input subdirectory.
   
    Warning: Make sure you only use a copy of the file because the 
             input card is set to delete the inbound data file as 
             soon as it is done processing the file.

5)  Call the command file from the command line.
    
    Note: You may first have to create the output subdirectory before
          calling the command file. 

    An example command line command is:  dtxcmdsv @cmndsrvr.txt
    
    Note: When you are at the command prompt, before you issue the 
          command, be sure that you:
          - are positioned at the directory in which the command 
            file resides
          - have run the setup script to properly set up the command 
            server environment

6)  Expect to get the following output data in the emphours.txt file 
    located in the output subdirectory: 
    Work A.             |Holic               |90.45
   
7)  Do additional tests to verify that the system extracts the 
    specified employee by modifying the employee first and last name 
    in the employee.txt file with other employee names from the 
    allemps.txt file. Run the system again and verify that the 
    output emphours.txt file contains the correct timesheet data for 
    the specified employee.

For detailed information about using the Command Server and the IFD, 
see the Command Server and the Integration Flow Designer 
documentation.


=====================================================================
                             END OF FILE
=====================================================================
