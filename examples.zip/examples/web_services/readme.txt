IBM WebSphere Transformation Extender 
Web Services Examples Readme


(c) Copyright International Business Machines Corporation 2006.
All Rights Reserved.


These examples demonstrate the usage of Web Services sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using These Examples


=====================================================================
1: EXAMPLE FILES
=====================================================================

The folder for Web Services examples, located under 
install_dir\examples, contains sample files to be used with Web 
Services components. This includes the WSDL Importer, SOAP and HTTP 
adapters, Launcher Agent, and the Launcher, to implement web services 
strategies.

There are three examples:

    1.  Provider - This example demonstrates how to provide a web
        service using an existing map and exposing it as a web
        service through a wrapper map.

        Two services are provided. They are as follows:

        Contact: Looking up and returning company contact
        information.

        Search: Looking up and returning personal contact
        information.

    2.  Secure Provider - This example is the same as the Provider
        example except that it uses the SSL Security Option to
        connect to a secure URL (HTTPS). Note that the 
        SSL Security Option is required to run the Secure Provider
        example. See the Intelligent Business Integration 
        documentation for more information about the security option.

    3.  Consumer - This example demonstrates how to consume a web
        service defined in WSDL using a map to invoke the service.

        The following service is consumed:

        Calculation: Performing calculation functions such as adding,
        subtracting, multiplying, and dividing.


Files included in these examples:


client.mms:             This map is used to imitate a client request
                        which invokes a web service. SOAP messages
                        are sent and received using the the HTTP
                        adapter as the transporter.

                        To run the Secure Provider example, use the
                        RunHttpsSearch.mmc map. This map invokes the
                        HTTPS protocol.

Consumer_example.mms:   This map is used to invoke the web service
                        defined in Calculator.wsdl. It uses the SOAP
                        and HTTP adapters.

                        The returns_scalar.mmc map is used to isolate
                        a scalar value from data returned from a web
                        service by using the -RETURN SOAP adapter
                        command. The GET() function is implemented to
                        execute the SOAP adapter to parse a request 
                        as a text string and receive a result from 
                        the Web service.

                        The returns_raw_scalar.mmc map is used to
                        isolate a scalar value from data returned 
                        from a web service by using a combination of 
                        the -RAW and the -RETURN SOAP adapter 
                        commands. The GET()function is implemented to 
                        execute the SOAP adapter to parse a request 
                        as a text string and receive a result from 
                        the web service.

                        The return_nonscalar.mmc map is used to
                        demonstrate how a map could be used to parse 
                        data returned by a web service using the -RAW 
                        SOAP adapter command. The RUN() function is 
                        implemented to invoke the ParseResult.mmc map 
                        which parses the result from the web service.

router.mms:             This map runs the requested Web Service map
                        using the ECHOIN function to send the input
                        data to the map and route the output data 
                        back to the client.

                        The RunResult.mmc map recognizes the success
                        or failure of the Web Service map execution
                        and runs  either the Success.mmc or
                        Failure.mmc map.

                        If the Web Service map execution is
                        successful, then the Success.mmc map
                        generates a SOAP response message which is
                        echoed to the Router.mmc map.

                        If the Web Service map execution fails, then
                        the Failure.mmc map generates a SOAPFault
                        message which is echoed to the Router.mmc
                        map.

services.mms:           This map contains the two web services. The
                        Contact.mmc and Search.mmc maps are invoked 
                        as web services providing contact lookup
                        functionality. 

Router.msd:             This .msd file is used to listen for incoming 
                        SOAP messages from a specified URL and run 
                        the router.mmc map.

Calculator.mtt:         This type tree describes the structure of
                        Calculator.wsdl used in this example and was
                        generated using the WSDL Importer. Note that
                        the variable SOAPSDK1 is currently specified 
                        as a namespace prefix in the initiator for 
                        the Calc.Add, Calc.AddResponse, and MsgXmlns 
                        Message Attribute.

Contact.mtt:            This type tree describes the input data for
                        the Contact.mmc map.

Http.mtt:               This type tree describes the input and output
                        data for the Web services.

Label.mtt:              This type tree describes the output data for
                        the Contact.mmc and Search.mmc Web Service 
                        maps.

Preferred.mtt:          This type tree describes the input data for
                        the Contact.mmc Web Service map.

Provider.mtt:           This type tree describes the structure of
                        Provider.wsdl used in this example and was
                        generated using the WSDL Importer.

SoapFault.mtt:          This type tree describes the SOAP adapter
                        failure message.

text.mtt:               This type tree is used to read or write a
                        text string in this example.

Contact.txt:            This is the input file for the Search.mmc
                        map.

FirstName.txt:          This is the input file for the Search.mmc
                        map.

FullContact.txt:        This is the input file for the Search.mmc
                        map.

LastName.txt:           This is the input file for the Search.mmc
                        map.

lookup.txt:             This is the input file for the Contact.mmc
                        map

Calculator.wsdl:        This Web Services Description Language file
                        defines the web service.

Provider.wsdl:          This Web Services Description Language file
                        defines the web service that invokes the
                        router.mms file, which is the wrapper for the
                        three provided web services.
                        
readme.txt:             This example readme text file.



=====================================================================
2: USING THESE EXAMPLES
=====================================================================

Scenario 1: Providing a web service.

    1)  Open the Router.msd file in the Integration Flow
        Designer.

    2)  Build and analyze the Router.msd system.

    3)  Generate the ProviderHTTP.msl file.

    4)  Deploy the ProviderHTTP.msl file to the install_dir\systems
        directory.

    5)  Start the Launcher Agent.

    6)  Start the Launcher as a service.

    7)  Open the router.mms file in the Map Designer.

    8)  Build the Router.mmc, RunResults.mmc, Success.mmc and
        Failure.mmc maps.

    9)  Open the services.mms file in the Map Designer.

   10)  Build the Contact.mmc, and Search.mmc maps.

   11)  Open the client.mms file in the Map Designer.

   12)  Run either the RunHttpSearch, or RunContact map
        to implement the corresponding Web Service map.  Edit the
        address specified for HTTP adapter -URL command, if
        necessary. Build the map and then run it.

   13)  Monitor the Web Service and router maps being executed
        through the Launcher Agent or Launcher monitor.

   14)  Check the maps' execution logs and traces, the adapters' logs
        and traces, and the reply data in the result.txt file.

Scenario 2: Providing a web service using HTTPS.

   *The SSL Security Option in IBM WebSphere Transformation Extender 
    Security Collection must be installed and an SSL environment must 
    be implemented on your server to run this example. 


    1)  Open the Router.msd file in the Integration Flow
        Designer.

    2)  Build and analyze the Router.msd system.

    3)  Generate the ProviderSSL.msl file.

    4)  Deploy the ProviderSSL.msl file to the install_dir\systems
        directory.

    5)  Start the Launcher Agent. Note that the Launcher Agent
        must be configured for SSL.

    6)  Start the Launcher as a service.

    7)  Open the router.mms file in the Map Designer.

    8)  Build the Router.mmc, RunResults.mmc, Success.mmc and
        Failure.mmc maps.

    9)  Open the services.mms file in the Map Designer.

   10)  Build the Search.mmc map.

   11)  Open the client.mms file in the Map Designer.

   12)  Run the RunHttpsSearch map to implement the Search Web
        Service map. Edit the address specified for HTTP adapter -URL
        command, if necessary. Build the map and then run it.

   13)  Monitor the maps being executed through the Launcher Agent or
        Launcher monitor.

   14)  Check the maps' execution logs and traces, the adapters' logs
        and traces, and the reply data in the result.txt file.

Scenario 3: Consuming a web service.

    1)  Open the Consumer_example.mms file in the Map
        Designer.

    2)  Choose a map to build and then run it. Note, to run the
        returns_nonscalar map, build the ParceResult.mmc map first.

    3)  Check the map's execution log and trace, the adapters' logs
        and traces, and the reply data in the Result_out.xml file.


=====================================================================
                             END OF FILE
=====================================================================