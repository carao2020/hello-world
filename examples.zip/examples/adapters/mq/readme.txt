IBM WebSphere Transformation Extender 
IBM WebSphere MQ Adapter Example Readme


� Copyright International Business Machines Corporation 2006, 2010.
All Rights Reserved.


This example demonstrates the usage of the IBM WebSphere MQ Adapter 
sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    input_msg_hdr.in          - data-driven input file
    msg_hdr_info.out          - output file
    mq.mms                    - map source file
    mq.mrc                    - resource configuration file
    mq.mtt                    - type tree file
    mq_config.mrn             - resource name file
    readme.txt                - this readme file
    text_record.mtt           - type tree file 


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example places eight messages on a queue, and retrieves three 
messages from the queue based on the criteria of the input MQ 
command line adapter. After the example runs, five messages remain 
on the queue and an output file is generated.


mq.mtt type tree
================

The maps in this example use the mq.mtt type tree. It describes 
the format of the input_msg_hdr.in data file for input, and the 
header information for output.

The mq.mtt type tree is arranged so that you can integrate the
definitions provided with any message data you want to define. It
provides types describing different MQSeries message formats so that
you can select the message types needed for input or output, or
the descriptor that you need to include with any message data you
want.

You can select one of the message types as input or output, or add a 
message content type as a MessageData component. The type tree is 
arranged so that you can integrate the definitions provided with any 
message data you want to define.

This type tree has definitions for the following types:

     - MQSeries Header MessageDescriptor 
       - The MessageDescriptor Header type defines the components 
         and format of the message descriptor. 
       - Use this for z/OS Batch or MQSeries.

     - MQSeries Header MessageDescriptor2 
       - The MessageDescriptor2 Header type defines the components 
         and format of the message descriptor for IBM MQSeries.


Mapping using the mq.mms map source file
========================================

The mq.mms map source file contains the following maps:
  - mq_put
  - mq_get

The mq_put map is data-driven. It uses the input_msg_hdr.in input 
file, which will be mapped to the output file of mq_put that uses
the Descriptor2 group within the mq.mtt type tree. The mq_put map
will place the eight messages from the output file on a queue with 
the mapped header information. 

The mq_get map retrieves three messages from the queue based on the 
group ID (-GRP) on the MQ adapter command line. Five messages will
remain on the queue. The mq_get map, which uses the text_record.mtt 
type tree, creates the msg_hdr_info.out output file with three 
records containing the MessageData, MsgSeqNumber, and MsgFlags items.


How to run the example
======================

To run the example, do the following steps:

1. Using the IBM WebSphere MQ Explorer, create a queue manager with 
   the name "Test" and a queue with the name "test".
   To use different queue manager and queue names, change the names 
   specified in the mq_config.mrn file that is included in this 
   example.
2. In the Resource Registry graphical user interface (GUI), overwrite
   the Global Resource File path that is specified in the mq.mrc 
   configuration file to the same location in which the 
   mq_config.mrn file is located.   
3. Analyze the mq.mtt and text_record.mtt type tree files using the 
   Structure and Logic option.
4. Build and run the mq_put map.
5. Build and run the mq_get map.
6. Verify that the three messages appear in the msg_hdr_info.out 
   file.



=====================================================================
                             END OF FILE
=====================================================================
