/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
package com.ibm.websphere.dtx.m4jaxb.test;

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.tools.MObjectPool;

public class RunSample {

	
	public void run(String path) {
			
		try
		{		
			MMap map = new MMap(path);
			
			MCard card = map.getInputCardObject(1);
	        
	        	MAdapter adapter = card.getAdapter();	        
	                    
		        Sample sample = new Sample();
		        sample.setId(5678);
		        sample.setAge(15);
		        sample.setName("JOE");
	        
		        /* the map instance number should be unique for thread safety */
		        int uniqueInstanceNumber = MMap.getUniqueMapInstance();
		        map.setIntegerProperty( MConstants.MPIP_MAP_INSTANCE, 0, uniqueInstanceNumber );
		        
		        String key = MObjectPool.getInstance().generateNewReferenceValue(sample);
		        
		        MObjectPool.getInstance().storeObjectToThePool(uniqueInstanceNumber, key, sample);
		        
		        adapter.setTextProperty(MConstants.MPIP_ADAPTER_COMMANDLINE, 0, "-C com.ibm.websphere.dtx.m4jaxb.test.Sample -ID " + key);	   	                 
	            
			map.run();	
			
			/* we need to remove the object from the object pool */
			MObjectPool.getInstance().removeObjectFromThePool(uniqueInstanceNumber, key);
			
			
			int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
	        	String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
	        	System.out.println("Map status: " + szMsg + " (" + iRC + ")");
			map.unload();	
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {		
		new RunSample().run("jaxb_xml.mmc");
	}

}
