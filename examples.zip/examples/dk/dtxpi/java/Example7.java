/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MStream;

public class Example7
{
    public static void main(String[] args)
    {
        try
        {
            // Initialize the API
            MMap.initializeAPI(null);

            // Load a map 
            MMap map = new MMap("test7.mmc");

            // Get an adapter object
            MCard card = map.getInputCardObject(1);
            MAdapter adapter = card.getAdapter();

            // Get the adapter command line in raw format
            System.out.println( "The adapter command line is....\n" +
                                adapter.getTextProperty( MConstants.MPIP_ADAPTER_COMMANDLINE, 0 ) +
                                "\n");

            // Get it in XML format 
            int[] properties = new int[]{ MConstants.MPIP_ADAPTER_COMMANDLINE };
            String xml = adapter.getPropertiesXML( properties, 0, properties.length );
            System.out.println("The adapter command line in XML is....\n" + xml + "\n");

            // Modify the command line using XML
            xml = "<Adapter>" +
                  "<CommandLine id=\"" + MConstants.MPIP_ADAPTER_COMMANDLINE + "\" type=\"text\">" +
                  "input2.txt" +
                  "</CommandLine>" +
                  "</Adapter>";
            adapter.setPropertiesXML( xml );

            // Print all of the Adapter's properties in XML format
            String xmlProps = adapter.getAllPropertiesXML(false);
            System.out.println("The modified, complete set of adapter properties is....\n" + xmlProps + "\n");

            // Clean up
            map.unload();
            MMap.terminateAPI();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
