IBM WebSphere Transformation Extender 
Programming Interface for Java Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


These examples demonstrate the usage of IBM WebSphere Transformation 
Extender Programming Interface for Java and how it loads, runs and 
controls maps.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using These Examples


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in these examples:

Example1.java - Simplest Case of Running a Map

Example2.java - Running Multiple Instances of a Map in Parallel

Example3.java - Overriding a Card in a Map and CodePageFallback property

Example4.java - Using a User-provided Status Method
Callback.java

Example5.java - Using Streams to Override Inputs and Outputs

Example6.java - Loading a map from a byte array

Example7.java - Getting and setting Properties

Example8.java - Using the Object Pool
AnObject.java

Example9.java - Persist objects in the Object Pool and un-persist
                them.
CounterObject.java

Example10.java - Simplest Case of Running Maps 
                 with a WTX logging callback registration

setenv.bat    - Sets the class path so that the examples can be run

make.bat     -  File to build executables

    Note: Example3.java is written to be used with the GZIP adapter, 
          which is not available on all platforms. If necessary, 
          override the GZIP adapter type in this example with a 
          substitute adapter to correctly run the example.


=====================================================================
2: USING THESE EXAMPLES
=====================================================================

These examples contain sample files to use the IBM WebSphere 
Transformation Extender Programming Interface for Java to run and 
control maps. All source code, maps, and supporting files are 
provided in this example.


To build and run the examples, follow these steps:

1) Compile the Java files.

   Open the batch file "make.bat" and  set
   JDKHOME variable.

   For Windows, from a DOS command prompt, compile
   the java files by executing:

   	make.bat
   	
2) Ensure that the WebSphere Transformation Extender directory is 
   in the path.

3) Set environment variable.

   From a DOS command prompt, set the environment by executing:

        setenv.bat


4) Using the Map Designer, open

   <install_dir>\examples\dk\dtxtpi\dtxpiex.mms

   and build the following maps:

    test1.mmc
    test2.mmc
    test3.mmc
    test4.mmc
    test5.mmc
    test6.mmc
    test7.mmc
    test8.mmc
    test9.mmc

   Note: Ensure that you build the maps for the specific platform on
         which you will be running them.

5) Place the compiled map files in the same directory as the example
   program executables.

6) Copy input.txt, input.gz, and input2.txt to the same directory.

7) Execute the examples.


=====================================================================
                             END OF FILE
=====================================================================
