IBM WebSphere Transformation Extender 
States Map Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the States Map.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

            output.txt
            readme.txt  (this readme file)
            states.mms
            states.mtt
            sts.txt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example maps data that contains statistics on US states and 
rearranges selected pieces of information in the output. 

The map rule on the output StatePop(s) references a functional map, 
MapState. The two arguments to this map are the StateID and the 
Population. The second argument to the functional map is Population 
which is optional. If Population does not exist in the input data, 
the functional map will not be called and no information for that 
state will be generated in the output.

How to run the example:

1)  Using the Map Designer, open states.mms.  
    It contains the following two maps:
    a) "master" - This map calls the "MapState" functional map.
    b) "MapState" - This map retrieves state ID and population
       data and returns it to output.         

2)  Build and run the map.

3)  View resutls.


=====================================================================
                             END OF FILE
=====================================================================
