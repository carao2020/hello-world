package map;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;
import java.util.Iterator;

import com.ibm.websphere.dtx.ds.map.MSCard;
import com.ibm.websphere.dtx.ds.map.MSCardType;
import com.ibm.websphere.dtx.ds.map.MSConstants;
import com.ibm.websphere.dtx.ds.map.MSMap;
import com.ibm.websphere.dtx.ds.map.MSMapSource;

/**
 * This example shows how to create a simple map using Java APIs.
 * <p>The example creates one map, adds one input and one output card with the provided type trees, 
 * then iterates over output card types and sets the rules. 
 */
public class CreateMapExample{
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	static String DefaultTargetLocation = "output/Mail.mms";
	
	private String _inputTreeLocation = "files/Contact.mtt";
	private String _outputTreeLocation = "files/Label.mtt";
	private String _targetLocation = DefaultTargetLocation;
	
	public CreateMapExample() {
		super();
	}


	private String getAbsoluteLocation(String fileLocation) {
		if(fileLocation != null && fileLocation.startsWith("files/")){
			URL url = getClass().getResource(fileLocation);
			fileLocation = url.getFile().replace("%20", " ").substring(1);
		}
	
		File sourceFile = new File(fileLocation);
		return sourceFile.getAbsolutePath();
	}


	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}


	/**
	 * This method runs the example
	 */
	public void run(){
		
		MSMapSource mapSource = MSMapSource.createMap(getTargetLocation());
	
		if(mapSource != null){
			MSMap map = mapSource.addMap("ContactToLabel");
			MSCard inputCard = new MSCard();
			inputCard.setCardName("ContactFile");
			inputCard.setTreeLocationPath(getInputTreeLocation());
			inputCard.setTypeName("ContactFile Data");
			map.addInputCard(inputCard);
			
			inputCard.getAdapter().setAdapterType(MSConstants.IO_TYPES.DATAFILE.customOrdinal());
			inputCard.getAdapter().setFileName(getAbsoluteLocation("files/Contact.txt"));
			
			// set type
			MSCard outputCard = new MSCard();
			outputCard.setCardName("Label");
			outputCard.setTreeLocationPath(getOutputTreeLocation());
			outputCard.setTypeName("Label Data");
			outputCard.getAdapter().setAdapterType(MSConstants.IO_TYPES.DATAFILE.customOrdinal());
			outputCard.getAdapter().setFileName("Label.txt");
			map.addOutputCard(outputCard);
			
			// add rules
			MSCardType root = outputCard.getRoot();
			Iterator<MSCardType> typeIter = root.getChildComponents();
			while (typeIter.hasNext()) {
				MSCardType nextType = (MSCardType) typeIter.next();
				processType(nextType);
			}
		}
		
		mapSource.save();
		mapSource.close();
			
	}

	public void processType(MSCardType type) {
		
		String nodeName = type.getTypePath();
		if(nodeName.equals("FullName Field")){
			type.addRule( "Last Name Field:Contact:ContactFile + \",\" + First Name Field:Contact:ContactFile");
		}
		else if(nodeName.equals("Company Field")){
			type.addRule("Company Field:Contact:ContactFile");
		}
		else if(nodeName.equals("Street Field")){
			type.addRule("Street Field:Contact:ContactFile");
		}
		else{
			type.addRule("NONE");
		}
		
		Iterator<MSCardType> typeIter = type.getChildComponents();
		while (typeIter.hasNext()) {
			MSCardType nextType = (MSCardType) typeIter.next();
			processType(nextType);
		}
		
	}

	public String getInputTreeLocation() {
		return getAbsoluteLocation(_inputTreeLocation);
	}

	public String getOutputTreeLocation() {
		return getAbsoluteLocation(_outputTreeLocation);
	}

	public void setInputTreeLocation(String inputTreeLocation) {
		_inputTreeLocation = inputTreeLocation;
	}

	public void setOutputTreeLocation(String outputTreeLocation) {
		_outputTreeLocation = outputTreeLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultTargetLocation;
		CreateMapExample target = new CreateMapExample();
		target.setTargetLocation(location);
		target.run();
	}

}
