/*
 * IBM Confidential
 * OCO Source Materials
 * 5747-SM3
 * � Copyright IBM Corp. 2012
 *
 * This software is the property of IBM Corporation and its licensors 
 * and contains their confidential trade secrets. Use, examination, copying,
 * transfer and disclosure to others, in whole or in part, are prohibited
 * except with the express prior written consent of IBM Corporation. 
 */

public class Company extends Entity {

	private String 	companyName 		= new String("");
	private String 	companyDescription 	= new String("");
	private int 	employeeAmt 		= -1;
	private boolean tradedPublicly 		= false;

	public Company() {
	}

	public Company(String Name, String Description) {
		super(Name, Description);
	}

	public void setCorpInfo(int nNumEmployees, boolean fTraded) {
		employeeAmt 	= nNumEmployees;
		tradedPublicly	= fTraded;
	}

	public String getInfo() {
		return new String("Company: " + getName() + ", " + 
						  "Description: " + getDescription() + ", " +
						  "Employees: " + (employeeAmt < 0 ? "unknown" : employeeAmt) + ", " +
						  "Publicly traded: " + (employeeAmt < 0 ? "unknown" : tradedPublicly));
	}
}
