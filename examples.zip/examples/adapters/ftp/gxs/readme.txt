IBM WebSphere Transformation Extender 
Accessing the GXS VAN with the FTP Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the sample files for accessing 
the GE Global eXchange Services (GXS) VAN with the FTP adapter. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    gxs_cert.mms - map source file which contains ibm_transmit and
                   ibm_receive
    Tree1.mtt    - Type tree to support the example maps
    EDI.mtt      - EDI specific type tree to support the example maps
    gxs1to1.edi  - Loopback EDI message sent from Test3 to Test3 
                   mailbox
    gxs1to2.edi  - EDI message sent from Test3 to Test4 mailbox
    x12.edi      - X12 EDI format message sent from Test3 to Test4 
                   mailbox
    readme.txt   - this readme file
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example provides the gxs_cert.mms file which contains maps that 
will help you understand how the FTP Adapter works using the GE 
Global eXchange Services (GXS) VAN. 

Prerequisites
-------------
- A valid account with the VAN provider
- Trading partners which are configured and verified
- Properly configured send and receive addresses

How to run the example:

As these maps all use a GXS test account, modification of internal
details is not necessary.  To run an example, build the map, then
run it.  A brief description of each map follows:


gxs_dirlist                    - outputs a listing of the specified 
                                 directory
gxs_receive_only_one           - Receives exactly one message
gxs_retrieve                   - Receives all pending messages
gxs_transmit                   - sends a message

scenario1_1_loopback_send      - sends a message from Test3 to Test3
scenario1_2_loopback_receive   - receives the message to Test3

scenario2_1_test3_send         - sends a message from Test3 to Test4
scenario2_2_test4_receive      - receives the message to Test4

scenario3_1_test3_send_x12     - sends a message from Test3 to Test4
                                 in X12 EDI format, using a type tree
scenario3_2_test4_receive_x12  - Receives the message to Test4


Breaking down the command lines
-------------------------------
Conventions used
----------------

- variable information is enclosed in matching angle-brackets <>, 
  which should be removed when the variables are changed

- each variable is documented under the example command line in which 
  it is used

Sending Messages
----------------------

-TV -GXS -URL FTPS://<LUSERID:LPASSWORD>@<SERVERURL>:<SERVERPORT>/
<DESTINATIONDIRECTORY>;type=A


Constant information:
;type=A                       - specifies that the transfer will 
                                happen in ASCII mode

Variable definitions:

<LUSERID:LPASSWORD>           - The login userid and password 
                                associated with the customer account

Retrieving Messages
-------------------------

-TV -GXS -URL FTPS://<LUSERID:LPASSWORD>@<SERVERURL>:<SERVERPORT>/
<RETREIVEDIRECTORY>/


Variable definitions:

<LUSERID:LPASSWORD>           - The login userid and password 
                                associated with the customer account
<SERVERURL>                   - The internet address associated with 
                                the server
<SERVERPORT>                  - Which port the server's SFTP service 
                                listens on (default 990)
<DESTINATIONDIRECTORY>        - The directory and filename to deliver 
                                the file as
<RETREIVEDIRECTORY>           - The directory name to retreive new 
                                messages from


=====================================================================
                             END OF FILE
=====================================================================
