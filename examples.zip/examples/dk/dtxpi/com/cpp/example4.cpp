/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include <atlbase.h>

extern CComModule _Module;
#include <atlcom.h>
#include <comdef.h>
#include "common.h"

namespace
{
  static const int	EVENT_ID = 111;//any arbitary value
  static const int	DISPID_ADDITION_DONE = 1;//disp id of AdditionDone...

  _ATL_FUNC_INFO OnReportEvent	=
	   						                  {
										                  CC_STDCALL, //calling conv...
										                  VT_EMPTY ,//return value...
										                  3 ,//number of arguments...
										                  {VT_I4, VT_I4, VT_I4}//argumnent types...
								                  };


}


class CEventSink : public IDispEventSimpleImpl<EVENT_ID,CEventSink,&DIID_IMMapEvents>
{
  public:	  
  
  // ReportEvent Class
  void _stdcall ReportEvent(long nEventID, long nBurstNum, long nCardNum);

  BEGIN_SINK_MAP(CEventSink)
	  SINK_ENTRY_INFO(EVENT_ID,DIID_IMMapEvents,DISPID_ADDITION_DONE,ReportEvent,&OnReportEvent)
	END_SINK_MAP()  
};


void _stdcall CEventSink::ReportEvent(long nEventID, long nBurstNum, long nCardNum)
{
	switch(nEventID)
	{
		case MPI_EVENT_START_INPUT:
			printf("Event received = MPI_EVENT_START_INPUT \n");
			break;
		case MPI_EVENT_INPUT_COMPLETE:
			printf("Event received = MPI_EVENT_INPUT_COMPLETE \n");
			break;
		case MPI_EVENT_START_OUTPUT:
			printf("Event received = MPI_EVENT_START_OUTPUT \n");
			break;
		case MPI_EVENT_OUTPUT_COMPLETE:
			printf("Event received = MPI_EVENT_OUTPUT_COMPLETE \n");
			break;
		case MPI_EVENT_START_BURST:
			printf("Event received = MPI_EVENT_START_BURST \n");
			break;
		case MPI_EVENT_BURST_COMPLETE:
			printf("Event received = MPI_EVENT_BURST_COMPLETE \n");
			break;
		case MPI_EVENT_START_MAP:
			printf("Event received = MPI_EVENT_START_MAP \n");
			break;
		case MPI_EVENT_MAP_COMPLETE:
			printf("Event received = MPI_EVENT_MAP_COMPLETE \n");
			break;
		default:
			printf("Unknown event !!!");
  }
}



int main()
{
  // Initialize the com libraries
	CoInitialize(NULL);
	
	try
	{
    IMFactoryPtr pMFactory(__uuidof(MFactory));
		BSTR bstrName = NULL;
    CComBSTR ccbstrName("test4.mmc");    

    /* Initialize the API */
    pMFactory->InitializeAPI(bstrName);         

    /* Load the Map */    
    IMMapPtr pMMap = pMFactory->MapLoadFile((_bstr_t)ccbstrName);    

    /* Create a sink class and register the class*/
    CEventSink* pSinkCPPClass = new CEventSink();
    pSinkCPPClass->DispEventAdvise(pMMap,
	  						                     &DIID_IMMapEvents);
	 /*Register all event */
    pMMap->MapSetupNotifications(MPI_EVENT_ALL);

    /* Run the Map */
    pMMap->Run();	

    /* Unregister the class*/
    pSinkCPPClass ->DispEventUnadvise(pMMap);
    delete pSinkCPPClass;

    /* Get the Error Response */
    ccbstrName = (BSTR)pMMap->GetTextProperty(MPIP_OBJECT_ERROR_MSG, 0);
    int nResultCode = pMMap->GetIntegerProperty(MPIP_OBJECT_ERROR_CODE, 0);	
	
    // print the error
    LPCTSTR lpszError = (LPCTSTR)_com_util::ConvertBSTRToString(ccbstrName);
    printf("Map status: %s (%d)\n", lpszError, nResultCode);

    /* Unload the Map */
	  pMMap->MapUnload();	      

    /* Exit the API */
    pMFactory->TerminateAPI();
	}

	catch (const _com_error Err)
	{          
    printf("Error Description: %s\n", (LPCTSTR)Err.Description());
	}

	CoUninitialize();

	return 0;
}
