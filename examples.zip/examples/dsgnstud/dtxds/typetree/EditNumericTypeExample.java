package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;

import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTNumber;
import com.ibm.websphere.dtx.ds.typetree.TTPad;
import com.ibm.websphere.dtx.ds.typetree.TTSign;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTType;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.ITEM_TYPES;

/**
 * This example demonstrates how to open a type tree, perform an update and save to a file.
 * 
 *
 */
public class EditNumericTypeExample {
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	private static String DefaultSourceLocation = "files/employee.mtt";
	private static String DefaultTargetLocation = "output/employee.mtt";
	
	private String _sourceLocation = DefaultSourceLocation;
	private String _targetLocation = DefaultTargetLocation;
	
	TTSource _typeTreeSource = null;
	
	public EditNumericTypeExample() {
		super();
	}

	/**
	 * This method runs the example
	 */
	public void run(){
		
		loadTypeTree();
		if(_typeTreeSource == null){
			System.out.println("Can not create type tree with location: " + getTargetLocation());
			return;
		}
		
		
		try {
			
			TTWalker walker = new TTWalker() {
				
				@Override
				public void processType(TTType type) {
					
					switch (type.getTypeClass()) {
					case TI_ITEM:
						TTItem item = (TTItem)type;
						if(item.getItemType() == ITEM_TYPES.IT_NUMBER){
							
							TTNumber number = (TTNumber)item.getItemProperties();
							TTPad pad = number.getPad();
							
							TTSign signMinus = number.getSignMinus();
							TTSign signPlus = number.getSignPlus();
							if(signPlus.getTrailing().equals("+")){
								signPlus.setTrailing("++");
							}
							TTSign signZero = number.getSignZero();
						}
					
						break;
					default:
						break;
					}
				}
			};
			walker.walkType(_typeTreeSource.getRootType());
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		_typeTreeSource.saveAs(getTargetLocation());
		
		_typeTreeSource.close();
	}
	
	protected void loadTypeTree(){
		
		// Load type tree from a file.
		String fileLocation = getSourceLocation();
		if(DefaultSourceLocation.equals(getSourceLocation())){
			URL url = getClass().getResource(DefaultSourceLocation);
			fileLocation = url.getFile().replace("%20", " ").substring(1);
		}
		File sourceFile = new File(fileLocation);
		if(sourceFile.exists()){
			/* Open Type Tree */
			_typeTreeSource = TTSource.openTypeTree(fileLocation);
		}

	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultSourceLocation;
		String targetlocation = args.length == 2 ? args[1] : DefaultTargetLocation;
		EditNumericTypeExample target = new EditNumericTypeExample();
		target.setSourceLocation(location);
		target.setTargetLocation(targetlocation);
		target.run();
	}

	public String getSourceLocation() {
		return _sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		_sourceLocation = sourceLocation;
	}

	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}

	

}
