IBM WebSphere Transformation Extender 
EXIT Function Example Readme


(c) Copyright International Business Machines Corporation 2006-2015.
All Rights Reserved.


This example demonstrates the usage of the EXIT function.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    exit.mms        map source file

    exit.mtt        type tree

    mydll64.dll

    readme.txt  (this readme file)


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example uses the EXIT function to call the function 'Alternate' 
in mydll64.dll. 

The DLL manipulates the text string that is passed as the third 
argument of the EXIT function. The result of the Alternate function 
is that the characters in the output string alternate between lower 
and uppercase.

How to run the example:

1)  Using the Map Designer, open exit.mms.

2)  Build and run the exitxmpl map.

3)  Open the exittest.out output file to view results.


=====================================================================
                             END OF FILE
=====================================================================
