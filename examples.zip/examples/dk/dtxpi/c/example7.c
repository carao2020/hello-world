/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#define MAX_BUFFER_LEN 131072
#define CHECK_ERR(rc) if(MPIRC_FAILED(rc))     { printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

int main()
{
    const char  *szCommandLine;
    char        szOutXML[MAX_BUFFER_LEN];
    char        buf[4];
    size_t      iLen;
    int         ids[1];
    MPIRC       rc;
    HMPIMAP     hMap;
    HMPICARD    hCard;
    HMPIADAPT   hAdapter;

    rc = mpiInitAPI(NULL); 
    CHECK_ERR(rc);


    rc = mpiMapLoadFile (&hMap, "test7.mmc");
    CHECK_ERR(rc);

    /* Get the adapter object handle for input card #1*/
    rc = mpiMapGetInputCardObject (hMap, 1, &hCard);
    CHECK_ERR(rc);

    /* Get the handle to the adapter object */
    rc = mpiCardGetAdapterObject (hCard, &hAdapter);
    CHECK_ERR(rc);

    /* Get the adapter command line in raw format */
    rc = mpiPropertyGetText (hAdapter, MPIP_ADAPTER_COMMANDLINE, 0, &szCommandLine, &iLen);
    CHECK_ERR(rc);
    printf("The adapter command line is....\n%s\n\n", szCommandLine);

    /* Get it in XML format */
    iLen = sizeof(szOutXML);
    ids[0] = MPIP_ADAPTER_COMMANDLINE;
    rc = mpiPropertyGetPropertiesXML(hAdapter, ids, 0, 1, &szOutXML[0], &iLen);
    CHECK_ERR(rc);
    printf("The adapter command line in XML is....\n%s\n\n", szOutXML);

    /* Modify the command line using XML */
    memset(szOutXML, 0, iLen);
    strcat(szOutXML, "<Adapter>");
    strcat(szOutXML, "<CommandLine id=\"");
    sprintf(buf, "%d", MPIP_ADAPTER_COMMANDLINE);
    strcat(szOutXML, buf);
    strcat(szOutXML, "\" type=\"text\">"); 
    strcat(szOutXML, "input2.txt");
    strcat(szOutXML, "</CommandLine>");
    strcat(szOutXML, "</Adapter>");
    rc = mpiPropertySetPropertiesXML(hAdapter, szOutXML);
    CHECK_ERR(rc);

    /* Print all of the Adapter's properties in XML format */
    memset(szOutXML, 0, iLen);
    rc = mpiPropertyGetAllPropertiesXML(hAdapter, &szOutXML[0], &iLen, 0);
    CHECK_ERR(rc);
    printf("The modified, complete set of adapter properties is....\n%s\n\n", szOutXML);

    /* Clean up */
    rc = mpiMapUnload (hMap);
    CHECK_ERR(rc);

    rc = mpiTermAPI();
    CHECK_ERR(rc);
    return 0;
}
