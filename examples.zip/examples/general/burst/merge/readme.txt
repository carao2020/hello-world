IBM WebSphere Transformation Extender 
Map File Merge Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of burst mode to make merging 
inputs faster. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example

=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    java.mtt    type tree

    merge.mms   map source file

    readme.txt  this readme file    

    t1.dat      data files
    t2.dat
    t3.dat


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example shows how burst mode can make merging inputs faster. 

How to run the example:

1)  Using the Map Designer, open merge.mms.

    There are three inputs, all set to burst mode. 
    The FetchUnit for each is set to 50. 

    Note:   You can change the FetchUnit value, however all three 
            inputs must have the same value.

    When the merge map runs, the first row of the first input, the 
    first row of the second input, and the first row of the third 
    input (data files) are used to create the first row of the 
    output. 
    
    Then, the second row of the first input, the second row of the 
    second input, and the second row of the third input are used to 
    produce the second output row. This pattern continues until all 
    input rows are consumed. 

2)  You will not see the burst effect unless you make the input files
    larger. To do this, use the clninput map the same way as the 
    merge map.

    There are two executable maps in this map file: clninput and 
    merge. Use clninput to make the three input data sets t1.dat,
    t2.dat, and t3.dat larger. Use the merge map to merge the inputs 
    to create one output.

    Note:   Distinguishable messages might occur when analyzing the 
            java.mtt type tree. The types that are not 
            distinguishable are only used to clone the data, not
            as input that will need to be validated. 


=====================================================================
                             END OF FILE
=====================================================================
