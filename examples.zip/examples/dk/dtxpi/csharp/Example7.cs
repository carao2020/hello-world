/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
using System;
using com.ibm.websphere.dtx.dtxpi.dtxinterop;

namespace com.ibm.websphere.dtx.dtxpi.example
{
	/// <summary>
	/// This example gets and sets the map properties
	/// </summary>
	public class Example7
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				MFactoryClass imFactory = new MFactoryClass();
				imFactory.InitializeAPI(null);

				// Load the Map 
				MMap map = imFactory.MapLoadFile("test7.mmc");    
				map.Run();

				// Get an adapter object
				MCard card = map.GetInputCard(1);
				MAdapter adapter = card.GetAdapter();

				// Get the adapter command line in raw format
				Console.WriteLine( "The adapter command line is....\n" +
						   adapter.GetTextProperty( MConstants.MPIP_ADAPTER_COMMANDLINE, 0 ) +
						   "\n");

				// Get it in XML format 
				int property = MConstants.MPIP_ADAPTER_COMMANDLINE;
				string xml = adapter.GetPropertiesXML(ref property, 1);
				Console.WriteLine("The adapter command line in XML is....\n" + xml + "\n");

				// Modify the command line using XML
				xml = "<Adapter>" +
					"<CommandLine id=\"" + MConstants.MPIP_ADAPTER_COMMANDLINE + "\" type=\"text\">" +
					"input2.txt" +
					"</CommandLine>" +
					"</Adapter>";
				adapter.SetPropertiesXML( xml );

				// Print all of the Adapter's properties in XML format
				string xmlProps = adapter.GetAllPropertiesXML(0);
				Console.WriteLine("The modified, complete set of adapter properties is....\n" + xmlProps + "\n");

				// Unload the Map
				map.MapUnload();	      

				// Exit the API 
				imFactory.TerminateAPI();
			}
			catch (Exception e)
			{          
				Console.Out.WriteLine("Error Description: "+e);
			}
		}
	}
}
