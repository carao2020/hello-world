IBM WebSphere Transformation Extender 
Programming Interface for RMI Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of sample files for the IBM
WebSphere Transformation Extender RMI Programming Interface.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using These Examples


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in these examples:

Example1.java - Simplest case of running a map

Example2.java - Running multiple instances of a map in parallel

Example3.java - Overriding a card in a map

Example4.java - Using a user-provided status method

Example5.java - Using streams to override inputs and outputs

Example6.java - Loading a map from a byte array

Example7.java - Getting and setting properties

Example8.java - Using serialization and deserialization
AnObject.java

setenv.bat    - Sets the class path so that the examples can be run

make.bat     -  Batch file to build executables


=====================================================================
2: USING THESE EXAMPLES
=====================================================================

These examples contain sample files to use the IBM WebSphere 
Transformation Extender RMI Programming Interface and how it loads, 
runs and controls maps.

To build and run the examples, follow these steps:

1) Compile the Java files.

   Open the batch file "make.bat" and  set
   JDKHOME variable For Windows, from a DOS command prompt, compile
   the java files by executing:

   	make.bat
   	

2) Set environment variable.

   From a DOS command prompt, set the environment by executing:

        setenv.bat

2) Using the Map Designer,  open 
   <install_dir>\examples\dk\dtxpi\dtxpiex.mms and build the
   following maps:

    test1.mmc
    test2.mmc
    test3.mmc
    test4.mmc
    test5.mmc
    test6.mmc
    test7.mmc
    test8.mmc
    test10.mmc

3) Place the compiled map files in the same directory as the example
   program executables.

4) Copy input.txt, input.gz, and input2.txt to the same directory.

5) Execute the examples.

   For example, if the RMI server is running on local machine at port
   2500 and the compiled maps are in 
   <install_dir>\examples\dk\dtxpi\rmi
   you would enter the following command from the DOS prompt to run 
   Example 1:

   java Example1 localhost 2500 <install_dir>\examples\dk\dtxpi\rmi

   Note: The third argument is the path where the compiled map files
         are as the RMI Server sees it. In other words if the server
         is running on a different machine the map files need to be
         copied to a folder the server machine can read and the third
         argument points to that folder as the server sees it.
	
   Note: To run example4 successfully, the RMI server should be 
         running in JRMP protocol. If the RMI server is running in
         IIOP protocol, then "example4.java" should be changed to use
         the method PortableRemoteObject to export and unexport the
         remote object.

   Note: For "example6" the map "test6.mmc" should be available on
         the client machine and should be built in the platform where
         RMI Server is located.


=====================================================================
                             END OF FILE
=====================================================================
