/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.io.FileInputStream;

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MStream;
import com.ibm.websphere.dtx.dtxpi.tools.MObjectPool;

public class Example8
{
    public static void main(String[] args)
    {
        try
        {
            // Initialize the API
            MMap.initializeAPI(null);

            // Create a map
            MMap map = new MMap("test8.mmc");

            // Get WTX unique value for map instance
            // getUniqueMapInstance method guaranties that all map instances
            // are unique within the same process
            int uniqueInst = MMap.getUniqueMapInstance();

            map.setIntegerProperty(MConstants.MPIP_MAP_INSTANCE, 0, uniqueInst);

            // Override the input card so that a local file
            // containing input data can be sent to the remote server
            MCard card = map.getInputCardObject(1);
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Create a local Object
            AnObject anObject = new AnObject();
            anObject.setString(".. and they all lived happily ever after");

            // Put it in the Object Pool
            MObjectPool pool = MObjectPool.getInstance();
            String key = pool.generateNewReferenceValue(anObject);
            pool.storeObjectToThePool( map.getIntegerProperty(MConstants.MPIP_MAP_INSTANCE, 0),
                                       key,
                                       anObject);

            // Pass it to the server via a stream
            MAdapter adapter = card.getAdapter();
            MStream stream = adapter.getOutputStream();
            stream.write(key.getBytes("8859_1"), 0, key.length());

            // Get the adapter object handle for output card #2
            card = map.getOutputCardObject(2);

            // Override the adapter in output card #2 to be a stream
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Get the output as a stream
            adapter = card.getAdapter();
            stream = adapter.getInputStream();

            // Get the data in pieces from the stream
            stream.seek(0, MConstants.MPI_SEEK_SET);
            while( true )
            {
                boolean bIsEnd = stream.isEnd();

                // Clean and Break
                if( bIsEnd )
                {
                    stream.setSize(0);
                    break;
                }

                byte[] page = stream.readPage();
                System.out.println(new String(page,"8859_1"));
/*              DoSomethingWithData (page, page.length); */
            }

            // Clean up
            map.unload();
            MMap.terminateAPI();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
