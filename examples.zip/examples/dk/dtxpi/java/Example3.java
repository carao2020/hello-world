/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;

public class Example3
{
    public static void main(String[] args)
    {
        try
        {
            // Initialize the API
            MMap.initializeAPI(null);

            // Load a map file 
            MMap map = new MMap("test3.mmc");

            // Turn on burst and summary execution audit on the map instance 
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_SWITCH, 0, MConstants.MPI_SWITCH_ON);
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_BURST_EXECUTION, 0, MConstants.MPI_SWITCH_ON);
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_SUMMARY_EXECUTION, 0, MConstants.MPI_SWITCH_ON);

            // Get the adapter object handle 
            MCard card = map.getInputCardObject(1);
            card.overrideAdapter("GZIP", 0);

            // set a command line for the adapter
            MAdapter adapter = card.getAdapter();
            adapter.setTextProperty(MConstants.MPIP_ADAPTER_COMMANDLINE, 0, "-FILE input.gz");
            // overwrite CodePageFallback map setting with UTF16 string
            byte usubst[]={ 0x24, 0, 0x24, 0, 0x2b, 0, 0x25, 0, 0x25, 0, 0x24, 0, 0x24, 0, 0x24, 0, 0x24, 0 };
            map.setBinaryProperty(MConstants.MPIP_MAP_SUBST_CHARS, 0, usubst);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            map.unload();
            MMap.terminateAPI();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
