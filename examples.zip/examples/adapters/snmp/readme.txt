IBM WebSphere Transformation Extender 
SNMP Adapter example readme


� Copyright International Business Machines Corporation 2006, 2008.
All Rights Reserved.


This example demonstrates the usage of SNMP Adapter sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

snmp.mtt     - Type tree for detailed SNMP traps
snmpex.mtt   - Type tree for the example maps
snmpex.mms   - Example maps
snmpex.gif   - Sample binary data



=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to be used with the SNMP Adapter. 

The SNMP Adapter sends traps to one or more SNMP managers. To
effectively run the examples, an SNMP manager should be listening for
traps on port 162. You can change the port by editing the example
maps.

Specify trap hosts in the dtx.acl file, located in the directory into 
which you installed IBM WebSphere Transformation Extender.

Before you run the examples, do the following prerequisite steps:

  1. Download any SNMP Browser and SNMP Manager that you prefer to 
     use.
  2. After the SNMP Browser and SNMP Manager are downloaded, do the 
     required setup configurations.
  3. Import the dtx_smi1.mib file into the SNMP Browser.  


Example 1: Simple
-----------------

The Simple example shows how to send a trap without using a type
tree.

The example map consists of the following output cards:

Output1  -  data entry field
Output2  -  test to determine if data causes a trap to be sent

Running the Simple example should send a trap containing the
following information:

Specific trap IBM WebSphere Transformation Extender: dtxUserData #21 
              trap(v1)
  Enterprise: IBM WebSphere Transformation Extender
  Specific Trap MIB Lookup Results
    Name: dtxUserData, Module: DTX-EVENT-SERVER-MIB, Enterprise:
    IBM WebSphere Transformation Extender Bindings (3)
    Binding #1: dtxUserDataTxt *** (octets) The number is higher than
                it should be.31
    Binding #2: dtxUserTrapPriority *** (int32) notApplicable(1)
    Binding #3: dtxMapFile *** (octets) install_dir\examples\
                adapters\snmp\simple.mmc

Note that because it is not possible to set the dtxUserTrapPriority
variable without a type tree, the default priority notApplicable(1)
is used.


Example 2: Detailed
-------------------

The Detailed example shows how to send a trap using a type tree.

The example map consists of the following output cards:

TrapInfo  -  detailed trap information
Output1   -  data entry field
Output2   -  test to determine if data causes a trap to be sent

Running the Detailed example should send a trap containing the
following information:

Specific trap IBM WebSphere Transformation Extender::dtxUserData #21 
              trap(v1)
  Enterprise: IBM WebSphere Transformation Extender
  Specific Trap MIB Lookup Results
    Name: dtxUserData, Module: DTX-EVENT-SERVER-MIB, Enterprise:
    IBM WebSphere Transformation Extender Bindings (4)
    Binding #1: dtxUserDataInt *** (int32) 5150
    Binding #2: dtxUserDataTxt *** (octets) The number is too high!
    Binding #3: dtxUserTrapPriority *** (int32) informational(2)
    Binding #4: dtxMapFile *** (octets) install_dir\examples\
                adapters\snmp\detailed.mmc

Example 3: Simple_v2
--------------------

The Simple example shows how to send a V2 trap without using a type
tree.

The example map consists of the following output cards:

Output1  -  data entry field
Output2  -  test to determine if data causes a trap to be sent

Running the Simple example should send a trap containing the
following information:

Specific trap IBM WebSphere Transformation Extender: dtxUserData  
              trap(v2c)
  Enterprise: IBM WebSphere Transformation Extender
  Specific Trap MIB Lookup Results
    Name: dtxUserData, Module: DTX-EVENT-SERVER-MIB, Enterprise:
    IBM WebSphere Transformation Extender Bindings (3)
    Binding #1: dtxUserDataTxt *** (octets) The number is higher than
                it should be.31
    Binding #2: dtxUserTrapPriority *** (int32) notApplicable(1)
    Binding #3: dtxMapFile *** (octets) install_dir\examples\
                adapters\snmp\simple.mmc

Note that because it is not possible to set the dtxUserTrapPriority
variable without a type tree, the default priority notApplicable(1)
is used.

Example 4: Simple_v3
--------------------

The Simple example shows how to send a V3 trap without using a type
tree.

The example map consists of the following output cards:

Output1  -  data entry field
Output2  -  test to determine if data causes a trap to be sent

Running the Simple example should send a trap containing the
following information:

Specific trap IBM WebSphere Transformation Extender: dtxUserData  
              trap(v3)
  Enterprise: IBM WebSphere Transformation Extender
  Specific Trap MIB Lookup Results
    Name: dtxUserData, Module: DTX-EVENT-SERVER-MIB, Enterprise:
    IBM WebSphere Transformation Extender Bindings (3)
    Binding #1: dtxUserDataTxt *** (octets) The number is higher than
                it should be.31
    Binding #2: dtxUserTrapPriority *** (int32) notApplicable(1)
    Binding #3: dtxMapFile *** (octets) install_dir\examples\
                adapters\snmp\simple.mmc

Note that because it is not possible to set the dtxUserTrapPriority
variable without a type tree, the default priority notApplicable(1)
is used.

Before running this example please ensure that:
1. The dtx.uacl file contains context-names and users that match the 
specified -u and -ctx parameters used by the adapter.

For example:

acl = {
{ 
context-names = public
access = read-write
security-level=noAuthNoPriv
users = myUser
}

} 

2. The dtx.security file contains a userEntry that matches the user
specified by -u used by the adapter

For example:

#Local engine ID
localEngineID=0x8000002a05819dcb6200001f97
#Number of boots
localEngineBoots=2

#User and security configuration
userEntry=localEngineID,myUser,,usmHMACMD5AuthProtocol,mypassword

3. Your SNMP manager has created a user which matches the user defined
in steps 1 and 2 above

For example:

createUser -e 0x8000002a05819dcb6200001f97 myUser MD5 mypassword DES myotherpassword
