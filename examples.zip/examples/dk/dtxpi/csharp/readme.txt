IBM WebSphere Transformation Extender 
Programming Interface C# Example Readme


(c) Copyright International Business Machines Corporation 2006-2015.
All Rights Reserved.


These examples demonstrate the usage of the .NET interoperability for 
the COM API. Also demonstrated is how to load, run, and control maps 
using the Microsoft .NET C# programming language. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in these examples:

Example1.cs - Simplest case of running a map

Example2.cs - Running multiple instances of a map in parallel

Example3.cs - Overriding a Card in a Map

Example4.cs - Using a user-provided status method

Example5.cs - Using streams to override inputs and outputs

Example6.cs - Loading a map from a byte array

Example7.cs - Getting and setting properties

windows.mk  - Make file to build executables


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to use the IBM WebSphere 
Transformation Extender. Programming Interface to load, run, and 
control maps using the Microsoft .NET C# programming language. 

To build and run the examples, follow these steps:

1. Build the executables.

   Ensure that the NETFRAMEWORK_BIN environment variable is set to 
   the Microsoft .NET framework directory that contains the C# 
   compiler "csc.exe".  Note:  for these examples, version 1.1.4322
   or later of the Microsoft .NET framework should be used.

   From a DOS command prompt, build the examples by executing:

   nmake /f windows.mk

2. Using the Map Designer, open the dtxpiex.mms file under:

   <install_dir>\examples\dk\dtxpi\dtxpiex.mms 

   and build the following maps:

    test1.mmc 
    test2.mmc 
    test3.mmc 
    test4.mmc 
    test5.mmc 
    test6.mmc 
    test7.mmc 

3. Place the compiled map files in the same directory as the example
   program executables.

4. Copy input.txt, input.gz, and input2.txt to the same directory.

5. Execute the examples.


=====================================================================
                             END OF FILE
=====================================================================
