package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;

import com.ibm.websphere.dtx.ds.MDSException;
import com.ibm.websphere.dtx.ds.typetree.TTCategory;
import com.ibm.websphere.dtx.ds.typetree.TTDelimitedSyntax;
import com.ibm.websphere.dtx.ds.typetree.TTGroup;
import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTRestrictionValue;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTTypeSyntax;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.ITEM_TYPES;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.SYNTAX_CHAR_TYPE;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.TYPE_GROUP_SUBCLASS;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.TYPE_GROUP_SYNTAX;

/**
 * The following is an example of defining a syntax object as a component of a group type. 
 * <p>
 * The following data represents a message received from multiple departments.
 * <p>
 * Each message is made up of segments. Each department uses different segment delimiters and terminators. 
 * The message format specifies that the delimiter and terminator are the first two bytes of the message, 
 * followed by the actual data.
 * <p>
 * During the data validation process, the component SegmentDelimiter appears in the data with a value of *. 
 * The group type Segment has a variable delimiter specified as the item type SegmentDelimiter, with the value *. 
 * Therefore, it is understood that the segment has * as the delimiter.
 * <p>
 * When the value of a syntax object appears as actual data, it can be mapped as data. 
 * For example, source data may use different delimiters from several different sources. 
 * Acknowledgments of this data must be sent back to the source using the delimiter used in the original data. 
 * This data can be mapped from the input to the output if these syntax objects are defined as components within 
 * the data.
 * 
 */
public class SyntaxObjectsAsComponentsOfTypeExample {

	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	
	private static String DefaultLocation = "output/syntaxObjectsAsComponentsOfTypeExample.mtt";
	private String _fileLocation = DefaultLocation;

	/**
	 * @param fileLocation
	 */
	public SyntaxObjectsAsComponentsOfTypeExample(String fileLocation) {
		super();
		_fileLocation = fileLocation;
	}

	/**
	 * This method runs the example
	 */
	public void run(){

		TTSource typeTreeSource = TTSource.createTypeTree("Root", getFileLocation());

		TTCategory rootType = typeTreeSource.getRootType();
		try {
		
			TTCategory cat = rootType.addCategory("Fields");

			// Define two separate syntax objects with an Item Subclass of Syntax, 
			// one for the message delimiter and one for the message terminator. 

			TTItem dataItem = cat.addItem("DataItem");
			TTItem segDelimiter = cat.addItem("SegmentDelimiter");
			TTItem segTerminator = cat.addItem("SegmentTerminator");

			TTGroup message = cat.addGroup("Message");

			message.addComponent(dataItem);
			
			segDelimiter.setItemType(ITEM_TYPES.IT_SYNTAX);
			segTerminator.setItemType(ITEM_TYPES.IT_SYNTAX);
			
			// Define the possible message delimiter values as restrictions of the SegmentDelimiter item type. 
			TTRestrictionValue restrDel = new TTRestrictionValue();
			restrDel.setValue("*");
			segDelimiter.addRestriction(restrDel);
			
			// Define the possible message terminator values as restrictions of the SegmentTerminator item type.
			TTRestrictionValue restrTerm = new TTRestrictionValue();
			restrTerm.setValue("!");
			segTerminator.addRestriction(restrTerm);
			
			// In the Delimiter property set SegmentDelimiter as Delimiter 
			message.getGroupProperties().setGroupSubClass(TYPE_GROUP_SUBCLASS.TGSC_SEQUENCE);
			message.getGroupProperties().setFormatAsImplicit(false);
			message.getGroupProperties().setGroupSyntaxType(TYPE_GROUP_SYNTAX.DELIMITED);
			
			TTDelimitedSyntax groupSyntax = (TTDelimitedSyntax)message.getGroupProperties().getGroupSyntax();
			
			groupSyntax.getDelimiter().setVariableTypeSyntax(true);
			groupSyntax.getDelimiter().setItem(segDelimiter);
			groupSyntax.getDelimiter().setDefaultValue("*");
			// Indicate that the variable delimiter should be determined for each occurrence of the object by setting true for Find property:
			groupSyntax.getDelimiter().setFindFlag(true);
			
			// Set SegmentTerminator as Terminator.
			TTTypeSyntax typeSyntax = message.getTypeProperties().getTypeSyntax();
			typeSyntax.setTerminator(SYNTAX_CHAR_TYPE.VARIABLE);
			typeSyntax.getTerminator().setItem(segTerminator);
			typeSyntax.getTerminator().setDefaultValue("!");
			
		} catch (MDSException e) {
			
			e.printStackTrace();
		}
		
		typeTreeSource.save();
		
		typeTreeSource.close();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultLocation;
		SyntaxObjectsAsComponentsOfTypeExample target = new SyntaxObjectsAsComponentsOfTypeExample(location);
		target.run();
	}

	/**
	 * @return string value of file location
	 */
	public String getFileLocation() {
		if(_fileLocation != null && _fileLocation.equals(DefaultLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _fileLocation);
				_fileLocation = sourceFile.getAbsolutePath();
			}
		}
		return _fileLocation;
	}
	

}
