/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;

public class Example1
{
    public static void main(String[] args)
    {
        try
        {
            // this defines what resource configuration file to use
            String resCfgFile = null;

            // Initialize the API
            MMap.initializeAPI(resCfgFile);

            // Create a map 
            MMap map = new MMap("test1.mmc");

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            map.unload();
            MMap.terminateAPI();
        }
        catch( MException e )
        {
            e.printStackTrace();
        }
    }
}
