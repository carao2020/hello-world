/**********************************************************************
* IBM Confidential
*
* OCO Source Materials
*
* (C) Copyright IBM Corp. 2012  All Rights Reserved.
*
* The source code for this program is not published or otherwise  
* divested of its trade secrets, irrespective of what has been 
* deposited with the U.S. Copyright Office.
**********************************************************************/
package typetree;

import java.util.HashSet;
import java.util.Set;

import com.ibm.websphere.dtx.ds.typetree.TTType;

/**
 * This class gives an opportunity to subclasses to process every node on a given tree.
 * Sub-classes need to override {@link TTWalker#processType} to do anything useful with the nodes on the tree. 
 */
class TTWalker{
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM "
        + "(C) Copyright IBM Corp. 2012  All Rights Reserved. "
        + "US Government Users Restricted Rights - Use, duplication or "
        + "disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
	
	private boolean _walk = true;
	private Set<TTType> visitedTypes = new HashSet<TTType>();
	
	/**
	 * 
	 */
	public TTWalker(){
		super();
	}
	

	
	/**
	 * @param type type object to process
	 */
	public void walkType(TTType type){
		processType(type);
		if(visitedTypes.contains(type)) return;
		TTType nextType = null;
		nextType = type.getFirstSubType();
		if(nextType != null){
			if(_walk){
				walkType(nextType);
				
			}
		}
		nextType = type.getNextSiblingType();
		if(nextType != null){
			
			if(_walk){
				walkType(nextType);
			}
		}
		visitedTypes.add(type);
	}
	
	/**
	 * This method allows to stop processing the tree.
	 */
	public void stop(){
		_walk = false;
	}
	
	/**
	 * Process a type of the type tree
	 * 
	 * @param type the type to be processes
	 */
	public void processType(TTType type){
		//do nothing be default
	}

	
}
