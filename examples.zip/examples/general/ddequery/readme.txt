IBM WebSphere Transformation Extender 
DDEQUERY Function Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the DDEQUERY function to get 
information from an EXCEL spreadsheet.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    inv2txt.mms   -  map source file

    invtory.mtt   -  type tree

    mktprice.xls  -  Excel spreadsheet

    readme.txt    -  this readme file

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example uses the DDEQUERY function to get information from an 
EXCEL spreadsheet. 

How to run the example:

1)  Open the mktprice.xls spreadsheet.

2)  Using the Map Designer, open inv2txt.mms.

3)  Build and run the Run_Me map.

4)  Open pricelst.tmp to view the output results.

    Note:   You must have the Excel spreadsheet open when you run 
            the map.


=====================================================================
                             END OF FILE
=====================================================================
