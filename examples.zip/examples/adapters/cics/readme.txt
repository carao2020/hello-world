IBM WebSphere Transformation Extender 
CICS Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of CICS Adapter sample files.

See the CICS Adapter documemtation for complete information
on the CICS adapter.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

       dinq.mms      - Example maps
       dfh$dma.cpy   - Copybook for the dfhdma program
       dfh$dmb.cpy   - Copybook for the dfhdmb program
       dfhdma.mtt    - Type tree for the dfhdma program
       dfhdmb.mtt    - Type tree for the dfhdmb program
       blob.mtt      - Type tree with one text field
        

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example shows how to run the BMS DINQ transaction on a 
CICS host running on z/OS.

The example includes two type trees representing the dfhdma and 
dfhdmb programs. The type trees were generated using the COBOL 
Copybook Importer.

How to run the example:

The CICS adapter sends map data to a transaction running on a z/OS 
host and receives map data output. By running a sequence of maps 
which send, receive and process data, a pseudo conversation between a 
workstation and a host can be achieved.

The following adapter command line options need to be set so that you
can run the example:

    HOSTNAME  -  the hostname or IP address of your CICS host
    PORT      -  the port that the CICS Listener is running on
    UID       -  your user id
    PW        -  your password
    DT        -  the driver transaction name (check with your
                 CICS administrator)

The settings can be modified by editing the "execdma" item in the 
"execdma" output card of the "dfhdma" map.

Example1 - DINQ
---------------

dinq.mms contains two maps, "dfhdma" and "dfhdmb". Executing "dfhdma" 
will cause data provided in the "blddma" output card to be sent to 
the CICS host specified in the "execdma" output card. The respose 
will be sent to the "dfhdmb" map for processing.

The "dfhdmb" map reads the output from the CICS transaction into the 
DFHDMBO group from the dfhdmb type tree. Individual fields are 
converted to the workstations native character set and may be 
referenced in the output card.

Output
------

    Running the "dfhdma" map produces a file called out.txt which is 
    similar to the following:

    FILE INQUIRY
    000001
    IBM Corporation
    8051 Congress Ave, Boca Raton, FL
    561-862-3380
    9/26/02
    00000.01
    A MESSAGE

    PRESS ENTER TO CONTINUE

The DINQ transaction, is one of the examples supplied by IBM with 
CICS/TS 1.3. It is described in the CICS Application Programming 
Guide(SC33-1687). The COBOL copybooks were generated directly from 
the BMS source using the "aligned" option.


=====================================================================
                             END OF FILE
=====================================================================
