/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#define CHECK_ERR(rc) if(MPIRC_FAILED(rc)) 	{ printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

void StatusMethod(HMPIMAP hMap, int iEventID, int iBurstNum, int iCardNum)
{
	switch(iEventID)
	{
		case MPI_EVENT_START_INPUT:
			printf("Event received = MPI_EVENT_START_INPUT \n");
			break;
		case MPI_EVENT_INPUT_COMPLETE:
			printf("Event received = MPI_EVENT_INPUT_COMPLETE \n");
			break;
		case MPI_EVENT_START_OUTPUT:
			printf("Event received = MPI_EVENT_START_OUTPUT \n");
			break;
		case MPI_EVENT_OUTPUT_COMPLETE:
			printf("Event received = MPI_EVENT_OUTPUT_COMPLETE \n");
			break;
		case MPI_EVENT_START_BURST:
			printf("Event received = MPI_EVENT_START_BURST \n");
			break;
		case MPI_EVENT_BURST_COMPLETE:
			printf("Event received = MPI_EVENT_BURST_COMPLETE \n");
			break;
		case MPI_EVENT_START_MAP:
			printf("Event received = MPI_EVENT_START_MAP \n");
			break;
		case MPI_EVENT_MAP_COMPLETE:
			printf("Event received = MPI_EVENT_MAP_COMPLETE \n");
			break;
		default:
			printf("Unknown event !!!");

	}
}


int main()
{
	const char	*szMsg;
	int		iRC;
	size_t tlen;
	MPIRC rc;
	HMPIMAP	hMap;

	rc = mpiInitAPI(NULL);
	CHECK_ERR(rc);

	rc = mpiMapLoadFile (&hMap, "test4.mmc");
	CHECK_ERR(rc);

	rc = mpiMapRegisterStatusMethod (hMap,StatusMethod,MPI_EVENT_ALL);
	CHECK_ERR(rc);

	rc = mpiMapRun (hMap);
	CHECK_ERR(rc);

	rc = mpiPropertyGetText (hMap, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, &tlen);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);

	rc = mpiMapUnload (hMap);
	CHECK_ERR(rc);
	rc = mpiTermAPI();
	CHECK_ERR(rc);
	return 0;
}
