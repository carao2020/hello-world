/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
using System;
using System.Text;
using System.IO;
using com.ibm.websphere.dtx.dtxpi.dtxinterop;

namespace com.ibm.websphere.dtx.dtxpi.example
{
	/// <summary>
	/// This example loads a map from a byte arry
	/// </summary>
	public class Example6
	{
		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				MFactoryClass imFactory = new MFactoryClass();
				imFactory.InitializeAPI(null);

				// Load a local map file
				FileStream fis = new FileStream("test6.mmc", FileMode.Open, FileAccess.Read);
				int fileSize = (int)fis.Length;
				byte[] mapData = new byte[fileSize];
				fis.Read(mapData, 0, fileSize);
				fis.Close();

				// Create a map 
				MMap map = imFactory.MapLoadMemory("test6", null, mapData, fileSize);
				MCard card = map.GetInputCard(1);
				// Override the adapter in input card #1 to be a stream 
				card.OverrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

				// Read the local data file
				fis = new FileStream("input.txt", FileMode.Open, FileAccess.Read);
				byte[] inputData = new byte[fis.Length];
				fis.Read(inputData, 0, (int) fis.Length );
				fis.Close();

				// Get the handle to the stream object 
				MAdapter adapter = card.GetAdapter();
				MStream stream = adapter.GetOutputStream();
				// Send a single large page 
				stream.Write(inputData, inputData.Length);

				// Get the adapter object handle for output card #2
				card = map.GetOutputCard(1);
				// Override the adapter in output card #2 to be a stream 
				card.OverrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);
				// Run the map		
				map.Run();

				// Get the return status
				string responseMessage = map.GetTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
				int resuleCode = map.GetIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
				Console.Out.WriteLine("Map Status: " + responseMessage + " " + resuleCode);
				// Get the adapter object handle for output card #2
				adapter = card.GetAdapter();
				stream = adapter.GetInputStream();
				// Get the data in pieces from the stream 
				stream.Seek(0, MConstants.MPI_SEEK_SET);

				IMStreamPage page;
				object returnValue;
				Byte[] outputByteArray;
				char[] chars;
				Decoder decoder = Encoding.UTF8.GetDecoder();
				while( true ) {
					int bIsEnd = stream.IsEnd();
					// Clean and Break
					if( bIsEnd == 1) {
						stream.SetSize(0);
						break;
					}
					page = stream.ReadPage();
					page.GetData(false, out returnValue);
					outputByteArray = (Byte[]) returnValue;
					chars = new char[outputByteArray.Length];
					decoder.GetChars(outputByteArray, 0, outputByteArray.Length, chars, 0);
					Console.WriteLine(chars);
				}

				// Unload the Map 
				map.MapUnload();	      
				// Exit the API 
				imFactory.TerminateAPI();
			}
			catch (Exception e)
			{          
				Console.Out.WriteLine("Error Description: "+e);
			}
		}
	}
}
