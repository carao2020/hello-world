IBM WebSphere Transformation Extender 
XML Examples Readme


� Copyright International Business Machines Corporation 2006, 2010.
All Rights Reserved.


This readme file contains descriptions of two XML examples that are 
included in the product installation. One is the XML to EDI example
and the other is the XML Importer example.

The XML to EDI example demonstrates the usage of maps for an XML 
purchase order document transformation to an ANSI EDI Interchange. 

The XML Importer example demonstrates the usage of validation maps 
for an XML purchase order document. 

=====================================================================
CONTENTS
=====================================================================

    1.  XML to EDI Example
        - Files
        - Using
    2.  XML Importer Example
        - Files
        - Using


=====================================================================
1: XML to EDI EXAMPLE
=====================================================================

FILES
-----

Files included in this example:

       po_xml.mtt      type trees
       po4010.mtt

       xml2edi.mms     map source file

       podata.dtd      DTD

       poin.xml        input file

       readme.txt      this file


USING
-----

This example maps an XML purchase order document to an ANSI EDI 
Interchange.

The purchase order (PO) data in the XML document is defined in the 
po_xml.mtt type tree. The interchange is defined in the po4010.mtt 
type tree. The podata.dtd DTD is in the folder for xml examples, 
located under install_dir\examples.

The XML DTD Importer can be run using the podata.dtd file as input. 
It produced the po_xml.mtt tree that is in the folder for xml 
examples, located under install_dir\examples.

To run the example:

1) In the Type Designer, import podata.dtd using the XML DTD 
   importer.

   It creates the podata.mtt type tree that will have to be renamed
   as po_xml.mtt.

2) In the Map Designer, open xml2edi.mms. 

   The executable map is "xml2edi2".
   
   There is one input card:
   
   "PO_XML" - This card represents the input XML document and
              references the type tree created in step 1 using the 
              XML DTD Importer.
       
   There is one output card:
   
   "X12_PO" - This card represents the EDI X12 purchase order that
              the map will produce.

3) Build and Run "xml2edi2".

   The map generates the following output data:

   Ouput Card 1 ("X12_PO") - x12po.dat



=====================================================================
2: XML IMPORTER EXAMPLE
=====================================================================

FILES
-----

Files included in this example:

       ipo.mtt          type tree

       ipo.mms          map source file

       address.xsd      XML Schema files
       ipo.xsd

       ipo.in.xml       input file

       readme.txt       this file


USING
-----

This example uses a validation map for an XML type tree.

The purchase order (PO) data in the XML document is defined in the 
ipo.mtt type tree. The address.xsd and ipo.xsd XML Schema files are 
in the folder for xml examples, located under install_dir\examples.

The XML Schema Importer can be run using the ipo.xsd file as input. 
It produced the ipo.mtt tree that is in the folder for xml examples,
located under install_dir\examples.

To run the example:

1) In the Type Designer, use the XML Schema importer to import the 
   ipo.xsd schema file.

   It creates the ipo.mtt type tree.

2) In the Map Designer. open the ipo.mms map source file. 

   The executable map is "validationMap".

   There is one input card:

   "Input" - This card represents the input XML document and
             references the type tree created in step 1 using the XML
             Schema Importer.

   There is one output card:

   "Output" - This card represents the output XML document that the
              map will produce.

3) Open the Edit Output Card dialog box and set the value of 
   Schema > Type > Name Spaces > http://www.example.com/IPO to 
   "ipo-out".

4) Build and run "validationMap".

   The map generates the following output data:

   Ouput Card 1 ("Output") - ipo.out.xml

=====================================================================
                             END OF FILE
=====================================================================
