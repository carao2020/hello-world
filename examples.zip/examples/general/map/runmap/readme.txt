IBM WebSphere Transformation Extender 
Run Map Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Run Map.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    allemps.txt
    employee.txt
    readme.txt  (this readme file)
    runmap.mms
    runmap.mtt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example will use the callmap to select an employee's timesheet 
out of the allemps.txt file, based on which employee name is located 
in the employee.txt file. It will then return the employee's name and 
the total number of hours that employee worked for the week. 

The total number of hours is determined by passing the information 
to a run map called gethours.

How to run the example:

1)  Using the Map Designer, open runmap.mms.  
    There are two maps inside:
    a)  callmap - This map calls the gethours map using a RUN 
                  function.
    b)  gethours - This map calculates out the hours worked for the 
                   week and returns the result to the RUN function in 
                   callmap.
        
        Note: A Run Map is different from a Functional Map because
              it must have a source for the inbound cards, and a 
              target for the outbound cards.

2)  Look at the RUN function in the total_hours element field of the
    outbound card in callmap.
    a)  RUN - This function passes information to a new map for 
              processing. This can be very useful when the output 
              type is different than the input type of the receiving 
              map, even though the data layout is the same.
    b)  ECHOIN - This passes a TEXT Blob of information to the RUN 
                 Map.
    c)  VALID - This verifies that the RUN Function worked properly.
    d)  FAIL - If the RUN Function failed, the FAIL Function will 
               place a message of your choosing in the Audit Log.

3)  Build and run callmap.  
    A "Fail function aborted map" message is displayed.

4)  View the Audit Log (callmap.log).
    a)  The following is displayed in the log file: 
        FAIL function aborted map:gethours.mmc 
        failed with Could not open map
    b)  The reason why it could not open the Run Map (gethours) is 
        because the Run Map being called must have an associated 
        compiled map (gethours.mmc).

5)  Build the gethours map.

6)  Run the callmap again and view your output.
    a)  The following outbound data is generated:
       "Work A.             |Holic               |90.45"

7)  For additional practice, you can look up other names in the 
    allemps.txt file and place them in the employee.txt file.


=====================================================================
                             END OF FILE
=====================================================================
