IBM WebSphere Transformation Extender 
Microsoft Message Queue (MSMQ) Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008. 
All Rights Reserved.


This example demonstrates the usage of the Microsoft Message Queue 
(MSMQ) Adapter sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    msmq_in.mtt
    msmq_out.mtt
    msmq_out_extended.mtt
    msmq.mms
    file_in.mtt
    filein1.txt
    filein2.txt
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example provides types describing different MSMQ message 
properties so you can easily select the message types needed for 
input or output cards used in the Map Designer. Use a type tree that 
is appropriate for the data source. If the Header adapter command 
(-HDR)is not specified, the type tree representing the MSMQ message
properties should not be used. The sample type tree (msmq_in.mtt)
should be used as a guide when creating new type trees to facilitate
mapping of individual properties. This type tree is set up to receive
or set all properties and uses property names as identifiers to
partition them into proper type groups. When setting or receiving
individual message properties, the type tree must define these
properties exactly.. 

How to run the example:

The msmq.mms file contains seven maps that show how the MSMQ adapter
works. Open msmq.mms in the Map Designer and you will see seven map
names in the left pane of the main window. To switch between maps,
double-click on name of the map to which you want to switch.


map1
----

The content of filein1.txt (input card) maps to the message
on the .\queue1 queue (output card). This map specifies the
following adapter command for the output card:

    -QN .\queue1 -HDR -T

This command specifies that the data from the input card should be
delivered as a message to the .\queue1 queue. The Header adapter
command (-HDR) specifies inclusion of message header properties other
than the body of the message. These properties are LABEL and
CORRELATION ID (CID). The Trace adapter command (-T) activates the
adapter trace function to track function calls and to store them in a
trace log file. (The default log file name is msmqtrace.log.)

Before you run the map, be sure that either the ./queue1
transactional queue already exists or change the queue name in
adapter command to some existing transactional queue. Purge the queue
before you run the map.

If you look at the output card, notice that a message will have the
input file for the content(body). It will also have label 'LabelA'
and cid 'CIDA'.

Run the map and use MSMQ Explorer to check the content of the
.\queue1 queue. You should be able to see that the queue now contains
a message labeled LabelA, with the following message body:

    This sentence is a 46 bytes long message body.

Change the values in the adapter command of the output card to be
LabelB and CIDB and run the map again. After that, two messages will
appear on the queue:

    LabelA             - the old one
    LabelB             - the new one


map2
----

map2 maps a message from the .\queue1 queue to both the .\queue2
queue and a file named fileout.txt. Suppose that the map1 was
previously executed and that we have two messages on the .\queue1
queue1 as shown below:

    label = LabelA, cid = CIDA
    label = LabelB, cid = CIDB

The adapter command for the input card is:

    -QN .\queue1 -LABEL LabelB -CID CIDB -HDR -T -LSN 5

This adapter command requests that the adapter find a message on the
.\queue1 queue (-QN .\queue1) that has label LabelB (-LABEL LabelB)
and correlation id CIDB (-CID CIDB). The adapter will receive all
message properties. In addition to the body (-HDR), it will track its
function calls (-T) and it will wait not more than five seconds (-LSN
5) for a message to arrive if it is not already on the queue.

On the output side of the map are two cards. The first card specifies
the fileout.txt file. The second card specifies another MSMQ queue:
.\queue2. The map specifies that all operations on the .\queue queue
(input card) will belong to the transaction with a map scope
(OnFailure = Rollback, Scope = Map) and that operations on the
.\queue2 queue will not be in any transaction (OnFailure = Commit).

This means that the .\queue2 queue can be a non-transactional queue.

Notice that the input card has an option (OnSuccess = Keep), which
means that a copy of the message will remain on the source queue
(.\queue1).

Run the map. Use MSMQ Explorer to check the content of the .\queue2
queue. The message with the LabelB label is there. Both messages are
still on the .\queue1 queue.

Looking at the fileout.txt output file, notice that it contains the
body of the received message.

Change the adapter command of the input card to:

    -QN .\queue1 -LABEL LabelA -HDR -T -LSN 5

Run the map.

The (LabelA, CIDA) message will be copied to the .\queue2 queue.


map3
----

map3 shows how to use the PUT() function to place multiple messages
on the queue. On the input side, the FileIn2.txt text file has the
following structure:

    This is Message 001
    This is Message 002
    This is Message 003
    .
    .
    .
    This is Message 099
    This is Message 100

map3 will use these 100 strings to create 100 messages on the 
.\queue1 queue. These messages should have the labels Label001,
Label002,...,Label100.

The output card specifies the Sink AdapterTarget, indicating that
there is no target. The Map Designer will execute the PUT() function
for each appearance of the object 'Body:TextFile', that is, it will
execute the PUT() function 100 times, once for each message. The Map
Designer will call the MSMQ Adapter, which is specified as the first
argument of the function "msmq".

The adapter command will be:

    "-QN .\queue1 -T -LABEL Test" + RIGHT(TEXT(Body:TextFile), 3)

The RIGHT() function takes the three right-most characters of its
string argument. These are "001", "002", ... , "100".

This means that for the first input string "This is Message 001", the
adapter command will be "-QN .\queue1 -T -LABEL Test001". For the
last message, the adapter command will be "-QN .\queue1 -T -LABEL
Test100".

The third parameter specifies that which is passed as a data(message)
to the adapter. Note that the adapter command does not have a Header
adapter command (-HDR) specified, which means that all data passed to
the adapter should be treated as message bodies.

"<BODY><CR><LF>" is an initiator for the message body passed to
the adapter; "</BODY><CR><LF>" is the terminator.

<CR> is the carriage return character. It is obtained by using the
function call SYMBOL(13) because 13 is an ASCII code for the carriage
return character.

<LF> is the line feed character. It is obtained by using the function
call SYMBOL(10) because 10 is an ASCII code for the line feed
character. We must use the SYMBOL function because <CR> and <LF> are
not printable characters.

Purge the .\queue1 queue and run the map. Check the content of
.\queue1. It will have 100 different messages.


map4
----

map4 uses burst mode to map multiple messages from one queue to
another. It will transfer 10 messages from the .\queue1 queue to the
.\queue2 queue.

The option OnSuccess=Delete is specified for the input card. This
means that after being received, messages from the input queue will
be removed from it. Burst mode is also specified (CardMode=Burst).
The adapter command for the input card is:

    -QN .\queue1 -HDR -QTY 10 -LSN 3 -T

-QTY 10 means that ten messages should be taken from the .\queue1
queue.

FetchUnit=1 in the card options means that one message will be taken
per burst.

Before you run this map, .\queue1 should contain at least 10 
messages. (Run map3 to put 100 messages on it.)

Run the map.

Ten messages are transferred from .\queue1 to .\queue2.


map5
----

map5 introduces some new features including the ability to get more
than one message per burst and using the PUT() function to call
adapter functions.

This map will attempt to map 105 messages from the .\queue1 queue to
the .\queue2 queue. The GET > Source input card is MSMQ, but the
output card PUT > Target is Sink, which is actually an empty output.

The Map Designer only executes the PUT() function on exit for each
appearance of the MessageContainer object on the input side. The
MessageContainer contains one message, along with its Initiator
(<MESSAGE><CR><LF>) and Terminator(</MESSAGE><CR><LF>). These are the
initiators(terminators) for messages with more than one property. We
already saw that messages with only body (content) have an initiator
of <BODY><CR><LF> and a terminator of </BODY><CR><LF>.

The adapter command for the input card is:

    -QN .\queue1 -HDR -QTY 105 -LSN 3 -T

This command specifies that the adapter should take 105 messages
(-QTY 105) from the .\queue1 queue (-QN .\queue1), but not to wait
more than three seconds (-LSN 3) in total. Take all properties of the
messages (-HDR) and track its own function calls in the m4msmq.log
file.

The PUT() function for the output card has following argument values:

    =PUT(   "msmq", "-QN .\queue2 -T -LABEL " + ...

This means to use the MSMQ adapter (msmq). For each appearance of the
MessageContanier object, call the adapter function with the following
adapter command: -QN .\queue2 -T -LABEL .

Attempt to run the map when the queue .\queue1 queue is empty.
Because there are no messages on the .\queue1 queue, the adapter will
wait for three seconds. After that, it will issue a warning. Because
the Transaction > Warnings map setting is set to Fail for the input
card, this warning will cause the map to fail with the message
"Source not available". If you specify Transaction > Warnings =
Ignore, the map will execute successfully.

FetchUnit = 10 which means that the adapter will get ten messages per
burst.

Suppose that we have 100 messages on the .\queue1 queue. (This can be
done with map3).

Run the map.

The adapter will get ten messages, ten times. These 100 messages will
be placed on the .\queue2 queue. The adapter will try to get five
more messages after that to fulfill the request of 105 messages in
total (-QTY 105). But because there are no more messages on the
.\queue1 queue, the adapter will wait three seconds (-LSN 3) and then
it will give up. But, this time, the warning is not issued. The map
successfully completes, but only 100 messages are placed on the
.\queue2 queue.


map6
----

map 6 describes the use of response, administration, and dead
letter queues. To run map6, you must have three queues:
queue1, queue2, and queue3. Note that queue1 and queue2 are
transactional queues and queue3 is a non-transactional queue.

On the input side, map6 gets a file; on the output side, the map
stores a message to queue1, using input file as a message body.

The label of the message is set to "MyLabel" and the correlation id
of the message is set to "MyCID". The output card uses the
msmq_out_extended type tree, which is the extended msmq_out type tree
previously used.

First, look at the PROPID_M_TIME_TO_REACH_QUEUE property. Its value
is set to 5 which means that the maximum length of time for a message
to reach the destination queue is set to 5 seconds. The
PROPID_M_TIME_TO_BE_RECEIVED property has a value of 50 which means
that the maximum length of time for a message to be received from the
destination queue is 50 seconds.

A message can stay on the destination queue for not more than 50
seconds. If the message does not arrive at the destination queue
(queue1) during the PROPID_M_TIME_TO_REACH_QUEUE-specified time or if
it arrives, but is not taken from the destination queue in the
PROPID_M_TIME_TO_BE_RECEIVED-specified time, some action needs to be
taken. This action is specified using the PROPID_M_ACKNOWLEDGE and
PROPID_M_ADMIN_QUEUE properties.

The PROPID_M_ACKNOWLEDGE property specifies the type of notification
we want to receive. In this example, the PROPID_M_ACKNOWLEDGE
property value is set to 8, which is a value of the
MQMSG_ACKNOWLEDGMENT_ NACK_RECEIVE symbolic constant. This means that
we want to be notified only when the message is NOT received in the
specified time (as specified in the PROPID_M_TIME_TO_BE_RECEIVED
property).

How do we get notified? MSMQ is sending a notification message to the
queue entitled administration queue. It is up to the user to specify
the queue to be used as the administration queue. The administration
queue must be a non-transactional queue. In this case, the queue3
queue is specified as an administration queue.

There is another property used in this type tree for the message:
PROPID_M_JOURNAL. Its value specifies whether the message should be
kept in a machine journal queue (on the originating machine), sent to
a dead letter queue, or neither.

The machine journal queue has a predefined name "Journal" and is
created by MSMQ on each machine that is added to the MSMQ enterprise.
There are also queue journal queues that MSMQ creates for each new
queue. Journal queues are used to track sent messages and to store
report messages from MSMQ. Dead letter queues are used to store
messages that cannot be delivered to the destination queue. A value
of 1 has been specified for PROPID_M_JOURNAL, which is a value of the
MQMSG_DEADLETTER constant. This means that we want undelivered
messages to be placed upon the dead letter queue. MSMQ has two dead
letter queues: one is for transactional messages (messages that are
sent to a transactional queue) and one is for non-transactional
messages (messages that are sent to a non-transactional queue). Each
transactional dead letter queue has a predefined name: "Xact Dead
Letter" (for the transactional queue) and "Dead Letter" (for the
non-transactional dead letter queue).

Finally, the last property used in this type tree is
PROPID_M_RESP_QUEUE. It is used to tell the receiving application
that it is supposed to send a response message to the queue defined
through this property. In this case, it is the queue2 queue. The
response queue can be either transactional or non-transactional.

Before you run the map, you must create queue1, queue2, and queue3.
For clarity, you should purge these queues, as well as
"Xact Dead Letter". Run the map.

The message will be placed to the queue1 queue. If you go to the
Enterprise Manager quickly enough, you will see the MyLabel message
on the queue1 queue. If you right-click on the message and select
Properties, you will see that the administration queue for this
message is queue3 and that the response queue is queue2. After some
time, the message will disappear from the queue. Because it was not
received in fifty seconds (as specified in
PROPID_M_TIME_TO_BE_RECEIVED), MSMQ will perform the action we
specified. This means that it will put the message onto the Xact Dead
Letter queue (because the queue1 destination is transactional). If
you right-click on this message in Xact Dead Letter queue, notice
that the value of class property is "Time to be received expired".
Because we also specified the administration queue, a copy of the
MyLabel message will be placed upon the queue3 administration queue
as well.


map7
----

map7 explains how a map can be used to read messages from dead letter
queues. After map6 has run, the MyLabel message has been placed upon
the Xact Dead Letter queue. map7 takes the message from this queue
and stores its body to the filexact.txt output file. You must execute
map6 before running map7.

Similar to any other queue, dead letter queues are specified in
adapter commands using the Queue Name adapter command (-QN). However,
dead letter queues have a special naming convention. Each machine can
have only one transactional dead letter queue and one
non-transactional dead letter queue.

The transactional dead letter queue is specified as: -QN
machine_name;DEADXACT (or -QN .;DEADXACT for the local machine)

The non-transactional dead letter queue is specified as:   -QN
machine_name;DEADLETTER (or -QN .;DEADLETTER for the local machine)

Run the map. It will get a message from the Xact Dead Letter queue
and store it in the filexact.txt file. Because the output card has
the OnSuccess option set to Delete, the message will be removed from
the dead letter queue after it has been received.



=====================================================================
                             END OF FILE
=====================================================================
