IBM WebSphere Transformation Extender 
Map Designer Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the MapImportExport utility.  

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    modifymapscript.mms  - Map source files 
    origmap.mms      

    lmf.mtt              - Type trees     
    mapimportexport.mtt 
    mapsettingsconfig.mtt   
    mtn96_2002.mtt


    mapset.txt           - contains the new map settings

    mtn96.txt            - input file in the origmap.mms in the 
                            In_MTn96_Common card

    readme.txt           - this readme file

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example demonstrates one use for the MapImportExport utility. 
This utility allows you to represent map source in an XML format. 

For ease of description in this example, this representation is 
called Map Script. In its simplest form, you can take a map created
in the Map Designer and EXPORT the map (re-represent it in XML 
syntax) to a file. That same file can be IMPORTED back into the Map 
Designer and used as a map. 

This functionality has many uses. One application is to make global 
changes to a map system. In many cases this will be quicker, easier,
and less error-prone than making many changes manually. 

In this example you want to change all Trace map setting switches in 
a particular map, and change all Audit switches to OFF. Without the 
MapImportExport utility, you would open each map and manually change 
each switch setting. This is a common task that is performed after 
map testing and before a map is placed in a production environment. 

There are three maps in this example:

1)  - The original map is a SWIFT n96 to XML (LMF) transformation.

2)  - The map that transforms the original map to the new map by 
      applying the new switch settings. A configurtion file is used 
      to hold the new switch settings.

3)  - The new map with the desired TRACE and AUDIT settings.

How to run the example:

1)  Using the Map Designer, open the original map source file: 
    origmap.mms.

    You will notice that there are many maps with the Audit and Trace 
    switched ON.

2)  From the Map menu, select 'Export to XML' and export the map to file 
    origmap.xml using file type XML. The resulting map source file will 
    be named origmap.xml.

3)  Verify that the new map settings to be applied are correct by    
    opening the mapset.txt file. It should have two entries:

    TRACE=OFF
    AUDIT=OFF

4)  Open the map source modifymapscript.mms.

5)  Build and Run the executable map mapset. 
   
    This map will modify the map script origmap.xml using the 
    MapSettings specified in mapset.txt and generate a new 
    map script newmap.xml.
   
6)  Using the Map Designer, import the new map script into a new map: 
   
    Select File > Import > Transformation Extender > Map From XML
    Browse to the folder containing the map import export example and select the new 
    map script file (newmap.xml) and select to import it into your current project.
   
7)  Open the new map newmap.mms in your project. 

    Notice that the only difference between the origmap source and 
    the newmap source is that all of the Audit and Trace switches are 
    OFF in the newmap.


=====================================================================
                             END OF FILE
=====================================================================
