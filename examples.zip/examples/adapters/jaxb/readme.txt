IBM WebSphere Transformation Extender 
JAXB Adapter Example Readme


(c) Copyright International Business Machines Corporation 2013
All Rights Reserved.


This example demonstrates the usage of the JAXB Adapter sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    sample.mms    	-  Map file
    blob.mtt         	-  Type tree for reading a blob data
    input.xsd        	-  Schema representing the Sample class
    readme.txt          -  Readme file for the JAXB adapter example
    setenv.bat(sh)	-  Batch (Script file) to setup the environment
    make.bat(sh)	-  Batch (Script file) to generate sample.jar   
    run.bat(sh)		-  Batch (Script file) to invoke WTX map from Application Progamming API                          

Note: All the listed .class files can be generated from the
      corresponding .java files using the Java Compiler (javac). 
      

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example explains the main concepts of the JAXB adapter,
such as using JAXB adapter as input adapter or output adapter or in a
GET or PUT functions.

The example uses simple java POJO and a schema file to demostrate the
capability.

Before running the examples verify that all the listed class files
are in a directory that is included in the CLASSPATH.

Steps to run the maps in Design Studio and using WTX JAVA API

1) Edit the make.bat(sh), run.bat(sh) file and update JAVA_HOME and DTXHMOME directory

2) Run the batch file (script file on non-windows).
	The batch file generated a sample.jar file.

3) Add the jar file in to WTX classpath
	a) Drop in a WTX install directory on windows or libs directory on UNIX for standalone deployments
	b) For integration deployments please follow the host application instructions to add to the CLASSPATH
	

4) Open sample.mms in the WTX Map Designer.

There are five defined maps in sample.mms:

 - jaxb_run
 - jaxb_xml
 - jaxb_xml_get
 - xml_jaxb
 - xml_jaxb_put

5) Build all the maps in the source file


6) Run the maps in the following order

	a) xml_jaxb - generates a java serialized object (output.ser)
	b) jaxb_run - reads a file and generates a XML document through file adapter
	c) jaxb_xml_get - uses WTX get function to get access to a file
	d) xml_jaxb_put - used a WTX put function to write a file

7) Edit the run.bat(sh), and update DTXHMOME directory
	
8) Invoke run.bat (sh) to run map transformations using WTX Java Application Programming. 
	a) The map should run successfully and generate a output.xml file in the map directory


=====================================================================
                             END OF FILE
=====================================================================
