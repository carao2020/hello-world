IBM WebSphere Transformation Extender 
WebSphere DataPower Map Example Readme


� Copyright International Business Machines Corporation 2007-2012.
All Rights Reserved.


This example demonstrates how to test a WebSphere DataPower map 
on a WebSphere DataPower SOA Appliance from the Map Designer. 

To learn more about WebSphere DataPower SOA Appliances, go to:

    www.ibm.com/software/integration/datapower


=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

        Contact.txt
        readme.txt  (this readme file)
        Mail.mms
        Contact.mtt
        Label.mtt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example map takes comma-separated contact information from
a text file and generates a mailing label from it.

When you run a WebSphere DataPower map in the Map Designer, the 
compiled map, and input files are attached to a request message that 
is sent to the WebSphere DataPower SOA Appliance for the 
Interoperability Test Service. After processing has completed, a 
response message is returned with the output and audit log files.

If you built a map to be run on a WebSphere DataPower SOA Appliance, 
to test it from the Map Designer, the Interoperability Test Service
must be running on the appliance.

To use this example, you must provide connection information for 
your WebSphere DataPower SOA Appliance.


How to run the example map:

1)  Using the Map Designer, open Mail.mms. It contains the
    ContactToLabel WebSphere DataPower map.

2)  Click Window > Preferences > Transformation Extender > Map > 
    DataPower. The DataPower preferences pane opens. 

3)  Under Connectivity, enter the Host or IP Address information. 

4)  Click the Interoperability Test Service tab and enter the port 
    information to connect to the appliance using HTTP.
    
    To connect to the appliance using HTTPS, select Secure Transport. 
    
    To generate a map audit log, specify an audit context name in  
    the WTX Audit Log field. 
    
    To support map warnings on the appliance, select Support 
    WTX Warnings. 

    To save the request, response and session messages, select 
    the required Request, Response and Session options.

5)  In the Outline view, select the ContactToLabel map, and on the 
    Map menu, click Build.  
    
    If map build errors occur, open the Organizer folder and 
    double-click the Build Results element. The Build Results view 
    opens and you can view the build errors.

6)  In the Outline view, select the ContactToLabel map, and on the 
    Map menu, click Run. 

    If map run errors occur, open the Organizer folder, and 
    double-click the Session element. The Session view opens and you 
    can view the DataPower Session errors, if you selected the 
    Session option. 

7)  On the Map menu, click View Run Results. 
    The Run Results window opens. 

8)  Select the items you want to view and click OK. 
    The results are displayed. Review the input and output to 
    confirm that the label was created correctly. 


For information about using a DataPower appliance with the Map 
Designer, specific instructions about how to run WebSphere 
DataPower maps locally, and how to deploy them to a WebSphere 
DataPower appliance, see the Map Designer documentation. 


=====================================================================
                             END OF FILE
=====================================================================
