IBM WebSphere Transformation Extender eInvoicing Example


� Copyright IBM Corporation 2011. All Rights Reserved.


=====================================================================
CONTENTS
=====================================================================

   1.  Overview
   2.  What this example contains
   3.  Running this example from IBM WebSphere Transformation Extender
   4.  Running this example from Sterling B2B Integrator
   5.  Other Notes

=====================================================================
1. OVERVIEW
=====================================================================

This example provides an IBM� WebSphere� Transformation Extender 
translation map that can be used within the eInvoicing process 
of IBM Sterling B2B Integrator (SI).

The example map transforms an interchange containing one or more
X12 810 invoice transactions to an XML format file that can be used
by the Sterling eInvoicing process.

The output XML data includes a special <ERROR_COUNT> element, which
tells the eInvoicing process whether there are any errors in the
remainder of the <EINV_CANONICAL> element.  This example uses some
special techniques to set this value correctly.  These techniques
are described in the "Other Notes" section of this readme file.

=====================================================================
2. WHAT THIS EXAMPLE CONTAINS
=====================================================================

In addition to this readme file, this example contains the following
files:

- X12_810_To_Canonical_ERROR.mms - Contains the source map 
  X12_810_To_Canonical_Error.  This map translates the X12 810
  invoices to XML data.

- ansi4040-pruned.mtt - Metadata that describes the format of the
  X12 810 invoices.  This is a subset of the ansi4040 type tree
  that is included in the WebSphere Transformation Extender Pack
  for X12.
			
- eInvoiceCanonicals.mtt - Metadata that describes the format of
  the XML output file. This was created by importing the 
  eInvoiceCanonicals.xsd XML schema.
  
- eInvoiceCanonicals.xsd - XML schema that describes the format of
  the XML output file. 
  
- eInvoiceCanonical.xsd - XML schema that is referenced by the
  eInvoiceCanonicals.xsd.  This schema is also used to validate
  an individual <EINV_CANONICAL> element.
 
- sample_input.txt - Input file containing the sample X12 810
  invoices.  


=====================================================================
3. RUNNING THIS EXAMPLE FROM IBM WEBSPHERE TRANSFORMATION EXTENDER
=====================================================================

1. Open the X12_810_To_Canonical_ERROR.mms source map in WTX Design
   Studio.

2. Build the X12_810_To_Canonical_Error map.  Some warnings may occur.

3. Run the X12_810_To_Canonical_Error map in Design Studio.

3. The map creates output file out.xml.  This file contains an XML
   document, which includes:
   - Root element: <eInvoiceCanonicals>
   - Six <EINV_CANONICAL> elements
   - Each <EINV_CANONICAL> element contains an <ERROR_COUNT> element.
     One of the six <ERROR_COUNT> values will have a value of 1, and
     the rest will have a value of 0.


=====================================================================
4. RUNNING THIS EXAMPLE FROM STERLING B2B INTEGRATOR
=====================================================================

When running as part of the eInvoicing process, this example would
run within the Translation service. The steps to configure and run
this example as part of the eInvoicing process are beyond the scope
of this readme file.  

For more information about the eInvoicing process, including setup
and configuration, refer to the Sterling B2B Integrator documentation.
For more information about deploying and running a WTX map
in the Translation service of Sterling B2B Integrator, see the
Translation service example that is included with this product.

=====================================================================
5.  OTHER NOTES
=====================================================================

SETTING THE <ERROR_COUNT> ELEMENT:
----------------------------------
 
The <ERROR_COUNT> element value is set to 0 or 1 to indicate whether
<EINV_CANONICAL> element is valid or not.  To set this correctly,
this example maps the data in two steps:

1) Map each X12 810 invoice to the <EINV_CANONICAL> element, without
   specifying the <ERROR_COUNT>.
   
   This step is done in the first output card, simply named "XML".
   The F_EachTransaction does this EDI->XML mapping for each 
   transaction.  In this example, it forces an error in the XML 
   output by setting the <SUPP_COMM_CRED> element value to NONE if
   the BIG02 element of the input transaction has a specific value.
   This forced error helps to demonstrate the XML validation
   performed in the second step.  Normally, the map would not
   intentionally create XML errors.
   
   The output from this card goes to "Sink" by default, so it is not
   written to a file. However, this output is used by output card 2.
   
2) Copy each <EINV_CANONICAL> element, and set the <ERROR_COUNT>
   value to the appropriate value.
   
   This step is done in the second output card, named 
   XML_WITH_ERROR_COUNT.  For each <EINV_CANONICAL> element
   in output card 1, the F_EachEINV_CANONICAL functional map is
   called.  Each time, the <EINV_CANONICAL> is passed, along with
   a flag (0 or 1) that indicates whether the element is valid.
   Then the F_EachEINV_CANONICAL map uses this flag to set the 
   <ERROR_COUNT> value.
   
   The mapping function xmllib->VALIDATE() is used to determine
   whether the <EINV_CANONICAL> element is valid or not.  The map
   rule to call this function also:
   - Adds the xmlns attribute to the <EINV_CANONICAL> element.
     This is required for the data to validate correctly against the
     schema.
   - Specifies the schema, eInvoiceCanonical.xsd, that the data will
     be validated against for the given namespace.
   - Converts the 0 or -1 returned by the xmllib->VALIDATE() function
     to a 0 or 1, as expected by the eInvoicing process.
	 
	 