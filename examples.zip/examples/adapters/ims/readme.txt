IBM WebSphere Transformation Extender 
IMS TM Resource Adapter Example Readme


(c) Copyright International Business Machines Corporation 2008.
All Rights Reserved.


This example demonstrates the usage of IMS TM Resource Adapter 
sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

File included in this example:
        
        Ex01.cpy	cobol file
 	Ex01x.mtt	type tree based on Ex01.cpy
        PhoneBook.mms	example map
        simple.mtt	type tree 
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains basic maps to connect to IMS using the PhoneBook 
example.  

DoPut - Map does a put operation to add an entry to the Phonebook

DoGet - Map does a get from a map rule to display an entry from the 
Phonebook. OUtput card PrepareData is fed into the get rule in output 
card DOit, which calls RunMap. Out.txt file is created with output 
from the display command passed to the IMS host.

QueueItUp - Map puts entry on IMS queue

InputCard - Map read entry from IMS queue and returns as EBCDIC to 
out.txt file

FileRead - Map converts EBCDIC data to ascii out.txt file for 
readability purposes.



=====================================================================
                             END OF FILE
=====================================================================
