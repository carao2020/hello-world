IBM WebSphere Transformation Extender 
Parsing Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of burst option. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example

=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    parsewds.txt  - input file

    readme.txt    - this readme file

    words.mms     - map source file

    words.mtt     - type tree


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example shows a simple use of the burst option. 

In this example, the requirement is to parse a blob of text data into
a minimum line of 67 characters to a maximum line of 73 characters. 

In the parsewds map, there is one input file (parsewds.txt). The 
contents are defined in the words.mtt type tree. The clue to the 
solution is the component rule for the Word object.

How to run the example:

1)  Using the Map Designer, open words.mms.

2)  Build and run the parsewds map.

3)  View the parsed output file (lines.txt) in the map 
    directory: install_dir\examples\general\burst\parsewds


=====================================================================
                             END OF FILE
=====================================================================
