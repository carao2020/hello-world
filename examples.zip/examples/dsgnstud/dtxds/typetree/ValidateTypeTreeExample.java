package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.ibm.websphere.dtx.ds.typetree.TTConstants;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTValidateResults;
import com.ibm.websphere.dtx.ds.typetree.TTValidator;

/**
 * This example demonstrates how validate a type tree.
 * 
 *
 */
public class ValidateTypeTreeExample {
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";
	
	private static String DefaultLocation = "files/example.mtt";
	private String _fileLocation = DefaultLocation;
	
	// for testing
	private List<TTValidateResults> _validateResults = new ArrayList<TTValidateResults>();
	
	/**
	 * @param fileLocation
	 */
	public ValidateTypeTreeExample(String fileLocation) {
		super();
		_fileLocation = fileLocation;
	}

	/**
	 * This method runs the example
	 */
	public void run(){
		
		TTSource typeTreeSource = TTSource.openTypeTree(getFileLocation());
		if(typeTreeSource == null){
			System.out.println("Can not open type tree from location: " + getFileLocation());
			return;
		}
		TTValidator validator = new TTValidator();
		
		if(validator.validateTypeTree(typeTreeSource, TTConstants.CHECK_TYPE.CHECK_BOTH)){
			System.out.println("File " + getFileLocation() + " validated successfully!");
		}
		else{
			System.out.println("File " + getFileLocation() + " did not validate successfully.");
		}
		
		typeTreeSource.close();
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) { 
		
		String location = args.length == 1 ? args[0] : DefaultLocation;
		ValidateTypeTreeExample target = new ValidateTypeTreeExample(location);
		target.run();
	}

	/**
	 * @return string value of file location
	 */
	public String getFileLocation() {
		if(_fileLocation != null && _fileLocation.equals(DefaultLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("./");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _fileLocation);
				_fileLocation = sourceFile.getAbsolutePath();
			}
		}
		return _fileLocation;
	}

	/**
	 * @return list of validation results
	 */
	public List<TTValidateResults> getValidateResults() {
		return _validateResults;
	}

}
