CREATE TABLE bulkcopy
(
state CHAR(2),
name VARCHAR(80),
type VARCHAR(9),
county VARCHAR(60),
st_code INTEGER,
county_code INTEGER,
platitude_dms CHAR(7),
plongitude_dms CHAR(8),
platitude_dec VARCHAR(10),
plongitude_dec VARCHAR(10),
slatitude_dms CHAR(7),
slongitude_dms CHAR(8),
slatitude_dec VARCHAR(10),
slongitude_dec VARCHAR(10),
elevation VARCHAR(10),
population VARCHAR(10),
cell_name VARCHAR(30)
);