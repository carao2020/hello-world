IBM WebSphere Transformation Extender 
Resource Registry Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Map Designer and Resource 
Registry.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

       apples.txt      - the input file for the map
       empty.mrc       - a resource configuration file that contains 
                         names of an empty resource name file
       empty.mrn       - an emtpy resource name file
       readme.txt      - this file
       testmaps.mms    - the example map source file
       testmaps.mrc    - the resource configuration file that 
                         contains a resource name file for valid 
                         aliases in testmap.mms
       testmaps.mrn    - the resource name file for testmaps.mrc
       testmaps.mtt    - the type tree for testmaps.mms


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to be used with the Map Designer 
and Resource Registry.

See the Resource Registry documentation for complete information 
about the Resource Registry.

The example map shows how to use aliases from the Resource Registry
in map and card settings as well as in rules.

Items that are aliased in this example include:

1)  input source file name
2)  input back-up name
3)  output target file name
4)  audit file name
5)  trace file name
6)  workspace directory location
7)  file name for a PUT rule function

In this example, depending on whether you specify testmaps.mrc, 
empty.mrc, or a non-existent .mrc file, a different result will
result will occur. In each case, an audit file will be produced 
so you can see the different setting that result based on the 
value of the configuration file.

How to run the example:

1)  Load testmaps.mms in the Map Designer and build the map.

2)  Under the menu Tools->Options->Run Options you can modify the
    Configuration File name.

3)  Enter testmaps.mrc for the configuration file name and run the
    map. In this case, all aliases will be resolved to their values
    in the resource name files, and the map will complete 
    succesfully creating the audit log file "myaudit.log".

4)  Enter empty.mrc for the configuration file name and run the map.
    In this case, valid resource configuration and name files exsit,
    but the aliases cannot be resovled, so any alias returns a 0 
    length value. The result is "Source not available" creating the 
    "my" audit file.

5)  Now, enter a resource configuration file that doesn't exist. In
    this case, the resource registry won't be used and aliases will
    be ignored in command lines and file names. Now the result will
    be "Could not open work files" and the audit file will be named
    "my%audit%".

For each of these three cases, you can look at the appropriate
audit log file to see how the other settings are affected.


=====================================================================
                             END OF FILE
=====================================================================
