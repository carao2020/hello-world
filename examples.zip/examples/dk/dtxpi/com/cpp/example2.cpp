/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include <windows.h>
#include <process.h>
#include "stdio.h"
#include "common.h"

void RunMap(void* pIMMap);

int main()
{
  // Initialize the com libraries
	CoInitialize(NULL);
	
	try
	{		        
    IMFactoryPtr pMFactory(__uuidof(MFactory));
		BSTR bstrName = NULL;
    CComBSTR ccbstrName1("test2.mmc");
    CComBSTR ccbstrName2("test2.mmc");

    // Create the Map
    IMMapPtr pMMap1, pMMap2 = NULL;	    

    /* Initialize the API */
    pMFactory->InitializeAPI(bstrName);         

    /* Load the first Map */
    pMMap1 = pMFactory->MapLoadFile((_bstr_t)ccbstrName1);    

    /* Load the second Map */
    pMMap2 = pMFactory->MapLoadFile((_bstr_t)ccbstrName2);

    /* enable externalized resource manager for common file resources */
    pMMap1->SetIntegerProperty(MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);
    pMMap2->SetIntegerProperty(MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);	

    _beginthread(RunMap, 0, (void*)pMMap1);
    _beginthread(RunMap, 0, (void*)pMMap2);

    Sleep(100);

    /* Get the Error Response for first map */
    ccbstrName1 = (BSTR)pMMap1->GetTextProperty(MPIP_OBJECT_ERROR_MSG, 0);
    int nResultCode = pMMap1->GetIntegerProperty(MPIP_OBJECT_ERROR_CODE, 0);	
	
    // print the error
    LPCTSTR lpszError = (LPCTSTR)_com_util::ConvertBSTRToString(ccbstrName1);
    printf("Map status for first map: %s (%d)\n", lpszError, nResultCode);

    /* Get the Error Response for second map */
    ccbstrName1 = (BSTR)pMMap2->GetTextProperty(MPIP_OBJECT_ERROR_MSG, 0);
    nResultCode = pMMap2->GetIntegerProperty(MPIP_OBJECT_ERROR_CODE, 0);	

    lpszError = (LPCTSTR)_com_util::ConvertBSTRToString(ccbstrName1);
    printf("Map status for second map: %s (%d)\n", lpszError, nResultCode);

    /* Unload the first Map */
	  pMMap1->MapUnload();	    

    /* Unload the second Map */
    pMMap2->MapUnload();	    

    /* Exit the API */
    pMFactory->TerminateAPI();
	}

	catch (const _com_error Err)
	{          
    printf("Error Description: %s\n", (LPCTSTR)Err.Description());
	}

	CoUninitialize();

	return 0;
}

void RunMap(void* pMap)
{
  IMMap* pIMMap = (IMMap*)pMap;
	pIMMap->Run();	
}
