/*
 * IBM Confidential
 * OCO Source Materials
 * 5747-SM3
 * � Copyright IBM Corp. 2012
 *
 * This software is the property of IBM Corporation and its licensors 
 * and contains their confidential trade secrets. Use, examination, copying,
 * transfer and disclosure to others, in whole or in part, are prohibited
 * except with the express prior written consent of IBM Corporation. 
 */

public class Product extends Entity {

	private String  theName 		= new String("");
	private String  theDescription 	= new String("");
	private Company theCompany 		= new Company();

	public Product() {
	}

	public Product(String Name, String Description) {
		super(Name, Description);
	}

	public void setCompany(Company aCompany) {
		theCompany 	= aCompany;
	}

	public Company getCompany() {
		return theCompany;
	}

	public String getInfo() {
		return new String("Product: " + getName()     + ", " + 
						  "Description: " + getDescription()  + ", " +
						  theCompany.getInfo());
	}
}
