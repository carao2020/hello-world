/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import java.rmi.server.*;
import java.io.Serializable;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;
import javax.rmi.*;

public class Example4 implements IMMapStatusCallback, Serializable
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example4 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load the Map
            String mapPath = makeMapPath(args[2], "test4.mmc");
            IMMap map = factory.loadMapFile(mapPath);
            Example4 example = new Example4();

            /*NOTE: Use PortableRemoteObject instead of UnicastRemoteObject when running
             *      RMI server with server.protocol.iiop= true
             *
             *	    PortableRemoteObject.exportObject( example );
             */
            UnicastRemoteObject.exportObject( example );
            map.registerStatusCallback(example, MConstants.MPI_EVENT_ALL);
            map.run();
            String responseMessage = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            int resuleCode = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);

            System.out.println("Map Status: " + responseMessage + " " + resuleCode);

            // Unload the Map
            map.unload();

            // Unexport the RMI object and let the process terminate

            /*NOTE: Use PortableRemoteObject instead of UnicastRemoteObject when running
             *      RMI server with server.protocol.iiop= true
             *
             *	    PortableRemoteObject.unexportObject( example );
             */
            UnicastRemoteObject.unexportObject( example, true );
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void callback(IMMap map, int eventID, int burstNum, int cardNum)
    {
        switch (eventID)
        {
        case MConstants.MPI_EVENT_START_INPUT:
            System.out.println("**Event received = MPI_EVENT_START_INPUT \n");
            break;
        case MConstants.MPI_EVENT_INPUT_COMPLETE:
            System.out.println("**Event received = MPI_EVENT_INPUT_COMPLETE \n");
            break;
        case MConstants.MPI_EVENT_START_OUTPUT:
            System.out.println("**Event received = MPI_EVENT_START_OUTPUT \n");
            break;
        case MConstants.MPI_EVENT_OUTPUT_COMPLETE:
            System.out.println("**Event received = MPI_EVENT_OUTPUT_COMPLETE \n");
            break;
        case MConstants.MPI_EVENT_START_BURST:
            System.out.println("**Event received = MPI_EVENT_START_BURST \n");
            break;
        case MConstants.MPI_EVENT_BURST_COMPLETE:
            System.out.println("**Event received = MPI_EVENT_BURST_COMPLETE \n");
            break;
        case MConstants.MPI_EVENT_START_MAP:
            System.out.println("**Event received = MPI_EVENT_START_MAP \n");
            break;
        case MConstants.MPI_EVENT_MAP_COMPLETE:
            System.out.println("**Event received = MPI_EVENT_MAP_COMPLETE \n");
            break;
        default:
            System.out.println("**Unknown event!!!");
            break;

        }
    }
}


