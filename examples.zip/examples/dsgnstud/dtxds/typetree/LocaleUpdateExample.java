package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.ibm.websphere.dtx.ds.typetree.TTCategory;
import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTLanguageData;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTType;

/**
 * This example updates locale for all types in the provided file.
 */
public class LocaleUpdateExample {

	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	private static String DefaultSourceLocation = "files/Contact.mtt";
	private static String DefaultTargetLocation = "output/Contact_langUpdate.mtt";
	
	private String _sourceLocation = DefaultSourceLocation;
	private String _targetLocation = DefaultTargetLocation;
	
	TTSource _typeTreeSource = null;
	Properties _properties = null;

	/**
	 * Constructor
	 */
	public LocaleUpdateExample() {
		super();
	}
	
	/**
	 * This method runs the example
	 */
	public void run(){
		
		try {
			loadTypeTree();
			
			// Get sources for type tree updates.
			loadProperties();
			
			// Update type tree
			if(_typeTreeSource != null && _properties != null){
				
				final String targetLanguage = _properties.getProperty("targetLanguage");
				final TTLanguageData.LanguageInfo langInfo = TTLanguageData.getInstance().getLanguageInfo(targetLanguage);
			
				final String targetCharSet = _properties.getProperty("targetChatSet");
				final TTLanguageData.DataLanguageInfo dataLangInfo = TTLanguageData.getInstance().getDataLanguageInfo(targetCharSet);
			
				if(langInfo == null){
					System.out.println(targetLanguage + " is not supported");
					return;
				}
				final StringBuffer sb = new StringBuffer();
				TTWalker walker = new TTWalker() {
					
					@Override
					public void processType(TTType type) {
						
						switch (type.getTypeClass()) {
						case TI_ITEM:
							TTItem item = (TTItem)type;
							item.getItemProperties().setLanguage(langInfo);
							item.getItemProperties().setCharSet(dataLangInfo);
							sb.append(type.getPath() + " Language changed to " + targetLanguage + "\n");
							break;
						case TI_CATEGORY:
							TTCategory cat = (TTCategory)type;
							cat.getItemProperties().setLanguage(langInfo);
							cat.getItemProperties().setCharSet(dataLangInfo);
							sb.append(type.getPath() + " Language changed to " + targetLanguage + "\n");
							break;

						default:
							break;
						}
					}
				};
				walker.walkType(_typeTreeSource.getRootType());
				System.out.println("*** Resulting Type Tree ***\n" + sb.toString());
			}
			
			// Close type tree
			if(_typeTreeSource != null){
				boolean result = _typeTreeSource.saveAs(getTargetLocation());
				_typeTreeSource.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	protected void loadProperties(){
		// Load properties file.
		_properties = new Properties();
		InputStream is = getClass().getResourceAsStream("files/langUpdate.properties");
		if(is == null) return;
		try {
			_properties.load(is);
			is.close();
			// Get parameters from the properties file.
			
		} catch (Exception e) {
			
		}
		finally{
			try {
				is.close();
			} catch (IOException e) {
				
			}
		}
	
	}

	
	protected void loadTypeTree() throws Exception{
		
		// Load type tree from a file.
		String fileLocation = getSourceLocation();
		if(DefaultSourceLocation.equals(getSourceLocation())){
			URL url = getClass().getResource(DefaultSourceLocation);
			fileLocation = url.getFile().replace("%20", " ").substring(1);
		}
		File sourceFile = new File(fileLocation);
		if(sourceFile.exists()){
			/* Open Type Tree */
			_typeTreeSource = TTSource.openTypeTree(fileLocation);
		}

	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultSourceLocation;
		String targetlocation = args.length == 2 ? args[1] : DefaultTargetLocation;
		LocaleUpdateExample target = new LocaleUpdateExample();
		target.setSourceLocation(location);
		target.setTargetLocation(targetlocation);
		target.run();
		
	}

	public String getSourceLocation() {
		return _sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		_sourceLocation = sourceLocation;
	}

	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}

}
