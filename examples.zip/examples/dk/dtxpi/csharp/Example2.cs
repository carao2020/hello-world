/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
using System;
using System.Threading;
using com.ibm.websphere.dtx.dtxpi.dtxinterop;

namespace com.ibm.websphere.dtx.dtxpi.example
{
	/// <summary>
	/// This example runs two instances of the same map in two separate threads
	/// </summary>
	public class Example2
	{
		private MMap map;

		public Example2(MMap mapVar)
		{
			this.map = mapVar;
		}

		[STAThread]
		static void Main(string[] args)
		{
			try
			{
				MFactory imFactory = new MFactory();
				imFactory.InitializeAPI(null);

				// Load a map twice
				MMap map1 = imFactory.MapLoadFile("test2.mmc");
				// This 2nd call will not read the MMC file.
				MMap map2 = imFactory.MapLoadFile("test2.mmc"); 

				Example2 map1Instance = new Example2(map1);
				ThreadStart map1Start = new ThreadStart(map1Instance.run);
				Thread map1Thread = new Thread(map1Start);
				map1Thread.Name = "Thread 1";
				// set resource manager property for common file resources
				map1.SetIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);

				Example2 map2Instance = new Example2(map2);
				ThreadStart map2Start = new ThreadStart(map2Instance.run);
				Thread map2Thread = new Thread(map2Start);
				map2Thread.Name = "Thread 2";
				// set resource manager property for common file resources
				map2.SetIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);

				map1Thread.Start();
				map2Thread.Start();

				map1Thread.Join();
				string responseMessage = map1.GetTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
				int resuleCode = map1.GetIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
				Console.Out.WriteLine("Map Status: " + responseMessage + " " + resuleCode);

				map2Thread.Join();
				responseMessage = map1.GetTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
				resuleCode = map1.GetIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
				Console.Out.WriteLine("Map Status: " + responseMessage + " " + resuleCode);

				// Clean up
				map1.MapUnload();
				map2.MapUnload();

				// Exit the API 
				imFactory.TerminateAPI();
			}
			catch (Exception e)
			{          
				Console.Out.WriteLine("Error Description: "+e);
			}

		}

		public void run()
		{
			Console.Out.WriteLine("Running Thread: " + Thread.CurrentThread.Name);
			map.Run();
			return;
		}
	}
}
