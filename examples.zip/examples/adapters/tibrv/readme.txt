IBM WebSphere Transformation Extender 
TIBCO/Rendezvous Adapter Example Readme

(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    rvmsg.mms
    tibco_rv.mtt
    readme.txt
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example provides the rvmsg.mms file which contains maps that 
will help you understand how the TIBCO/Rendezvous 7.x adapter works. 

How to run the example:

1)  To verify your TIBCO/RV installation, run the tibrvsend and
    tibrvlisten tools provided by Tibco.

2)  Build all maps in rvmsg.mms.

3)  Run "rqstrply.mmc" to start listen for the request message. Then
    run "rqst.mmc" to send the request message.

4)  Run "rvcmsgin.mmc" to start to "listen" for the certified
    message. Run "rvcmsgsn.mmc" to publish a certified message.
    Look at out.txt to see the received message.

5)  Run "rvmsgin.mmc" to start the "listen" for the message. Run
    "rvmsgsn.mmc" to publish the message. Look at out.txt
    to see the received message.



=====================================================================
                             END OF FILE
=====================================================================
