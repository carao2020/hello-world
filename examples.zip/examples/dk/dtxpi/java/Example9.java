/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.io.FileInputStream;

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MStream;
import com.ibm.websphere.dtx.dtxpi.tools.MObjectPool;

public class Example9
{
    public static void main(String[] args)
    {

		int counter=0;
        try
        {
			// Initialize the API
			  MMap.initializeAPI(null);

            // First run --- do not destroy the object pool
			// If the counter==1 then the map successfully used the object pool
			  try
			  {
              	counter = Objectpool(false);
              	if(counter==1)
			  	{
			  		System.out.println("Good...The object pool was not destroyed in the first run");
			  	}
			  	else
			  	{
					System.out.println("Error... The object pool was not destroyed but the map did not use the object");
				}
			  }
			  catch(NullPointerException ex)
			  {
				  System.out.println("Error... The object pool was destroyed");
			  }


             // Second run --- destroy the object pool
             // If exception is thrown then the object pool was successfully destroyed
			  try
			  {
			       counter = Objectpool(true);
			       System.out.println("Error... The object pool was not destroyed");
			  }
			  catch(NullPointerException ex)
			  {
			  		System.out.println("Good...The object pool was destroyed in the second run");
			  }

			// Clean up
        	MMap.terminateAPI();

		}
		catch( Exception e )
		{
			 e.printStackTrace();
		}
	}


	private static int Objectpool(boolean destroyObject) throws Exception
	{
		int count=0;
		int mapID=0;

		// Create a map
		MMap map = new MMap("test9.mmc");

		// Get WTX unique value for map instance
		int uniqueInst = MMap.getUniqueMapInstance();

		// Set map instance to unique value
  		map.setIntegerProperty(MConstants.MPIP_MAP_INSTANCE, 0, uniqueInst);

		// Create a local Object
		CounterObject counterObject = new CounterObject();

		// Put it in the Object Pool
		MObjectPool pool = MObjectPool.getInstance();
		String key = pool.generateNewReferenceValue(counterObject);
		pool.storeObjectToThePool( map.getIntegerProperty(MConstants.MPIP_MAP_INSTANCE, 0),
			  					  	key,counterObject);

		// Override the input card so that a local file
		// containing input data can be sent to the remote server
		MCard card = map.getInputCardObject(1);
		card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

		// Pass it to the server via a stream
		MAdapter adapter = card.getAdapter();
		MStream stream = adapter.getOutputStream();
		stream.write(key.getBytes("8859_1"), 0, key.length());

		if(destroyObject)
		{
			//Destroy the object pool
			map.setIntegerProperty(MConstants.MPIP_MAP_DESTROY_OBJECT_POOL, 0, MConstants.MPI_SWITCH_ON);
		}
		else
		{
			 //Do not destroy the object pool
			 map.setIntegerProperty(MConstants.MPIP_MAP_DESTROY_OBJECT_POOL, 0, MConstants.MPI_SWITCH_OFF);
		}

		// Run the map
		map.run();
        mapID=map.getIntegerProperty(MConstants.MPIP_MAP_INSTANCE, 0);

		// Clean up
        map.unload();

         //Retrieve object from the pool
		CounterObject anotherObject = (CounterObject) pool.retrieveObjectFromThePool(mapID,key);
		count= anotherObject.getCount();
		pool.removeObjectFromThePool(mapID,key);


        return count;


	}
}

