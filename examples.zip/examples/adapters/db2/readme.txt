
IBM WebSphere Transformation Extender - DB2 Adapter Readme

(c) Copyright IBM Corporation 2012. All Rights Reserved.


This example demonstrates how to use WebSphere Transformation Extender 
to read and update a DB2 database.

====================================================================== 
Contents 
====================================================================== 

1. Example files
2. Using the examples

====================================================================== 
Example files 
====================================================================== 

Readme: This file

Database_QueryFile.mdq: Database query file

SAMPLE.mms: Contains the source for all of the maps in the example

OneNewEmployee.txt: Input file for the AddEmployee map contained in SAMPLE.mms 

Maps:
- AllEmployee: Lists the contents of the EMPLOYEE table 
- AllDept: Lists the contents of the DEPT table 
- EmployeeAndDept: Uses the DBLOOKUP function in a functional map 
  to create a list of employees and their department name. 
- AddEmployee: Adds a new employee to the NEWEMPLOYEE 
  table which was created for this example.

Type Trees:
- Dept.mtt: For the DEPT table 
- Employee.mtt: For the EMPLOYEE table 
- NewEmployee.mtt: For the NewEmployee table 
- Database_QueryFile1.mtt: For the database query  
- NameAndDept.mtt: Output description for the NameAndDept map

====================================================================== 
Using the examples 
====================================================================== 

This example uses the DB2 SAMPLE database for the Windows platform. 
DB2 distributes similar databases and tables for other platforms.  
Create the sample database by following the instructions in the DB2 
information center.  Search for the DB2SAMPL command.  

This example uses the EMPLOYEE and DEPT database tables of the 
SAMPLE database.  The NEWEMPLOYEE table is a copy of the 
EMPLOYEE table of the SAMPLE database.

Except for the NameAndDept type tree, all of the TypeTrees are created 
with the Database Interface Designer and do not need to be changed. 
The NameAndDept type tree describes the output of the EmployeeAndDept
map. The NameAndDept type tree is the only one you can change without 
making a corresponding change in the SAMPLE database.


1. Copy the example from:
   C:\IBM\WebSphere Transformation Extender n.n\examples\adapters\db2 
2. Import the files into a new project in Design Studio.
3. Open the "Database_QueryFile1.mdq" file with Database Interface Designer 
   or double-click on it in Design Studio.
4. a. Check that the Data Source for both Database Interface Designer and 
      Runtime have the name of the SAMPLE database on your system.   
      SAMPLE is the default value that is installed with DB2.
   b. The initial USERID is DB2ADMIN and the initial PASSWORD is PASSWORD.
      Change the USERID and PASSWORD to that of the database owner.
   c. Save your changes.
5. Build and run the maps.  
 
Database trace is enabled only for the EmployeeAndDept map. 
After the EmployeeAndDept map runs, the EmployeeAndDept.dbl file 
in the map directory contains the trace. 