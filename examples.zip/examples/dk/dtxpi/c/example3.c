/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#define CHECK_ERR(rc) if(MPIRC_FAILED(rc)) 	{ printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

int main()
{
	const char  		*szMsg;
	int		iRC;
	MPIRC rc;
	HMPIMAP	hMap;
	HMPICARD	hInputCard1;
	HMPIADAPT	hAdapter;
	unsigned short uSubstString[] = { 0x004d, 0x0079, 0x0053, 0x0075, 0x0062, 0x0073, 0x0074, 0x0043, 0x0068, 0x0061, 0x0072}; /* UTF16 "MySubstChar" */

	rc = mpiInitAPI(NULL);
	CHECK_ERR(rc);

	rc = mpiMapLoadFile (&hMap, "test3.mmc");
	CHECK_ERR(rc);

	/* Turn on burst and summary execution audit on the map instance */
	rc = mpiPropertySetInteger (hMap, MPIP_MAP_AUDIT_SWITCH, 0, MPI_SWITCH_ON);
	CHECK_ERR(rc);
	rc = mpiPropertySetInteger (hMap, MPIP_MAP_AUDIT_BURST_EXECUTION, 0, MPI_SWITCH_ON);
	CHECK_ERR(rc);
	rc = mpiPropertySetInteger (hMap, MPIP_MAP_AUDIT_SUMMARY_EXECUTION, 0, MPI_SWITCH_ON);
	CHECK_ERR(rc);

	/* Get the adapter object handle */
	rc = mpiMapGetInputCardObject (hMap, 1, &hInputCard1);
	CHECK_ERR(rc);
	rc = mpiCardOverrideAdapter(hInputCard1,"GZIP",0);
	CHECK_ERR(rc);
	rc = mpiCardGetAdapterObject (hInputCard1, &hAdapter);
	CHECK_ERR(rc);

	/* set a command line for the adapter */
	rc = mpiPropertySetText(hAdapter, MPIP_ADAPTER_COMMANDLINE, 0, "-FILE input.gz", 0);
	CHECK_ERR(rc);

	/* set ICU substitute chars - CodePageFallback map setting overwrite */
	rc = mpiPropertySetBinary(hMap, MPIP_MAP_SUBST_CHARS, 0, uSubstString, sizeof(uSubstString));
	CHECK_ERR(rc);

	rc = mpiMapRun (hMap);
	CHECK_ERR(rc);

	rc = mpiPropertyGetText (hMap, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, NULL);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);

	rc = mpiMapUnload (hMap);
	CHECK_ERR(rc);
	rc = mpiTermAPI();
	CHECK_ERR(rc);
	return 0;
} 
