public class SubClass
{
    public int _intField;
    public byte _byteArrayField[];
    
    public SubClass(int intPar1)
    {
        _intField=intPar1;
        _byteArrayField = new byte[5];
    }
}
