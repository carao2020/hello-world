/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example1
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        IMMap map = null;

        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example1 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load the Map
            String mapPath = makeMapPath(args[2], "test1.mmc");
            map = factory.loadMapFile(mapPath);
            map.run();
            String responseMessage = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            int resuleCode = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);

            System.out.println("Map Status: " + responseMessage + " " + resuleCode);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        try
        {
            // Unload the Map
            if (map != null) map.unload();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}


