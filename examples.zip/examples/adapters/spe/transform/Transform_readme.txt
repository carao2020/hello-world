IBM WebSphere Transformation Extender 
SPE Adapter TRANSFORM Example Readme


(c) Copyright International Business Machines Corporation 2015.
All Rights Reserved.


This example demonstrates the usage of the SPE Adapter -TRANSFORM 
(-TFM) command in a WebSphere Transformation Extender map.

This map interacts with SPE in a two step process.

1. A data file and map name are passed to SPE using the -TRANSFORM
   parameter, SPE runs the map on the Standards Processing Engine (SPE),
   and a response is returned from SPE in XML format. The XML response
   file contains the document IDs of the transformed documents. The 
   metadata schema of the XML response file is defined by the 
   wtx_install_dir\Response.xsd file.

2. Each Document ID is passed to SPE using the -GDOC parameter and
   the corresponding document is written to the file system.

=================================================================
CONTENTS
=================================================================

1. Example Files
2. Using This Example	

=================================================================
1: EXAMPLE FILES
=================================================================

Files included in this example:

1. Transform.mms
2. simpletext.mtt
3. Filter.mtt
4. FilterFile.txt
5. in\adapter_syntax.in
6. in\data.in
7. in\xslincludefile.xsl
8. readme

Other files that are used with this example: 
1. Response.xsd

=================================================================
2: USING THIS EXAMPLE
=================================================================

Prerequisites:
--------------

1. Install SPE
2. IInstall and deploy the SPE Pack(s)
3. Run samples for the SPE Pack(s)
4. Verify Derby is running

Description of Input Cards:
---------------------------

- Input Card 1 contains the data file to be processed.

- Input Card 2 ECHO the directory path used in Output Card 2 
  when writing documents from SPE to the file system.

- Input Card 3 contains additional SPE Adapter syntax.
 
- Input Card 4 contains the FilterFile.txt [This document 
  filter allows user to extract documents that match criteria 
  DOCTYPE & ACKTYPE & DOCNAME].

Transform map:
--------------

1. Copy Response.xsd from the WebSphere Transformation Extender 
   install directory to the spe\transform directory. It will be used 
   by Output Card 1.

2. Open map source file Transform.mms in Design Studio.

3. Select Map > Build All option.

4. Run Transform map.

Verify Results:
---------------

- Output Card 1 writes to out\SpeResponse.xml. 
  This file contains the response XML file from SPE.

- Output Card 2 writes to out\ResponseInfo.txt. 
  This file contains a list of document IDs from the response XML file.
 
- Output Card 3 writes to out\ReportInfo.speout.
  This file contains the Report information from the response XML file.

- Other files returned by SPE may appear in the "out" directory depending on the 
  filter criteria and SPE processing.

=================================================================
                             END OF FILE
=================================================================