/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.IWTXLogCallback;
import java.text.DateFormat;
import java.util.Date;



public class Example10 implements IWTXLogCallback
{
	 public void initWTXLog (MMap mymap, int myloglevel)
	 {
		  try {
				mymap.registerWTXLogCallback(this, myloglevel);
		  }
        catch( MException e )
        {
            e.printStackTrace();
        }

	 }
	 
    public static  void main(String[] args)
    {
        try
        {
            // Initialize the API
            MMap.initializeAPI(null);
				Example10 ex10 = new Example10();

            // Create a map 
            MMap mapTraceAll = new MMap("test1.mmc");
            MMap mapTraceErrors = new MMap("test1.mmc");

				// Register sample logging callback
				
				ex10.initWTXLog(mapTraceAll, MMap.LOG_TRACE | MMap.LOG_DEBUG | MMap.LOG_INFO |
													  MMap.LOG_WARNING | MMap.LOG_ERROR | MMap.LOG_FATAL);
				ex10.initWTXLog(mapTraceErrors, MMap.LOG_WARNING | MMap.LOG_ERROR | MMap.LOG_FATAL);

            // Run the map with full trace enabled
            System.out.println("Running map with full trace enabled: ");
            mapTraceAll.run();

            // Check the return status
            int iRC = mapTraceAll.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = mapTraceAll.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            mapTraceAll.unload();

            // Run the map with error trace enabled
            System.out.println("Running map with all errors trace enabled: ");
            mapTraceErrors.run();

            // Check the return status
            iRC = mapTraceErrors.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            szMsg = mapTraceErrors.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            mapTraceErrors.unload();

            MMap.terminateAPI();
        }
        catch( MException e )
        {
            e.printStackTrace();
        }
    }
	 public int WTXLogCallback(int nID, String msg, int ninst, String file, int line) {
		  Date current= new Date();
		  System.out.println( current.toString() + "\tMsgID: " + nID +  "\tMsg: " + msg +
									 "\tInstance: " + ninst +"\tFrom: " + file + "[" + line + "]");
		  return 1;
	 }
}

