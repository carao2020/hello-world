/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example5
{
    private static String szInputBuffer = "This is my input data";

    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {

        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example5 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load the Map
            String mapPath = makeMapPath(args[2], "test5.mmc");
            IMMap map = factory.loadMapFile(mapPath);

            // Get the adapter object handle for input card #1
            IMCard card = map.getInputCardObject(1);

            // Override the adapter in input card #1 to be a stream
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Get the handle to the stream object
            IMAdapter adapter = card.getAdapter();
            IMStream stream = adapter.getOutputStream();

            // Send a single large page
            stream.write(szInputBuffer.getBytes(), 0, szInputBuffer.length());

            // Get the adapter object handle for output card #2
            card = map.getOutputCardObject(2);

            // Override the adapter in output card #2 to be a stream
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Get the adapter object handle for output card #2
            adapter = card.getAdapter();
            stream = adapter.getInputStream();

            // Get the data in pieces from the stream
            stream.seek(0, MConstants.MPI_SEEK_SET);
            while ( true )
            {
                boolean bIsEnd = stream.isEnd();

                // Clean and Break
                if ( bIsEnd )
                {
                    stream.setSize(0);
                    break;
                }

                byte[] page = stream.readPage();
                System.out.println(new String(page));
            }

            // Clean up
            map.unload();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}


