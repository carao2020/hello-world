IBM WebSphere Transformation Extender 
COM Automation Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of COM Automation Adapter sample 
files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

\simple (simple example)

comexmpl.dll       - Sample DCOM component for the complex data types.
                     To use this example, you must run
                     "regsvr32 comexmpl.dll" from the command prompt
                     in this directory. For the successful
                     registration of the comexmpl.dll library, the
                     software installation directory must be added
                     to the PATH environment variable.

nxf_getentry.mtt   - type tree for example map

nxf_add.mtt        - type tree for example map

nxf_example.mms    - example map

nxfsvr.exe         - Sample DCOM component. To use this example, you
                     must run "nxfsvr.exe -regserver" from the 
                     command prompt in this directory.

nxf.exe            - simple command line utility used to inspect,
                     create, or modify the orders.dat file

orders.dat         - example data file

orders.nxi         - example data file

other.mtt          - type tree for example map

NOTE: The example maps depend on these files being located in this
      directory. You can place them elsewhere, however, if you do,
      you will need to update the maps.


\struct (example for using structures)

other.mtt          - type tree for example map
struct.mms         - example map

\array (example for using arrays)

other.mtt          - type tree for example map
array.mms          - example map

\object (example for showing object persistence capability)

other.mtt          - type tree for example map
object.mms         - example map


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to be used with the COM
Automation adapter. There is a basic example and a complex data types
example included.

For the basic example, the example custom component, NxfSvr is used.
This component has been designed to access a "structured" file
similar in concept to the UNIX tar facility.

For the complex data types example, the example custom component,
comexmpl.dll is used. This component contains examples for the usage
of structures, arrays and object persistence in the COM adapter.

For the successful registration of the comexmpl.dll library, the
IBM WebSphere Transformation Extender n.n (where n.n is the version
number) installation directory must be added to the PATH environment 
variable.

How to run the example:

1. Install the sample DCOM component as instructed above.

2. Open one of the examples in the Map Designer.

3. Modify the COM_Input cards as needed.

4. Build and run all maps.

5. View the output file results.


2a: Example File Scenario for Object Persistence
------------------------------------------------

Subdirectory \object

other.mtt          - type tree for example map
object.mms         - example map

Usage:

This test case illustrates object persistence in the COM adapter.

Output card 1 (COM_Input), prepares data for the Dummy1 method from
the CCustomInterface. This method takes the input parameter (integer
type) and returns its value multiplied by two (2).

Output card 2 (Invoke), calls the Dummy1 method, through a GET call
to the COM adapter.

Output card 3 (COM_Out), returns the result of the previous call.

Output card 4 (Get_Ref), calls the map get_ref.mmc. This map extracts
the exact reference number of the interface used for the call in
Output card 2.

Output card 5 (COM_Input_SumTest), prepares data for the method
TestObj1 from the SumTest interface to be called. This method takes
a reference to CCustomInterface as the input parameter pObj.

Output card 6 (Invoke_sum), performs a call to method TestObj1
through the GET call to the COM adapter.

NOTE: Type trees used in an example map need to be re-imported
      to correctly run an example.

The sum_test.mtt type tree can be imported with the Type Library
Importer. Use comexmpl.dll as the input, choose the SumTest interface
and the TestObj1 method.

The custom_i.mtt type tree can be imported with the Type Library
Importer. Use comexmpl.dll as the input, choose the CCustomInterface
interface and the Dummy1 method.


2b: Example File Scenario for Structure
------------------------------------

Subdirectory \struct

other.mtt          - type tree for example map
struct.mms         - example map

Usage:

This test case illustrates how to use structures in the COM adapter.

Method TestStruct1 takes pPoint structure as its input parameter, and
returns the total sum of its fields iX and iY. Structure is passed by
its reference, in a format "Ref.XXX", where XXX represents the
reference number. That reference number corresponds to the ref item
in the Structure Point group.

NOTE: Type trees used in an example map need to be re-imported
to correctly run an example.

The struct.mtt type tree can be imported with the Type Library
Importer. Use comexmpl.dll as the input, choose the SumTest interface
and the TestStruct1 method.


2c: Example File Scenario for Arrays
------------------------------------

Subdirectory \array

other.mtt          - type tree for example map
array.mms          - example map

Usage:

This test case illustrates how to use arrays in the COM adapter.

Method TestArray001 takes dragan SAFEARRAY as its input parameter.
This method adds the first five (5) elements of the SAFEARRAY. The
dragan input parameter has a range of (1:s), which is standard for
all SAFEARRAY type parameters.

You must create the array.mtt type tree that is used in the maps in 
array.mms.

  To create array.mtt:
  --------------------
  1. From the Startup window of the Type Designer, choose Import a 
     type tree and select OK. 
  2. In the Importer Wizard, choose to import from "Type Library" 
     and click Next.
  3. The required dll is not present in the Registered Components 
     list so you must browse to select it. Select the following dll 
     for the Type Library Name field:

       install_dir\examples\adapters\com\simple\comexmpl.dll

  4. Click Next.
  5. From the Objects list, select Sum Test and click Next. 
  6. From the Methods list, select the following:

       VT_I4 = TestArray001([in] dragan:VT_I4);

  7. Click Next. 
  8. In the File Name field, enter a path and name for the type tree 
     file you are creating. For this example, use the following:

       install_dir\examples\adapters\com\array\array.mtt

  9. Click Next. 
     (Opt to replace the existing file if it already exists.)
 10. When the type tree is displayed, click Finish. 
 11. When the new type tree is open in the Type Desginer, analyze 
     and save it.


=====================================================================
                             END OF FILE
=====================================================================
