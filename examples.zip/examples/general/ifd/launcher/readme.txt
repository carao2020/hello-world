IBM WebSphere Transformation Extender 
Launcher Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the IBM WebSphere 
Transformation Extender n.n Launcher, where n.n represents the 
product release version number. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    allemps.txt
    employee.txt
    launcher.mms
    launcher.msd
    launcher.mtt
    readme.txt  (this readme file)

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example will use these sample files to support the 
event-driven server.

An event-driven server is a server that processes data automatically,
based on a predefined triggering event. In this example, the pre-
defined triggering event is the appearance of the employee.txt file 
in the input subdirectory. You may first have to create the input
subdirectory, if it doesn't already exist, and then place a copy of 
the employee.txt in it. See step 5) below.

The launcher.msd will monitor the input subdirectory for a file
named employee.txt. It will select an employee's timesheet from 
the allemps.txt file, based on which employee name is located in 
the employee.txt file. It will then return the employee's name and 
the total number of hours that employee worked for the week in a 
file named emphours.txt in the output subdirectory. You may first 
have to create the output subdirectory, if it doesn't already exist. 

How to run the example:

1)  Using the Integration Flow Designer, open launcher.msd.

2)  Edit the launcher map component to reflect the current location 
    of the Map Source File.
  
3)  Build and deploy the launcher map component.
    This creates two additional files:
    a)  launcher.mmc - This is the compiled map used for processing.
    b)  launcher.msl - This is the system file used for controlling 
        the compiled maps (in this case, just the launcher.mmc).

4)  Start the IBM WebSphere Transformation Extender n.n Launcher 
    service and Management Console. Note that n.n represents the 
    product release version number.

    Note: You may first have to create the output subdirectory before
          starting the IBM WebSphere Transformation Extender n.n 
          Launcher service. 

5)  Place a copy of the employee.txt file into the input 
    subdirectory.

    Note: You may first have to create the input subdirectory.

    Warning: Make sure you only use a copy of the file because the 
             input card is set to delete the inbound data file as 
             soon as it is done processing the file.

    The emphours.txt outbound data file is created in the output 
    subdirectory:
    "Work A.             |Holic               |90.45"

6)  For additional practice, you can look up other names in the 
    allemps.txt file and place them in the employee.txt file.


=====================================================================
                             END OF FILE
=====================================================================
