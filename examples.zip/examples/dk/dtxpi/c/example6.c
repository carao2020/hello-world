/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#define CHECK_ERR(rc) if(MPIRC_FAILED(rc)) 	{ printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

int main()
{
	const char  	*szMsg;
	char 			*szMMCBuffer;
	char 			*szInputBuffer;
	int				iRC;
	int 			bIsEnd;
	void			*pData;
	size_t			nSizeOfData;
	size_t			nLen;
	HMPIMAP 		hMap;
	HMPIADAPT		hAdapter;
	HMPICARD		hCard;
	HMPISTREAM		hStream;
	HMPISTREAMPAGE	hPage;
	MPIRC			rc;
	FILE            *fp;

	rc = mpiInitAPI(NULL);
	CHECK_ERR(rc);

	/* Load a local map file */
	fp = fopen("test6.mmc", "rb");
	fseek( fp, 0, SEEK_END );  
	nSizeOfData = ftell( fp ); 
	szMMCBuffer = (char *)malloc( nSizeOfData );
	fseek( fp, 0, SEEK_SET );
	fread( szMMCBuffer, sizeof(char), nSizeOfData, fp );
	fclose( fp );
    
	rc = mpiMapLoadMemory (&hMap, "test6", NULL, szMMCBuffer, nSizeOfData);
	free(szMMCBuffer);
	CHECK_ERR(rc);
	
	/* Get the adapter object handle for input card #1*/
	rc = mpiMapGetInputCardObject (hMap, 1, &hCard);
	CHECK_ERR(rc);

	/* Override the adapter in input card #1 to be a stream */
	rc = mpiCardOverrideAdapter(hCard,NULL, MPI_ADAPTYPE_STREAM);
	CHECK_ERR(rc);

	/* Read the local data file */
	fp = fopen("input.txt", "r");
	fseek( fp, 0, SEEK_END );  
	nSizeOfData = ftell( fp ); 
        szInputBuffer = (char *)malloc( nSizeOfData );
	fseek( fp, 0, SEEK_SET );
	fread( szInputBuffer, sizeof(char), nSizeOfData, fp );
	fclose( fp ); 

	/* Get the handle to the adapter object */
	rc = mpiCardGetAdapterObject (hCard, &hAdapter);
	CHECK_ERR(rc);

	/* Get the handle to the stream object */
	rc = mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_FROM_ADAPT, 0, &hStream);
	CHECK_ERR(rc);

	/* Send a single large page */
	rc = mpiStreamWrite (hStream, szInputBuffer, nSizeOfData);
	CHECK_ERR(rc);

	/* Get the adapter object handle for output card #1*/
	rc = mpiMapGetOutputCardObject (hMap, 1, &hCard);
	CHECK_ERR(rc);

	/* Override the adapter in output card #1 to be a stream */
	rc = mpiCardOverrideAdapter(hCard,NULL, MPI_ADAPTYPE_STREAM);
	CHECK_ERR(rc);

	rc = mpiMapRun (hMap);
	CHECK_ERR(rc);

	rc = mpiPropertyGetText(hMap, MPIP_OBJECT_ERROR_MSG, 0, &szMsg,&nLen);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);

	/* Get the adapter object handle for output card #1*/
	rc = mpiCardGetAdapterObject (hCard, &hAdapter);
	CHECK_ERR(rc);
	/* Get the handle to the stream object */
	rc = mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_TO_ADAPT, 0, &hStream);
	CHECK_ERR(rc);

	/* Get the data in pieces from the stream */
	mpiStreamSeek(hStream,0,SEEK_SET);
	while (1)
	{
		rc = mpiStreamIsEnd (hStream, &bIsEnd);
		CHECK_ERR(rc);

		/*Clean and Break*/
		if (bIsEnd)
		{
			rc = mpiStreamSetSize(hStream, 0); 
			break;
		}

		rc = mpiStreamReadPage (hStream, &hPage);
		CHECK_ERR(rc);
		rc = mpiStreamPageGetInfo (hPage, &pData, &nSizeOfData);
		CHECK_ERR(rc);
		fwrite(pData,1,nSizeOfData,stdout);
/*    	        DoSomethingWithData (pData, nSizeOfData); */
	}

	rc = mpiMapUnload (hMap);
	CHECK_ERR(rc);
	rc = mpiTermAPI();
	CHECK_ERR(rc);
	return 0;
}
