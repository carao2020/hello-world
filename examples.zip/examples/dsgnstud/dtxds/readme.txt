IBM WebSphere Transformation Extender 
Design-time Java API Examples Readme


� Copyright International Business Machines Corporation 2012.
All Rights Reserved.


These examples demonstrate how to create and edit type trees and 
maps using the design-time Java APIs.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using These Examples


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in these examples:

typetree.AddComponentExample 	- demonstrates how to open an existing 
                                type tree, add a component, and 
                                save the type tree to a file
typetree.ContactListExample 	- demonstrates how to build a 
                                type tree from the data description 
                                from csv file (header row)
typetree.CreateTypeTreeExample
                            	- demonstrates how to create a 
                            	  type tree, add different kinds of 
                            	  elements, and save the type tree to 
                            	  a file
typetree.DeleteComponentExample 
                              - demonstrates how to delete a 
                                component from a type tree
typetree.EditNumericTypeExample 
                              - an example of updating number type 
                                properties
typetree.LocaleUpdateExample 	- an example of updating the locale 
                                for all types in the given type tree 
                                file
typetree.SetInitiatorAndTerminatorExample 
                              - demonstrates the setting of 
                                initiator and terminator properties 
                                on all item types, where 
                                NITITATOR = ItemName
typetree.SyntaxObjectsAsComponentsOfTypeExample 
                              - an example of defining a syntax 
                                object as a component of a group 
                                type
typetree.UpdateComponentExample 
                              - demonstrates how to update a 
                                component on a type tree
typetree.ValidateTypeTreeExample 
                              - demonstrates how to validate a 
                                type tree

map.CreateMapExample          - demonstrates how to create a simple 
                                map using Java APIs

make.bat                      - script to compile Java class files

runExample.bat                - script to run examples

  
=====================================================================
2: USING THESE EXAMPLES
=====================================================================

These examples contain sample Java files that demonstrate how you 
can use the IBM WebSphere Transformation Extender type tree and map 
design-time APIs for Java to create and edit type trees and maps. 
All source code, maps, and supporting files are provided in these 
examples.


To build and run the examples, follow these steps:

1) Compile the Java files.

   a. Open the "make.bat" batch file and set the JDKHOME and DTXHOME 
      variables.

   b. On Windows, from a DOS command prompt, compile the Java files 
      by running:

   	  make.bat

3) Run the examples.

   a. Open the "runExample.bat" batch file and set the DTXHOME 
      variable.

   b. From a DOS command prompt, run the following command:

      runExample.bat <exampleName>, where you replace <exampleName> 
      with one of the file names listed in the Example Files section.
	
	    Example:
	    
	    runExample.bat typetree.ContactListExample 

	By default, the examples use the files that are in the 
	"typetree/files" and "map/files" directories, as sources for 
	editing the type trees and maps. The resulting type trees and maps 
	are saved to the "output" directory.
	
	
=====================================================================
                             END OF FILE
=====================================================================
