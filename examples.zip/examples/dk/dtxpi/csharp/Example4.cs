/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
using System;
using com.ibm.websphere.dtx.dtxpi.dtxinterop;

namespace com.ibm.websphere.dtx.dtxpi.example
{
	/// <summary>
	/// This example uses a user provided status handling method
	/// </summary>
	public class Example4
	{
		public Example4()
		{
		}

		[STAThread]
		static void Main(string[] args)
		{
			try
            		{
				MFactory imFactory = new MFactory();
				imFactory.InitializeAPI(null);

				// Load the Map
				MMap map = imFactory.MapLoadFile("test4.mmc");    
				map.ReportEvent += new IMMapEvents_ReportEventEventHandler(Example4.HandleEvent);
				map.MapSetupNotifications(MConstants.MPI_EVENT_ALL);

				map.Run();

				string responseMessage = map.GetTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
				int resuleCode = map.GetIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);

				Console.Out.WriteLine("Map Status: " + responseMessage + " " + resuleCode);

				// Unload the Map
				map.MapUnload();	      

				// Exit the API
				imFactory.TerminateAPI();
			}
			catch (Exception e)
			{
			        Console.Out.WriteLine("Error Description: "+e);
            		}
		}
	
		// Handle the events from the map
		static void HandleEvent(int nEventID, int nBurstNum, int nCardNum)
		{
			switch(nEventID)
			{
				case MConstants.MPI_EVENT_START_INPUT:
					Console.Out.WriteLine("Event received = MPI_EVENT_START_INPUT \n");
					break;
				case MConstants.MPI_EVENT_INPUT_COMPLETE:
					Console.Out.WriteLine("Event received = MPI_EVENT_INPUT_COMPLETE \n");
					break;
				case MConstants.MPI_EVENT_START_OUTPUT:
					Console.Out.WriteLine("Event received = MPI_EVENT_START_OUTPUT \n");
					break;
				case MConstants.MPI_EVENT_OUTPUT_COMPLETE:
					Console.Out.WriteLine("Event received = MPI_EVENT_OUTPUT_COMPLETE \n");
					break;
				case MConstants.MPI_EVENT_START_BURST:
					Console.Out.WriteLine("Event received = MPI_EVENT_START_BURST \n");
					break;
				case MConstants.MPI_EVENT_BURST_COMPLETE:
					Console.Out.WriteLine("Event received = MPI_EVENT_BURST_COMPLETE \n");
					break;
				case MConstants.MPI_EVENT_START_MAP:
					Console.Out.WriteLine("Event received = MPI_EVENT_START_MAP \n");
					break;
				case MConstants.MPI_EVENT_MAP_COMPLETE:
					Console.Out.WriteLine("Event received = MPI_EVENT_MAP_COMPLETE \n");
					break;
				default:
					Console.Out.WriteLine("Unknown event!!!");
					break;
			} 
		} 
	} 
} 
