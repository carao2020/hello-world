/*
 * Copyright (C) 2004 IBM Software Corporation.  All rights reserved.
 *
 * This software is the property of IBM Software Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Software Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MMapStatusCallback;


public class Callback extends MMapStatusCallback
{
    public void callback(MMap map, int iEventID, int iBurstNum, int iCardNum)
    {
        switch( iEventID )
        {
        case MConstants.MPI_EVENT_START_INPUT:
            System.out.println("Event received = MPI_EVENT_START_INPUT \n");
            break;

        case MConstants.MPI_EVENT_INPUT_COMPLETE:
            System.out.println("Event received = MPI_EVENT_INPUT_COMPLETE \n");
            break;

        case MConstants.MPI_EVENT_START_OUTPUT:
            System.out.println("Event received = MPI_EVENT_START_OUTPUT \n");
            break;

        case MConstants.MPI_EVENT_OUTPUT_COMPLETE:
            System.out.println("Event received = MPI_EVENT_OUTPUT_COMPLETE \n");
            break;

        case MConstants.MPI_EVENT_START_BURST:
            System.out.println("Event received = MPI_EVENT_START_BURST \n");
            break;

        case MConstants.MPI_EVENT_BURST_COMPLETE:
            System.out.println("Event received = MPI_EVENT_BURST_COMPLETE \n");
            break;

        case MConstants.MPI_EVENT_START_MAP:
            System.out.println("Event received = MPI_EVENT_START_MAP \n");
            break;

        case MConstants.MPI_EVENT_MAP_COMPLETE:
            System.out.println("Event received = MPI_EVENT_MAP_COMPLETE \n");
            break;
        default:
		    System.out.println("Unknown event!!!");
            break;

        }
    }
}
