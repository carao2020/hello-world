IBM WebSphere Transformation Extender 
JEXIT Example Readme

� Copyright International Business Machines Corporation 2012.
All Rights Reserved.


This example demonstrates how to use the IBM WebSphere Transformation 
Extender JEXIT function.


=====================================================================
CONTENTS
=====================================================================

    1.  Example files
    2.  Using this example


=====================================================================
1: EXAMPLE FILES
=====================================================================

This example includes the following files:

readme.txt     - this document

jexit.mms      - contains maps that use the JEXIT function to invoke 
                 Java� objects and methods
                 
jexit.mtt      - type tree used for invoking the JEXIT function and 
                 displaying results

TestJExit.java - defines simple methods and an Entity object

Entity.java    - defines a base class that the JEXIT function invokes

Product.java   - defines an Entity-derived class that the JEXIT 
                 function invokes

Company.java   - defines an Entity-derived class that the JEXIT 
                 function invokes

TestJExit.jar  - contains the TestJExit, Entity, Product, and Company 
                 classes

make.bat       - builds TestJExit.jar module on Windows platforms

make.sh        - builds TestJExit.jar module on UNIX platforms


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example illustrates various usages of the JEXIT function within
IBM WebSphere Transformation Extender.

To build and run the example, follow these steps:

1) Optional: Recompile the TestJExit.jar module.

   For running the example on Windows platforms, do the following 
   steps:
   a. Open a DOS command prompt window.
   b. Set the JAVA_HOME environment variable.
   c. Compile the Java files by running: make.bat
   	
2) Copy the TestJExit.jar module to one of the following locations:
   o the "[External Jar Files]" section of the dtx.ini file
   o the Windows installation directory or the UNIX "libs" 
     sub-directory
   o the CLASSPATH, which works for all execution environments, 
     except the Design Studio
   
3) In the Design Studio, open the jexit.mms source map and build
   the maps for the specific platform on which they will be run.
   
   These example maps show how to create java objects and invoke 
   their methods.

   jexit_upper_method.mmc     - converts a string to upper case
   jexit_concat_method.mmc    - concatenates two strings together
   jexit_single_object.mmc    - creates, invokes and destroys an 
                                object
   jexit_multiple_objects.mmc - manipulates multiple objects and 
                                data types
                                   
4) Run the example maps.

   To troubleshoot problems with the JEXIT function, enable the map 
   to log information to a trace file through parameters in the 
   dtx.ini file. This .ini file is global to all JEXIT function 
   invocations.
   
   For example, the following parameters can be used on a Windows 
   platform:
   [JVM Options]
   option1=-Djexit.trace.file=c:\jexit.log
   option2=-Djexit.trace.level=verbose

   Specify one of the following available trace levels:
   verbose  - greatest level of detail
   info     - function entry, exit and return status
   warning  - warning and error messages
   error    - error messages only, which is the default setting
   
   Each trace level is a superset of the previous trace level. The 
   "verbose" level includes all other levels. However, the "error" 
   level does not include any other level besides itself.

   If a map uses a JEXIT function to return a complex Java object, 
   make sure that the map also uses the "<destroy>" method of the 
   JEXIT function to explicitly delete that Java object from the 
   Java Virtual Machine (JVM) memory. Otherwise, a JVM memory leak 
   can occur when you run the map in the following runtime 
   environments: WebSphere Transformation Extender with Launcher, 
   WebSphere Transformation Extender for Message Broker, and C-based 
   TX Programming API invocations. When you run the map in the 
   WebSphere Transformation Extender for Sterling B2B Integrator, 
   the WebSphere Transformation Extender for WebSphere Enterprise 
   Service Bus (WebSphere ESB), or Java-based TX Programming API 
   invocations, the occurrence of a JVM memory leak 
   is not a problem due to the way the map references are 
   automatically deleted in Java.

   When the trace file is enabled, the map logs this JVM memory leak 
   by indicating that the number of maps still referencing the 
   Object Pool in WebSphere Transformation Extender has exceeded 
   its limit, as set by "jexit.objectpool.maplimit". The default 
   limit is 100. So after 100 or more maps continue to reference 
   complex Java objects in the Object Pool, an error message is sent 
   to the JEXIT trace file.


=====================================================================
                             END OF FILE
=====================================================================
