package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;

import com.ibm.websphere.dtx.ds.MDSException;
import com.ibm.websphere.dtx.ds.typetree.TTCategory;
import com.ibm.websphere.dtx.ds.typetree.TTDelimitedSyntax;
import com.ibm.websphere.dtx.ds.typetree.TTGroup;
import com.ibm.websphere.dtx.ds.typetree.TTGroupProperties;
import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTTypeSyntax;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.SYNTAX_CHAR_TYPE;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.TYPE_GROUP_SYNTAX;

/**
 * This example demonstrates how to build a type tree from the data description from csv file (header row).
 * The header row has comma separated names of the fields. Each record in the file is separated by the new line.
 * <p>
 * Type Tree APIs demonstrated by this example:
 * <li> adding types
 * <li> setting of group properties
 * <li> setting non-printable characters
 *
 */
public class ContactListExample {
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	private static String DefaultSourceLocation = "files/Contact.txt";
	// by default output files are located in 'DefaultLocation' relative to class file
	private static String DefaultTargetLocation = "output/Contact.mtt";
	
	private String _sourceLocation = DefaultSourceLocation;
	private String _targetLocation = DefaultTargetLocation;
	
	/**
	 * @param fileLocation
	 */
	public ContactListExample() {
		super();
	}

	/**
	 * This method runs the example
	 */
	public void run(){
		
		String[] items = loadCSVFile();
		
		TTSource typeTreeSource = TTSource.createTypeTree("Data", getTargetLocation());
		if(typeTreeSource == null){
			System.out.println("Can not create type tree with location: " + getTargetLocation());
			return;
		}
		
		try {
			// create types
			TTCategory root = typeTreeSource.getRootType();
			TTGroup contact = root.addGroup("Contact");
			
			// setting of group properties
			TTGroupProperties groupProp = contact.getGroupProperties();
			groupProp.setFormatAsImplicit(false);
			groupProp.setGroupSyntaxType(TYPE_GROUP_SYNTAX.DELIMITED);
			
			TTDelimitedSyntax groupSyntax = (TTDelimitedSyntax)groupProp.getGroupSyntax();
			groupSyntax.getDelimiter().setValue(",");
			
			TTGroup contactFile = root.addGroup("ContactFile");
			
			TTTypeSyntax typeSyntax = contactFile.getTypeProperties().getTypeSyntax();
			typeSyntax.setTerminator(SYNTAX_CHAR_TYPE.LITERAL);
			
			//setting non-printable characters
			String symbol = getDisplaySymbolFromRealSymbol("LF") +
							getDisplaySymbolFromRealSymbol("CR");
			
			typeSyntax.getTerminator().setValue(symbol);
		
			TTItem fileItem = root.addItem("Field");
			TTItem name = fileItem.addItem("Name");
			
			// create components
			contactFile.addComponent(contact);
			
			// adding types
			for (int i = 0; i < items.length; i++) {
				TTItem item = null;
				if(items[i].equals("First") || items[i].equals("Last")){
					item = name.addItem(items[i]);
				}
				else{
					item = fileItem.addItem(items[i]);
				}
				if(item != null){
					contact.addComponent(item);
				}			
			}

		} catch (MDSException e) {
			
			e.printStackTrace();
		}

		typeTreeSource.save();
		
		typeTreeSource.close();
	}
	
	protected String[] loadCSVFile() {
		
		// Load type tree from a file.
		String fileLocation = getSourceLocation();
		if(DefaultSourceLocation.equals(getSourceLocation())){
			URL url = getClass().getResource(DefaultSourceLocation);
			fileLocation = url.getFile().replace("%20", " ");
		}
		try {
			StringBuffer content = new StringBuffer();
			BufferedReader reader = new BufferedReader(new FileReader(fileLocation));
			String line;
			int counter = 0;
			while((line = reader.readLine()) != null && counter==0) {
				content.append(line);
				counter++;
			}
			reader.close();
			String data = content.toString();
			return data.split(",");
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		
		return new String[0];	
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultSourceLocation;
		ContactListExample target = new ContactListExample();
		target.setSourceLocation(location);
		target.run();
	}

	public String getSourceLocation() {
		return _sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		_sourceLocation = sourceLocation;
	}

	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}

	private static String getDisplaySymbolFromRealSymbol(String aSymbol)
	{
		if(aSymbol == null) return "<>";
		return "<"+aSymbol+">";
		
	}

}
