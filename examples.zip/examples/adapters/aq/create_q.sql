CREATE TYPE simple AS OBJECT (
   name VARCHAR(30),
   age  NUMBER(3));
/
   
begin
	DBMS_AQADM.CREATE_QUEUE_TABLE (
	queue_table        => 'qatest.simpleadt',
   queue_payload_type => 'qatest.simple');
end;
/

begin
	DBMS_AQADM.CREATE_QUEUE (
	queue_name         => 'simplein',
	queue_table        => 'qatest.simpleadt');
end;
/
	
begin
	DBMS_AQADM.START_QUEUE (
	queue_name         => 'simplein');
end;
/

begin
	DBMS_AQADM.CREATE_QUEUE (
	queue_name         => 'simpleout',
	queue_table        => 'qatest.simpleadt');
end;
/
	
begin
	DBMS_AQADM.START_QUEUE (
	queue_name         => 'simpleout');
end;
/
