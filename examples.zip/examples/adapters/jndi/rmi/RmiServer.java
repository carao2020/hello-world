import java.rmi.*;
import java.rmi.registry.*;

public class RmiServer
{
	public static void main(String[] args)
	{
		try
		{
			System.out.println("Starting RMI Server...");
			Registry reg = LocateRegistry.createRegistry(1099);
			System.out.println("RMI Server running.");
			for (;;Thread.sleep(100));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
