/* 
 * Copyright (C) 2015 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
namespace com.ibm.websphere.dtx.dtxpi.example
{
	using System;
	
	/*===========================================================================*
	*= class: MConstants
	*===========================================================================*/
	/// <summary>Various MPI constants.
	/// *
	/// </summary>
	public class MConstants
	{
		// Property types
		public const int MPI_PROP_TYPE_NONE     = 0;
		public const int MPI_PROP_TYPE_INT      = 1;
		public const int MPI_PROP_TYPE_TEXT     = 2;
		public const int MPI_PROP_TYPE_BINARY   = 3;
		public const int MPI_PROP_TYPE_OBJECT   = 4;
		public const int MPI_PROP_TYPE_PTR      = 5;
		public const int MPI_PROP_TYPE_INDEXED  = 0x8000;
		
		// Object types
		public const int MPI_OBJTYPE_BASE       = 0x0000;
		public const int MPI_OBJTYPE_OBJECT     = 0x1000;
		public const int MPI_OBJTYPE_MAP        = 0x1001;
		public const int MPI_OBJTYPE_CARD       = 0x1002;
		public const int MPI_OBJTYPE_ADAPTER    = 0x1003;
		public const int MPI_OBJTYPE_CONNECTION = 0x1004;
		public const int MPI_OBJTYPE_TRACE      = 0x0005;
		public const int MPI_OBJTYPE_ADAPTCOLL  = 0x0006;
		public const int MPI_OBJTYPE_MESSAGE    = 0x0007;
		public const int MPI_OBJTYPE_MESSAGECOLL= 0x0008;
		public const int MPI_OBJTYPE_STREAMPAGE = 0x0009;
		public const int MPI_OBJTYPE_STREAM     = 0x000a;
		
		// MAdapter types for "special" adapters
		public const int MPI_ADAPTYPE_FILE          = 0;
		public const int MPI_ADAPTYPE_BUFFER        = 4;
		public const int MPI_ADAPTYPE_DATABASE      = 5;
		public const int MPI_ADAPTYPE_APP           = 6;
        public const int MPI_ADAPTYPE_STATICINPUT   = 10;
		public const int MPI_ADAPTYPE_ANY           = 30;
		public const int MPI_ADAPTYPE_STREAM        = 31;
        public const int MPI_ADAPTYPE_XDS           = 32;
        public const int MPI_ADAPTYPE_SDO           = 33;
        public const int MPI_ADAPTYPE_SINK          = 113;

		// Object property index bases
		public const int MPI_PROPBASE_OBJECT        = 0;
		public const int MPI_PROPBASE_MAP           = 100;
		public const int MPI_PROPBASE_CARD          = 200;
		public const int MPI_PROPBASE_ADAPTER       = 300;
		public const int MPI_PROPBASE_CONNECTION    = 400;
		public const int MPI_PROPBASE_USER          = 1000;

        //UPGRADE_NOTE: Final was removed from the declarations, see: 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="jlca1003"'

		// MBase object properties
		public static int MPIP_OBJECT_ERROR_CODE    = MPI_PROPBASE_OBJECT + 0;		
		public static int MPIP_OBJECT_ERROR_MSG     = MPI_PROPBASE_OBJECT + 1;
		public static int MPIP_OBJECT_PARENT        = MPI_PROPBASE_OBJECT + 2;
		
		// MAdapter properties
		public static int MPIP_ADAPTER_TYPE                     = MPI_PROPBASE_ADAPTER + 0;
		public static int MPIP_ADAPTER_ABBREV                   = MPI_PROPBASE_ADAPTER + 1;
		public static int MPIP_ADAPTER_PROVIDER_CODE            = MPI_PROPBASE_ADAPTER + 2;
		public static int MPIP_ADAPTER_PROVIDER_MSG             = MPI_PROPBASE_ADAPTER + 3;
		public static int MPIP_ADAPTER_WILDCARD                 = MPI_PROPBASE_ADAPTER + 4;
		public static int MPIP_ADAPTER_CONTEXT                  = MPI_PROPBASE_ADAPTER + 5;
		public static int MPIP_ADAPTER_ON_SUCCESS               = MPI_PROPBASE_ADAPTER + 6;
		public static int MPIP_ADAPTER_ON_FAILURE               = MPI_PROPBASE_ADAPTER + 7;
		public static int MPIP_ADAPTER_RETRY                    = MPI_PROPBASE_ADAPTER + 8;
		public static int MPIP_ADAPTER_RETRY_ATTEMPTS           = MPI_PROPBASE_ADAPTER + 9;
		public static int MPIP_ADAPTER_RETRY_INTERVAL           = MPI_PROPBASE_ADAPTER + 10;
		public static int MPIP_ADAPTER_SCOPE                    = MPI_PROPBASE_ADAPTER + 11;
		public static int MPIP_ADAPTER_WARNINGS                 = MPI_PROPBASE_ADAPTER + 12;
		public static int MPIP_ADAPTER_FETCH_UNIT               = MPI_PROPBASE_ADAPTER + 13;
		public static int MPIP_ADAPTER_QUANTITY                 = MPI_PROPBASE_ADAPTER + 14;
		public static int MPIP_ADAPTER_LISTEN_TIME              = MPI_PROPBASE_ADAPTER + 15;
		public static int MPIP_ADAPTER_MSG_COLLECTION           = MPI_PROPBASE_ADAPTER + 16;
		public static int MPIP_ADAPTER_USER_DATA                = MPI_PROPBASE_ADAPTER + 17;
		public static int MPIP_ADAPTER_COMMANDLINE              = MPI_PROPBASE_ADAPTER + 18;
		public static int MPIP_ADAPTER_DATA_TO_ADAPT            = MPI_PROPBASE_ADAPTER + 19;
		public static int MPIP_ADAPTER_DATA_FROM_ADAPT          = MPI_PROPBASE_ADAPTER + 20;
		public static int MPIP_ADAPTER_LISTEN_USESAMECONN       = MPI_PROPBASE_ADAPTER + 21;
		public static int MPIP_ADAPTER_SQL_STMT                 = MPI_PROPBASE_ADAPTER + 22;
		public static int MPIP_ADAPTER_TRACE_OBJECT             = MPI_PROPBASE_ADAPTER + 23;
		public static int MPIP_ADAPTER_NUM_MESSAGES             = MPI_PROPBASE_ADAPTER + 24;
		public static int MPIP_ADAPTER_DB_INFO                  = MPI_PROPBASE_ADAPTER + 25;
		public static int MPIP_ADAPTER_GLOBAL_TX                = MPI_PROPBASE_ADAPTER + 26;
		public static int MPIP_ADAPTER_RES_ALIAS_HANDLE         = MPI_PROPBASE_ADAPTER + 27;
	    public static int MPIP_ADAPTER_RES_ALIAS_SYSTEM         = MPI_PROPBASE_ADAPTER + 28;
	    public static int MPIP_ADAPTER_ENABLE_TRANSACTIONS	    = MPI_PROPBASE_ADAPTER + 29;
	    public static int MPIP_ADAPTER_CALLBACK_PTR             = MPI_PROPBASE_ADAPTER + 30;
	    public static int MPIP_ADAPTER_CAN_SET_INPUT_DATA_OBJECT= MPI_PROPBASE_ADAPTER + 31;
	    public static int MPIP_ADAPTER_CAN_GET_OUTPUT_DATA_OBJECT = MPI_PROPBASE_ADAPTER + 32;
        public static int MPIP_ADAPTER_JNI_ENV_PTR              = MPI_PROPBASE_ADAPTER + 33;
	    public static int MPIP_ADAPTER_EXT_DATA_HANDLER_PTR     = MPI_PROPBASE_ADAPTER + 34;
		
		// MConnection properties
		public static int MPIP_CONNECTION_USER_DATA         = MPI_PROPBASE_CONNECTION + 0;
		public static int MPIP_CONNECTION_INUSE             = MPI_PROPBASE_CONNECTION + 1;
		public static int MPIP_CONNECTION_NUMBER            = MPI_PROPBASE_CONNECTION + 2;
		public static int MPIP_CONNECTION_TRANSACTION_COUNT = MPI_PROPBASE_CONNECTION + 3;
		public static int MPIP_CONNECTION_STATE             = MPI_PROPBASE_CONNECTION + 4;
		public static int MPIP_CONNECTION_STATE_TIMESTAMP   = MPI_PROPBASE_CONNECTION + 5;
		public static int MPIP_CONNECTION_ON_SUCCESS        = MPI_PROPBASE_CONNECTION + 6;
		public static int MPIP_CONNECTION_ON_FAILURE        = MPI_PROPBASE_CONNECTION + 7;
		public static int MPIP_CONNECTION_SCOPE             = MPI_PROPBASE_CONNECTION + 8;
		public static int MPIP_CONNECTION_GLOBAL_TX         = MPI_PROPBASE_CONNECTION + 9;
		public static int MPIP_CONNECTION_MODE              = MPI_PROPBASE_CONNECTION + 10;
		
		// MMap properties
		public static int MPIP_MAP_MAP_NAME                     = MPI_PROPBASE_MAP + 0;
		public static int MPIP_MAP_INSTANCE                     = MPI_PROPBASE_MAP + 1;
		public static int MPIP_MAP_WATCH_NUMBER                 = MPI_PROPBASE_MAP + 2;
		public static int MPIP_MAP_GTX_CONTEXT                  = MPI_PROPBASE_MAP + 3;
		public static int MPIP_MAP_GTX_MANAGER                  = MPI_PROPBASE_MAP + 4;
		public static int MPIP_MAP_TRANSACTION_COUNT            = MPI_PROPBASE_MAP + 5;
		public static int MPIP_MAP_AUDIT_SWITCH                 = MPI_PROPBASE_MAP + 6;
		public static int MPIP_MAP_AUDIT_BURST_DATA             = MPI_PROPBASE_MAP + 7;
		public static int MPIP_MAP_AUDIT_BURST_EXECUTION        = MPI_PROPBASE_MAP + 8;
		public static int MPIP_MAP_AUDIT_SUMMARY_EXECUTION      = MPI_PROPBASE_MAP + 9;
		public static int MPIP_MAP_AUDIT_SETTINGS_MAP           = MPI_PROPBASE_MAP + 10;
		public static int MPIP_MAP_AUDIT_SETTINGS_DATA          = MPI_PROPBASE_MAP + 11;
		public static int MPIP_MAP_AUDIT_LOCATION               = MPI_PROPBASE_MAP + 12;
		public static int MPIP_MAP_AUDIT_DIRECTORY              = MPI_PROPBASE_MAP + 13;
		public static int MPIP_MAP_AUDIT_DIRECTORY_CUSTOM_VALUE = MPI_PROPBASE_MAP + 14;
		public static int MPIP_MAP_AUDIT_FILENAME               = MPI_PROPBASE_MAP + 15;
		public static int MPIP_MAP_AUDIT_FILENAME_ACTION        = MPI_PROPBASE_MAP + 16;
		public static int MPIP_MAP_AUDIT_FILENAME_CUSTOM_VALUE  = MPI_PROPBASE_MAP + 17;
		public static int MPIP_MAP_AUDIT_MEMORY_SIZED           = MPI_PROPBASE_MAP + 18;
		public static int MPIP_MAP_TRACE_SWITCH                 = MPI_PROPBASE_MAP + 19;
		public static int MPIP_MAP_TRACE_LOCATION               = MPI_PROPBASE_MAP + 20;
		public static int MPIP_MAP_TRACE_DIRECTORY              = MPI_PROPBASE_MAP + 21;
		public static int MPIP_MAP_TRACE_DIRECTORY_CUSTOM_VALUE = MPI_PROPBASE_MAP + 22;
		public static int MPIP_MAP_TRACE_FILENAME               = MPI_PROPBASE_MAP + 23;
		public static int MPIP_MAP_TRACE_FILENAME_CUSTOM_VALUE  = MPI_PROPBASE_MAP + 24;
		public static int MPIP_MAP_TRACE_INPUT_CONTENT          = MPI_PROPBASE_MAP + 25;
		public static int MPIP_MAP_TRACE_INPUT_CARD_NUMBER      = MPI_PROPBASE_MAP + 26;
		public static int MPIP_MAP_TRACE_INPUT_CARD_START       = MPI_PROPBASE_MAP + 27;
		public static int MPIP_MAP_TRACE_INPUT_CARD_END         = MPI_PROPBASE_MAP + 28;
		public static int MPIP_MAP_TRACE_RULES_CONTENT          = MPI_PROPBASE_MAP + 29;
		public static int MPIP_MAP_TRACE_RULES_CARD_NUMBER      = MPI_PROPBASE_MAP + 30;
		public static int MPIP_MAP_TRACE_SUMMARY_CONTENT        = MPI_PROPBASE_MAP + 31;
		public static int MPIP_MAP_WORKSPACE_LOCATION           = MPI_PROPBASE_MAP + 32;
		public static int MPIP_MAP_WORKSPACE_DIRECTORY          = MPI_PROPBASE_MAP + 33;
		public static int MPIP_MAP_WORKSPACE_DIRECTORY_CUSTOM   = MPI_PROPBASE_MAP + 34;
		public static int MPIP_MAP_WORKSPACE_FILE_PREFIX        = MPI_PROPBASE_MAP + 35;
		public static int MPIP_MAP_WORKSPACE_FILE_ACTION        = MPI_PROPBASE_MAP + 36;
		public static int MPIP_MAP_WORKSPACE_PAGING_SIZE        = MPI_PROPBASE_MAP + 37;
		public static int MPIP_MAP_WORKSPACE_PAGING_COUNT       = MPI_PROPBASE_MAP + 38;
		public static int MPIP_MAP_SLIDING_CENTURY              = MPI_PROPBASE_MAP + 39;
		public static int MPIP_MAP_SLIDING_CENTURY_CCLOOKUP     = MPI_PROPBASE_MAP + 40;
		public static int MPIP_MAP_CUSTOM_VALIDATION            = MPI_PROPBASE_MAP + 41;
		public static int MPIP_MAP_CV_VALIDATION_ERROR          = MPI_PROPBASE_MAP + 42;
		public static int MPIP_MAP_CV_RESTRICTION_ERROR         = MPI_PROPBASE_MAP + 43;
		public static int MPIP_MAP_CV_SIZE_ERROR                = MPI_PROPBASE_MAP + 44;
		public static int MPIP_MAP_CV_PRESENTATION_ERROR        = MPI_PROPBASE_MAP + 45;
		public static int MPIP_MAP_MAP_RETRY                    = MPI_PROPBASE_MAP + 46;
		public static int MPIP_MAP_MAP_RETRY_ATTEMPTS           = MPI_PROPBASE_MAP + 47;
		public static int MPIP_MAP_MAP_RETRY_INTERVAL           = MPI_PROPBASE_MAP + 48;
		public static int MPIP_MAP_BURST_RESTART                = MPI_PROPBASE_MAP + 49;
		public static int MPIP_MAP_BURST_RESTART_ERROR_LIMIT    = MPI_PROPBASE_MAP + 50;
		public static int MPIP_MAP_WARNINGS_EVERY               = MPI_PROPBASE_MAP + 51;
		public static int MPIP_MAP_WARNINGS_14                  = MPI_PROPBASE_MAP + 52;
		public static int MPIP_MAP_WARNINGS_18                  = MPI_PROPBASE_MAP + 53;
		public static int MPIP_MAP_WARNINGS_21                  = MPI_PROPBASE_MAP + 54;
		public static int MPIP_MAP_WARNINGS_26                  = MPI_PROPBASE_MAP + 55;
		public static int MPIP_MAP_WARNINGS_27                  = MPI_PROPBASE_MAP + 56;
		public static int MPIP_MAP_WARNINGS_28                  = MPI_PROPBASE_MAP + 57;
		public static int MPIP_MAP_WARNINGS_29                  = MPI_PROPBASE_MAP + 58;
		public static int MPIP_MAP_BURST_NUMBER                 = MPI_PROPBASE_MAP + 59;
		public static int MPIP_MAP_INITPENDING_HIGH             = MPI_PROPBASE_MAP + 60;
		public static int MPIP_MAP_INITPENDING_LOW              = MPI_PROPBASE_MAP + 61;
	    public static int MPIP_MAP_WARNINGS_34                  = MPI_PROPBASE_MAP + 62;
	    public static int MPIP_MAP_AUDIT_BURST_DATA_SIZE_VALIDATION = MPI_PROPBASE_MAP + 63;
	    public static int MPIP_MAP_DESTROY_OBJECT_POOL          = MPI_PROPBASE_MAP + 64;
	    public static int MPIP_MAP_COMMON_TRACE_SWITCH          = MPI_PROPBASE_MAP + 65;
	    public static int MPIP_MAP_COMMON_TRACE_ACTION          = MPI_PROPBASE_MAP + 66;
	    public static int MPIP_MAP_COMMON_TRACE_FILE            = MPI_PROPBASE_MAP + 67;
	    public static int MPIP_MAP_RUNTIME_APPLICATION          = MPI_PROPBASE_MAP + 68;
	    public static int MPIP_MAP_ENABLE_TRANSACTIONS          = MPI_PROPBASE_MAP + 69;
	    public static int MPIP_MAP_PUT_CALLBACK_PTR             = MPI_PROPBASE_MAP + 70;
	    public static int MPIP_MAP_TRACE_CALLBACK_PTR			= MPI_PROPBASE_MAP + 71;
	    public static int MPIP_MAP_MULTITHREADED			    = MPI_PROPBASE_MAP + 72;
	    public static int MPIP_MAP_USE_RESOURCE_MANAGER			= MPI_PROPBASE_MAP + 73;
	    public static int MPIP_MAP_ENTITY_RESOLVER				= MPI_PROPBASE_MAP + 74;
	    public static int MPIP_MAP_REMOTE_AUDIT					= MPI_PROPBASE_MAP + 75;
	    public static int MPIP_MAP_REMOTE_WARNINGS				= MPI_PROPBASE_MAP + 76;
	    public static int MPIP_MAP_RUNMAP_CALLBACK_PTR			= MPI_PROPBASE_MAP + 77;
	    public static int MPIP_MAP_GET_CALLBACK_PTR				= MPI_PROPBASE_MAP + 78;
	    public static int MPIP_MAP_XPATH_CALLBACK_PTR			= MPI_PROPBASE_MAP + 79;
	    public static int MPIP_MAP_XSLT_CALLBACK_PTR			= MPI_PROPBASE_MAP + 80;	
	    public static int MPIP_MAP_SUBST_CHARS					= MPI_PROPBASE_MAP + 81;
	    public static int MPIP_MAP_SUBST_LENGTH					= MPI_PROPBASE_MAP + 82;
	    public static int MPIP_MAP_XVALIDATE_CALLBACK_PTR		= MPI_PROPBASE_MAP + 83;
	    public static int MPIP_MAP_DATA_SIZE 					= MPI_PROPBASE_MAP + 84;
	    public static int MPIP_MAP_USES_MEMORY_LINK 			= MPI_PROPBASE_MAP + 85;
	    public static int MPIP_MAP_LPIS_PTR 					= MPI_PROPBASE_MAP + 86;
        public static int MPIP_MAP_CODEPAGE_FALLBACK            = MPI_PROPBASE_MAP + 87;
        public static int MPIP_MAP_TRACE_FORMAT                 = MPI_PROPBASE_MAP + 88;
        public static int MPIP_MAP_CV_COMPONENT_RULE            = MPI_PROPBASE_MAP + 89;
		
		// MCard properties
		public static int MPIP_CARD_NAME                            = MPI_PROPBASE_CARD + 0;
		public static int MPIP_CARD_NUMBER                          = MPI_PROPBASE_CARD + 1;
		public static int MPIP_CARD_DIRECTION                       = MPI_PROPBASE_CARD + 2;
		public static int MPIP_CARD_OBJECT_COUNT                    = MPI_PROPBASE_CARD + 3;
		public static int MPIP_CARD_BACKUP                          = MPI_PROPBASE_CARD + 4;
		public static int MPIP_CARD_BACKUP_WHEN                     = MPI_PROPBASE_CARD + 5;
		public static int MPIP_CARD_BACKUP_DIRECTORY                = MPI_PROPBASE_CARD + 6;
		public static int MPIP_CARD_BACKUP_DIRECTORY_CUSTOM_VALUE   = MPI_PROPBASE_CARD + 7;
		public static int MPIP_CARD_BACKUP_FILENAME                 = MPI_PROPBASE_CARD + 8;
		public static int MPIP_CARD_BACKUP_FILENAME_CUSTOM_VALUE    = MPI_PROPBASE_CARD + 9;
		public static int MPIP_CARD_BACKUP_ACTION                   = MPI_PROPBASE_CARD + 10;
		public static int MPIP_CARD_BACKUP_FILEPATH                 = MPI_PROPBASE_CARD + 11;
		public static int MPIP_CARD_MODE                            = MPI_PROPBASE_CARD + 12;
		public static int MPIP_CARD_REUSE_WORK_AREA                 = MPI_PROPBASE_CARD + 13;
		public static int MPIP_CARD_DOCUMENT_VERIFICATION           = MPI_PROPBASE_CARD + 14;
		public static int MPIP_CARD_ERROR_CONTEXT                   = MPI_PROPBASE_CARD + 15;
	    public static int MPIP_CARD_METADATA_LOCATION				= MPI_PROPBASE_CARD + 16;
	    public static int MPIP_CARD_ROOT_TYPE_NAME				    = MPI_PROPBASE_CARD + 17;
	    public static int MPIP_CARD_XML_NAMESPACE					= MPI_PROPBASE_CARD + 18;
	    public static int MPIP_CARD_IS_XDS_ENABLED				    = MPI_PROPBASE_CARD + 19;
	    public static int MPIP_CARD_IS_SYNTAX						= MPI_PROPBASE_CARD + 20;
		
		// Seek offset values
		public const int MPI_SEEK_SET               = 0;
		public const int MPI_SEEK_CUR               = 1;
		public const int MPI_SEEK_END               = 2;
		
		// Compare values
		public static int MPI_CMP_LESS              = -1;
		public const int MPI_CMP_EQUAL              = 0;
		public const int MPI_CMP_GREATER            = 1;
		public static int MPI_CMP_DIFFER            = -2;
		
		// End-transaction types
		public const int MPI_COMMIT                 = 0;
		public const int MPI_ROLLBACK               = 1;
		
		// General
		public const int MPI_FALSE                  = 0;
		public const int MPI_TRUE                   = 1;
		public const int MPI_SWITCH_OFF             = 0;
		public const int MPI_SWITCH_ON              = 1;
		
		// Location
		public const int MPI_LOCATION_FILE          = 0;
		public const int MPI_LOCATION_MEMORY        = 1;
		
		// Directory
		public const int MPI_DIRECTORY_MAP          = 1;
		public const int MPI_DIRECTORY_CUSTOM       = 0;
		
		// File name
		public const int MPI_FILENAME_UNIQUE        = 2;
		public const int MPI_FILENAME_DEFAULT       = 1;
		public const int MPI_FILENAME_CUSTOM        = 0;
		
		// File actions
		public const int MPI_FILE_CREATE            = 0;
		public const int MPI_FILE_DELETE            = 1;
		
		// Trace
		public const int MPI_TRACE_OFF              = 0;
		public const int MPI_TRACE_ALL              = 1;
		public const int MPI_TRACE_CARD             = 2;
		public const int MPI_TRACE_RANGE            = 3;
		
		// public static int MPIP_MAP_STATE
		public const int MPI_STATE_IDLE             = 5;
		public const int MPI_STATE_RUNNING          = 6;
		public const int MPI_STATE_PAUSED           = 7;
		public const int MPI_STATE_ABORTED          = 8;
		public const int MPI_STATE_FINISHED         = 9;
		
		// MPIP_CARD_BACKUP_WHEN
		public const int MPI_WHEN_ALWAYS            = 10;
		public const int MPI_WHEN_ONERROR           = 11;
		
		// MPIP_CARD_MODE
		public const int MPI_MODE_INTEGRAL          = 1;
		public const int MPI_MODE_BURST             = 0;
		
		// MPIP_ADAPTER_CONTEXT
		public const int MPI_CONTEXT_SOURCE         = 14;
		public const int MPI_CONTEXT_SOURCE_EVENT   = 15;
		public const int MPI_CONTEXT_TARGET         = 16;
		public const int MPI_CONTEXT_GET            = 17;
		public const int MPI_CONTEXT_PUT            = 18;
		public const int MPI_CONTEXT_DBLOOKUP       = 19;
		public const int MPI_CONTEXT_DBQUERY        = 20;
		
		// ADAPTER TYPES
		public const int MPI_ADAPT_TYPE_DB          = 21;
		public const int MPI_ADAPT_TYPE_FILE        = 22;
		public const int MPI_ADAPT_TYPE_MSG         = 23;
		public const int MPI_ADAPT_TYPE_APP         = 24;
		
		// TRANSACTION MODES
		public const int MPI_TRANSACTIONS_SINGLE    = 25;
		public const int MPI_TRANSACTIONS_NONE      = 25;
		public const int MPI_TRANSACTIONS_MULTIPLE  = 27;
		
		// UNIT-OF-WORK
		public const int MPI_UNITOFWORK_MESSAGE     = 28;
		public const int MPI_UNITOFWORK_LOGICAL     = 29;
		
		// MPIP_MAP_EVENT
		public const int MPI_EVENT_START_INPUT      = 0x0001;
		public const int MPI_EVENT_INPUT_COMPLETE   = 0x0002;
		public const int MPI_EVENT_START_OUTPUT     = 0x0004;
		public const int MPI_EVENT_OUTPUT_COMPLETE  = 0x0008;
		public const int MPI_EVENT_START_BURST      = 0x0010;
		public const int MPI_EVENT_BURST_COMPLETE   = 0x0020;
		public const int MPI_EVENT_START_MAP        = 0x0040;
		public const int MPI_EVENT_MAP_COMPLETE     = 0x0080;		
		public const int MPI_EVENT_ALL              = 0x00ff;
		public static int MPI_EVENT_MAP_EVENTS      = MPI_EVENT_START_MAP | MPI_EVENT_MAP_COMPLETE;
		public static int MPI_EVENT_BURST_EVENTS    = MPI_EVENT_START_BURST | MPI_EVENT_BURST_COMPLETE;
		public const int MPI_EVENT_CARD_EVENTS      = 0x000f;
		
		// Actions for custom validation
		public const int MPI_ACTION_CONTINUE        = 0x0000;
		public const int MPI_ACTION_STOP            = 0x0001;
		public const int MPI_ACTION_IGNORE          = 0x0000;
		public const int MPI_ACTION_VALIDATE        = 0x0001;
		public const int MPI_ACTION_WARN            = 0x0010;
		public const int MPI_ACTION_FAIL            = 0x0020;
		
		// Actions for targets
		public const int MPI_ACTION_CREATE          = 0x0001;
		public const int MPI_ACTION_DONT_CREATE     = 0x0002;
		public const int MPI_ACTION_CREATEONCONTENT = 0x0004;
		public const int MPI_ACTION_APPEND          = 0x0008;
		public const int MPI_ACTION_UPDATE          = 0x0010;
		
		// Actions for sources
		public const int MPI_ACTION_KEEP            = 0x0001;
		public const int MPI_ACTION_DELETE          = 0x0002;
		public const int MPI_ACTION_KEEPONCONTENT   = 0x0004;
		
		// OnFailure actions
		public const int MPI_ACTION_ROLLBACK        = 0x0001;
		public const int MPI_ACTION_COMMIT          = 0x0002;
		
		// MPIP_ADAPTER_SCOPE
		public const int MPI_SCOPE_MAP              = 0x0001;
		public const int MPI_SCOPE_BURST            = 0x0002;
		public const int MPI_SCOPE_CARD             = 0x0004;
		
		// MPIP_CARD_DIRECTION
		public const int MPI_CARD_INPUT             = 0x1;
		public const int MPI_CARD_OUTPUT            = 0x0;
		
		// MPIP_CARD_REUSE_WORK_AREA
		public const int MPI_WORK_AREA_REUSE        = 0x2;
		public const int MPI_WORK_AREA_DONTREUSE    = 0x0;
		
		// MPIP_ADAPTER_FETCH_UNIT/MPIP_ADAPTER_QUANTITY
		public const int MPI_NUMBER_SOME            = 0;
		
		// MPIP_ADAPTER_LISTEN_TIME
		public static int MPI_INFINITE              = -1;
		
		// Global Transaction managers
		public const int MPI_TM_MQS                 = 1;
		public const int MPI_TM_MSDTC               = 2;
		
		// MPIP_CONNECTION_STATE
		public const int MPI_CONNECTION_STATE_DOWN  = 0;
		public const int MPI_CONNECTION_STATE_UP    = 1;
		
		// Notifications
		public const int MPIN_ADAPTER_GETSTART      = 1;
		public const int MPIN_ADAPTER_GETSTOP       = 2;
		public const int MPIN_ADAPTER_PUTSTART      = 3;
		public const int MPIN_ADAPTER_PUTSTOP       = 4;
		public const int MPIN_ADAPTER_LISTENSTART   = 5;
		public const int MPIN_ADAPTER_LISTENSTOP    = 6;
		public const int MPIN_ADAPTER_LISTENABORT   = 7;
		public const int MPIN_ADAPTER_MAPABORT      = 8;
		public const int MPIN_OBJECT_PREPARE_DESTROY= 9;
		
		// bases for error codes
		public const int MPIRC_TYPE_SUCCESS         = 0;
		public static int MPIRC_TYPE_ERROR          = -1;
		public const int MPIRC_TYPE_WARNING         = 1;
		public const int MPIRC_RC_USER_BASE         = 1000;
		
		// Common success codes
		public const int MPIRC_SUCCESS              = 0;
		
		// Common warning codes (info)
		public static int MPIRC_W_NO_DATA           = MPIRC_TYPE_WARNING + 1;
		public static int MPIRC_W_END_OF_DATA       = MPIRC_TYPE_WARNING + 2;
		public static int MPIRC_W_DATA_TRUNCATED    = MPIRC_TYPE_WARNING + 3;
		
		// Common error codes
		public static int MPIRC_E_UNKNOWN           = -1;
		public static int MPIRC_E_EXCEPTION         = -2;
		public static int MPIRC_E_FAILED            = -3;
		public static int MPIRC_E_INVALID_PROPERTY  = -4;
		public static int MPIRC_E_TYPE_MISMATCH     = -5;
		public static int MPIRC_E_PROPERTY_NOTSET   = -6;
		public static int MPIRC_E_INVALID_INDEX     = -7;
		public static int MPIRC_E_NULL_ARGUMENT     = -8;
		public static int MPIRC_E_INVALID_ARGUMENT  = -9;
		public static int MPIRC_E_ALLOC_FAILED      = -10;
		public static int MPIRC_E_NO_PROPERTIES     = -11;
		public static int MPIRC_E_INVALID_TYPE      = -12;
		public static int MPIRC_E_BAD_CONNECTION    = -13;
		public static int MPIRC_E_FILEOPEN_FAILED   = -14;
		public static int MPIRC_E_FILEWRITE_FAILED  = -15;
		public static int MPIRC_E_FILEREAD_FAILED   = -16;
		public static int MPIRC_E_FILEPOS_FAILED    = -17;
		public static int MPIRC_E_INVALID_OBJECT    = -18;
		public static int MPIRC_E_NULL_OBJECT       = -19;
		public static int MPIRC_E_ILLEGAL_CALL      = -20;
		public static int MPIRC_E_EOF               = -21;
		public static int MPIRC_E_ROOT_ELEM         = -22;
		public static int MPIRC_E_NOT_ROOT_ELEM     = -23;
		public static int MPIRC_E_3RD_PARTY_FAILED  = -24;
		public static int MPIRC_E_NON_RESIZABLE     = -25;
		public static int MPIRC_E_RUNMAP_FAILED     = -26;
		public static int MPIRC_E_LOADMAP_FAILED    = -27;
		public static int MPIRC_E_NONEXISTING       = -28;
		public static int MPIRC_E_LOADLIBRARY_FAILED = -29;
		public static int MPIRC_E_INVALIDSEEK       = -30;
		public static int MPIRC_E_DATA_TRUNCATED    = -31;
		public static int MPIRC_E_NO_PARENT         = -32;
		public static int MPIRC_E_NOT_SUPPORTED     = -33;
		public static int MPIRC_E_XERCES_FAILED     = -34;
		public static int MPIRC_E_INVALID_CARDNUM   = -35;
		public static int MPIRC_E_INVALID_CARDDIR   = -36;
		public static int MPIRC_E_PROPXML_MISMATCH  = -37;
		public static int MPIRC_E_INVALID_PROPID    = -38;
		public static int MPIRC_E_INVALID_PROPTYPE  = -39;
		
		// Trace object flags
		public const int LOG_MODE_DEFAULT           = 0x00;
		public const int LOG_MODE_APPEND            = 0x01;
		public const int LOG_LEVEL_DEFAULT          = 0x01;
		public const int LOG_LEVEL_MAX              = 0x7fffffff;

        // MPIP_MAP_CODEPAGE_FALLBACK
        public static int MPI_CODE_PAGE_FALLBACK_SKIP        = 0;
        public static int MPI_CODE_PAGE_FALLBACK_SUBSTITUTE  = 1;

        // MPIP_MAP_TRACE_FORMAT
        public static int MPI_TRACE_FORMAT_TEXT     = 0;
        public static int MPI_TRACE_FORMAT_BINARY   = 1;

        /* MPIP_CARD_DOCUMENT_VERIFICATION */
        public static int MPI_VERIFY_NEVER                  = 0;
        public static int MPI_VERIFY_ALWAYS                 = 1;
        public static int MPI_VERIFY_ONFAILURE		        = 2;
        public static int MPI_VERIFY_ONSUCCESS		        = 3;
        public static int MPI_VERIFY_WELLFORMED             = 4;
        public static int MPI_VERIFY_IGNORE_UNDEFCONSTRUCTS = 5;
	}
}