public class Book implements java.io.Serializable
{
	public String title;
	public String author;
	public float price;
	public boolean instock;
	
	public Book(String title, String author)
	{
		this.title = title;
		this.author = author;
	}

	public Book(String title, String author, float price, boolean instock)
	{
		this(title, author);
		this.price = price;
		this.instock = instock;
	}	
}