package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;

import com.ibm.websphere.dtx.ds.typetree.TTCategory;
import com.ibm.websphere.dtx.ds.typetree.TTSource;

/**
 * This example demonstrates how to create a type tree, add different kind of elements and save to a file.
 * 
 *
 */
public class CreateTypeTreeExample {
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	// by default output files are located in 'DefaultLocation' relative to class file
	private static String DefaultLocation = "output/example.mtt";
	private String _fileLocation = DefaultLocation;
	
	/**
	 * @param fileLocation
	 */
	public CreateTypeTreeExample(String fileLocation) {
		super();
		_fileLocation = fileLocation;
	}
	
	/**
	 * This method runs the example
	 */
	public void run(){

		TTSource typeTreeSource = TTSource.createTypeTree("Root", getFileLocation());

		TTCategory rootType = typeTreeSource.getRootType();
		
		TTCategory cat = rootType.addCategory("Fields");

		cat.addItem("simple");
		cat.addGroup("grp");
		
		typeTreeSource.save();
		
		typeTreeSource.close();
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultLocation;
		CreateTypeTreeExample target = new CreateTypeTreeExample(location);
		target.run();
	}

	/**
	 * @return string value of file location
	 */
	public String getFileLocation() {
		if(_fileLocation != null && _fileLocation.equals(DefaultLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _fileLocation);
				_fileLocation = sourceFile.getAbsolutePath();
			}
		}
		return _fileLocation;
	}

}
