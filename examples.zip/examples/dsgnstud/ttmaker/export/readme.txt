IBM WebSphere Transformation Extender 
Export Type Tree Maker Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of exporting an item with a 
restriction list and uses the exported type tree script to create a 
cross reference table.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    export.mms     - a map to generate the cross reference table

    element.mtt    - a type tree to be exported into an .mts file
                        (type tree script)

    readme.txt     - this readme file 

    ttmaker60.mtt  - contains the document type used to validate an 
                     exported XML document file (type tree script)

    xreftbl.mtt    - the definition of the cross reference table to 
                     be generated
                        
    xref.txt       - the genetated cross reference table


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example shows how to export an item with a restriction list and 
uses the exported type tree script to create a cross reference table.
The ttmaker60.mtt file contains the document type used to validate an 
exported XML document (type tree script) file from the Type Designer.

How to run the example:

1)  Open the element.mtt type tree.
   
2)  Export the type tree (Tree > Export) to an element.mts file in 
    this directory.

3)  Run the exprstrc map in the export.mms source file.


=====================================================================
                             END OF FILE
=====================================================================
