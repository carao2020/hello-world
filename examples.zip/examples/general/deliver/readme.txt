IBM WebSphere Transformation Extender 
Deliver Map Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Deliver Map.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:


    deliver.mms
    deliver.mtt
    deliver.txt
    readme.txt  (this readme file)
    report.txt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example maps data that contains information for forcasting, 
invoicing, and purchase orders. 

In the deliver.mms map file, there are three executable maps.

In the Activity Report map (actvtrpt), the input is a file of records 
(deliver.txt). The type Record is partitioned into different kinds -- 
Forecast, Invoice, and PO. The Forecast and PO types are partitioned
even further.

The output of the Activity Report map (actvtrpt)is a file 
(report.txt) that summarizes the record types that are in the input, 
and performs some calculations.

In the Orders By Department map (ordbydpt), the input, again, is the 
file of records (deliver.txt). 

There are two outputs. One output file (acct.txt) contains just the 
Invoice records from the input. The other output file (order.txt) 
contains the Forecast and PO records.

The Test Data map (testdata) creates one output file (deliver.txt) 
that contains Collection Data used as input by the other two maps.

How to run the example: 

1)  Launch the Map Designer and open the deliver.mms file. 

2)  Build and run the testdata map.  This creates the output file
    deliver.txt that will be used by the other two maps.

3)  Build and run the actvtrpt map. Open report.txt to view the 
    output results of the Activity Report (actvtrpt) map.

4)  Build and run the ordbydpt map. Check the output file (acct.txt)
    to view the Invoice records from the input. Check the other 
    output file (order.txt) to view the Forecast and PO records. 
           

=====================================================================
                             END OF FILE
=====================================================================
