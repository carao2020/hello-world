IBM WebSphere Transformation Extender 
Audit Log Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Audit Log. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

        badaud.log
        goodaud.log
        maperrcd.dat
        readme.txt
        tryaudit.mms
        tryaudit.mtt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example will use these sample files to run the Audit Log. The 
Audit Log example has been broken down into three parts:

1)  Output Card 1 (MapStatus) produces a user-readable error report
    based on the content of the data audit.

2)  Output Card 2 (Report) produces a header/detail file of records
    based on the execution audit information with a single header 
    row for the map execution and a detail record for each input and 
    each output.

3)  Output Card 4 (EMail_Error) sends out an e-mail alert if the map
    execution failed, including the contents of audit log as an
    attachment.

How to run the example: 

1)  Using the Map Designer, open tryaudit.mms.
    There are two input cards:
   
    a)  Audit_Log - This card is used to determine with which audit 
        log (badaud.log or goodaud.log) you want to test.
      
        badaud.log reports error activity
        goodaud.log reports successful activity
      
    b)  Map_Error_Cds - This card points to a data file containing
        an explanation for each Return Code.

Note:   An audit log reports back if you have problems with the
        inbound or outbound data when running a map.

   There are four output cards:
   
    a)  MapStatus - This card is used to determine if the audit log
        contains information about an error.
      
    b)  Report - This card produces a header/detail file of records
        based on the execution audit information with a single header
        row for the map execution and a detail record for each input
        and each output.
      
    c) Error_Msg - This card generates the message that will be
       sent out by e-mail if the audit log contained any errors.
       
    d) EMail_Error - This card is used to send an e-mail if the
       audit log contains errors.

2)  Configure the rule in output card 4 (EMail_Error) so that it 
    uses the correct e-mail adapter commands to send your e-mail 
    error message to the desired mailbox.

3)  Build and Run tryaudit (you will not send an e-mail error 
    message the first time because input card 1 is pointing to a 
    good audit log).
   
    The following outbound data is generated:
    a)  Output Card 1 (MapStatus)   - result.txt
    b)  Output Card 2 (Report)      - report.txt
    c)  Output Card 3 (Error_Msg)   - errormsg.out ONLY if audit.log
        contains errors
    d)  Output Card 4 (EMail_Error) - Sends e-mail ONLY if audit.log
        contains errors

Tip:    If the map fails during execution, review the tryaudit.log.
        Most likely, you forgot to modify the e-mail adapter
        commands as stated in step number 2.

4)  After running tryaudit for the first time, change the first input
    card (Audit_Log) to point to badaud.log. You should now generate
    an e-mail error message.

This tryaudit example demonstrates some of the choices you have
when creating or modifying maps using the Map Designer.

1)  Backup File
   
    Purpose: To provide a means whereby unique backup file names can 
    be generated or whereby backup file names can participate in
    wildcard coordination with other sources and targets of the map.

    This feature is presented in the tryaudit example by allowing 
    the data for input card 1 (Audit_Log) to be backed up only if 
    there is an error with the map. This will occur when using the
    badaudit.log log file for data.

2)  Expanded Options for When to Create Audit Logs
   
    Purpose: To provide a means by which the audit log is written 
    only under specific conditions to facilitate the process of 
    handling audit logs only when exceptional circumstances occur.

    This feature is presented in the tryaudit example by allowing 
    the audit log for the tryaudit example to be created only if 
    there is an error with the map. This will occur when using the
    badaudit.log log file for data.

3)  Ignore Restrictions Map Setting Extension
   
    Purpose: To provide a validation execution command setting that 
    will allow restrictions to be fully ignored, in all situations 
    other than when ignoring is required for object identification. 
    For example, when an item is partitioned by a restriction list, 
    and so forth.

    This feature is presented in the tryaudit example in the 
    Map Settings under Validation > RestrictionError. In this case, 
    the option "Ignore (no warnings)" has been selected. Although 
    not fully utilized in this example, it does present to you an 
    additional option when generating your maps.

4)  Full Audit Log Support on z/OS
   
    Purpose: To provide the full content of the map audit log on the 
    z/OS platform, including all sections of the audit, which are the 
    Data and Execution sections of BurstAudit and the Data and Map 
    settings audit.

    This feature is presented in the tryaudit example in the 
    Map Settings under MapAudit > BurstAudit > SummaryAudit > 
    SettingsAudit. In this case, the audit settings have been set 
    to only present themselves within the tryaudit.log, OnError.  
    Prior to this, you could only specify either On or Off for each 
    of these settings, and the BurstAudit option did not yet exist.


=====================================================================
                             END OF FILE
=====================================================================
