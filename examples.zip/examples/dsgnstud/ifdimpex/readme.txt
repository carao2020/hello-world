IBM WebSphere Transformation Extender 
Integration Flow Designer Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Integration Flow Designer
(IFD) Import/Export utility.  

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    cardsettings.xsd        - XSD file
    integrationflow.xsd     - XSD file
    mapsettings.xsd         - XSD file 

    readme.txt              - this readme file

    Sample.xml              - sample xml document     

    sys_map.mms             - map source file     

    systemimportexport.mtt  - type tree           


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example demonstrates one usage of the IFD Import/Export utility.
This utility allows you to represent MSD source in an XML format. 

For ease of description in this example, this representation is 
called IFD Script. In its simplest form, you can take an MSD file
created in the IFD and export one or more systems or one or more 
servers (by re-representing it in XML syntax) to a file. That same 
file can be imported back into the IFD and subsequently can be used 
as a system.

This functionality has many usages. One application is to make global 
changes to an IFD system. In many situations, this will be quicker, 
easier, and less error-prone than making many changes manually. 

In this example, change all map and Launcher settings in a
particular system or change the server settings. Without the IFD
Import/Export utility, you would have to open each MSD file and 
manually change each setting. This is a common task that is performed
after IFD testing and before an MSD file is placed in a production 
environment. 


=====================================================================
                             END OF FILE
=====================================================================
