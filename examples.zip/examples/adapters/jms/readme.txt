IBM WebSphere Transformation Extender 
Java Message Service(JMS) Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Java Message Service(JMS)
Adapter sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

This directory contains the following files:

    testjms.mms    - Source map definition file - includes ten maps
    text_out.mtt   - Type tree used to put example Text messages
    text_in.mtt    - Type tree used to get example Text messages
    bytes.mtt      - Type tree used to put/get example Bytes messages
    stream.mtt     - Type tree used to put/get example Stream 
                     messages
    map.mtt        - Type tree used to put/get example Map messages
    object_out.mtt - Type tree used to put example Object messages
    object_in.mtt  - Type tree used to get example Object messages
    Book.class     - Source code of the class used in Object messages
    Book.java      - Binary file of the class used in Object messages
    readme.txt     - Readme file for JMS adapter examples
        

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example demonstrates maps to show how to send and receive 
messages of all JMS defined message types: Text, Bytes, Stream, Map 
and Object. The examples also includes type trees for all message 
types. These type trees can be used as a template for generating new 
user specific type trees. Type trees for the Object messages can 
always be created using the JMS Importer.

How to run the example:

Open testjms.mms file in the Map Designer

There are ten maps in this file. Every map sends or receives a
message of a specific type.

All type trees share a few common characteristics:

a) "Message" group represents the whole JMS message. "Message" group
has <Message> initiator and </Message> terminator

b) "Message" group has two subgroups, "Header" and "Body".
The "Header" subgroup is optional and the "Body" subgroup is not.

c) "Header" group has two optional subgroups, "HeaderFields"
and "Properties". "Header" group is defined as unordered.

d) "HeaderFields" group includes all JMS header fields that are 
defined by the JMS specification. "HeaderFields" group has 
<HeaderFields> initiator and </HeaderFields> terminator. There are 10 
items in this group. The name of the items represent the actual names 
of the JMS header fields. The name of a field is used for the item's 
initiator and terminator, in form <FieldName> and </FieldName> where 
FieldName is one of the 10 defined header field names.

Note that for the following fields:

Destination, MessageID, CorrelationID, ReplyTo and Type

the initiator is in the form <FieldName><![CDATA[ 

and the terminator is in the form ]]></FieldName>

This was done to enable passing those text values for this fields 
that would otherwise cause XML parser in the adapter to fail.

For example, because of the CDATA section, the following value can be 
passed as MessageID:

"ID<3445>"

Note that the substring "]]>" must not appear in these header field's 
text values because it serves as the CDATA section closing marker.

e) "Properties" group is used to define user, provider and JMS
specific message properties. The initiator for this group is
<Properties> and the terminator is </Properties>. Properties are
further explained in the puttmsg and gettmsg example
maps. "Properties" group is defined as an unordered group.

The type trees reflect the XML structure of the data that is being 
passed to the adapter. To see what the data that is being passed to 
the JMS adapter looks like, replace the JMS output with the File 
output and map data to an XML file.

Next, open this XML file and investigate its structure. The
structure of this file should match the structure of the type tree.

The following flow chart explains how data that is passed to the
JMS adapter is interpreted by the JMS adapter:

Note that if no data at all is passed to the adapter, and OnSuccess
card setting is set to "Create", a generic JMS message with no
payload is created. If OnSuccess is set to "CreateOnContent", no
message is produced.


         Data passed to the JMS adapter
                     ||
                     ||
      Was -text adapter command specified?
                     /\
                 yes/  \no
                   /    \
                  /      \
 Create a TextMessage    Try to parse the
 and dump all the        data as it is XML data.
 received data to the    Was the XML parsing
 message body            successful?
                             /\
                         yes/  \no
                           /    \
                          /      \
   Locate Message,             Does the passed data
   Header, HeaderFields,       start with <Message> and
   Properties and Body         ends with </Message>?
   nodes in the data.                    /\
   Use information in                yes/  \no
   these nodes to create               /    \
   the message of a proper            /      \
   type and set message      The adapter       Create a BytesMessage
   header fields,            issues an         and dump all the
   properties and data       error because     received data to the
                             the data is       message body
                             supposed to
                             represent a JMS
                             message as
                             defined by the
                             type tree
                             but is invalid


IMPORTANT NOTE FOR THE EXAMPLES:
--------------------------------

All the examples assume that the File based JNDI repository is used,
and that the .bindings JNDI file is placed in the C:\STORE directory.
This is specified with the following two adapter commands:

-ictxfurl file://C:/STORE
-ictxf com.sun.jndi.fscontext.RefFSContextFactory

It further assumes that the .bindings file contains definitions
for the destination cn=myQ1 (JNDI lookup name for the destination
to send and retrieve messages) and for the connection factory
cn=myQueueCF1.

This is specified with the following two adapter commands which 
assume the destination is a queue:

-qn "cn=myQ1"
-cfn "cn=myQueueCF1"

If LDAP based repository is used instead of the File based 
repository, the -ictxfurl and -ictxf adapter commands in these 
examples need to be adequately modified.

If a destination different than queue "cn=myQ1" is used,
the -qn adapter command needs to be adequately modified.

In addition, if any connection factory different than "cn=myQueueCF1"
is used, the -cfn adapter command needs to adequately modified.

-t adapter command is used in all examples to create the adapter
trace file. This file is created in the map directory
and it has the name MapName.mal where MapName is the actual
map name that was executed.

Some of the included example maps use -hdr and -prp
adapter commands in the input cards. They define that the
header (properties) fields need to be returned by the adapter for
the source messages.

On the output side, this is not required because the adapter
uses the passed data that complies to the type tree to
extract the header and properties field values if they were
specified.


Example1 - puttmsg
-------------------------

This example sends a Text message on the output queue.
The correlation id of the message is specified to "Text message ID"
The message has two user defined properties:

 - MessageSubmitter
 - Price

Message properties are defined as items in the "Properties" group.

Every property has the initiator <PropertyName type="PropertyType">
and terminator </PropertyName>, where PropertyName is the actual
property name, and PropertyType is one of the following:

 - boolean
 - byte
 - short
 - int
 - long
 - float
 - double
 - char

For the java.lang.String property types, the initiator is in the 
form: 

<PropertyName type="java.lang.String"><![CDATA[ 

and the terminator is in the form:

]]></PropertyName>

This was done to enable passing those text values for this properties 
that would otherwise cause XML parser in the adapter to fail. (such 
as text values that contain '<' and '>' characters). Note that the 
substring "]]>" must not appear in the property's text value because 
it serves as the CDATA section closing marker.

"MessageSubmitter" property is a java.lang.String property and it has
value "John Smith"

"ItemPrice" property is a float property and it has value 2.35

The message data has the text string "Oranges"

Run the map to store the text message on the output queue.


Example2 - gettmsg
-------------------------

This example map reads the Text message that was previously stored
on the queue in Example1.

Note that the properties group has all the properties that are
defined on the message, and not only the properties that were
specified by the user when the message was sent.

In this example, properties specific to the IBM WebSphere MQ JMS 
messages are added. Because the -prp adapter command is specified on 
the input card, the adapter will pass back ALL the properties that 
are defined on the input message. In order for the data to be 
validated on input, all the properties must be defined in the type 
tree.

An easy way to see what properties are defined on a particular 
message is to use a simple item on the input, specify -prp adapter 
command, and map the retrieved data to an XML file for further 
analysis.

The output XML file will contain all the properties that are defined
on the message and the property types. The type tree needs to be
modified to match this data structure.

Run the map. The result file TextMessage.txt will contain the
following sentence:

The item is: Oranges, and the price is: 2.35


Example3 - putbmsg
--------------------------

This example stores a Bytes message on the output queue. The message
body in this example will consist of three bytes 0x0A, 0x0B and 0x0C.
Before bytes are sent to the adapter, they need to be base64 encoded.
BASE64 adapter is used to encode the binary data.

The binary data is encoded so that the data that is passed to the
adapter can be interpreted as XML. Otherwise, the data with the
non-printable bytes could not be parsed as XML.

The GET call:

=GET("BASESF", "-ENCODE", SYMBOL(10)+SYMBOL(11)+SYMBOL(12))

is passing three bytes to the base64 adapter (alias BASESF) to
be encoded (-ENCODE). The base64 encoded data is assigned to
Base64Data item and this data is passed to the JMS adapter.

The JMS adapter internally decodes this data and the decoded data
(0x0A 0x0B 0x0C) is used for the actual message body content.
The correlation id of the generated message is "Bytes message ID"

Run the map. A Bytes message with a three-byte body will be stored on
the output queue.


Example4 - getbmsg
--------------------------

This example map reads the Bytes message that was previously stored
on the queue. The adapter returns the message that contains base64
encoded data. To display the data in its natural binary form, it is
first necessary to decode it. The base64 adapter is used for this
again but this time with the -DECODE adapter command.

The GET call that does this:

=GET("BASESF", "-DECODE", Base64Data:Body Body:GetBytesMessage)

Run the map, and look at the output. The output file BytesMessage.bin
has three bytes 0x0A 0x0B 0x0C. Those are the three bytes that were
originally sent to the queue.


Example5 - putsmsg
---------------------------

In this example a Stream message is created and stored on the output
queue. Stream messages have a message body that consists of
concatenated fields. A stream message can have any number of the
fields.

These fields are unnamed, but they have to be of one of the
following Java types:

 - boolean
 - byte
 - short
 - int
 - long
 - float
 - double
 - char
 - java.lang.String
 - byte[]


This is same as for the message Properties with the addition of
the byte[] Java type.

In this example there are three fields in the stream message.

The first one is of int type (item name intField), the second one is
of java.lang.String type (item name StringField) and the third one
is of byte[] type (group name byteArrayField). All the fields are
represented by the components that have <Field type="FieldType">
initiator and </Field> terminator, where the FieldType is the
type of the actual field.

The only exception to this rule are the fields of java.lang.String 
type. Their initiators are in the form:

<Field type="java.lang.String"><![CDATA[

and the terminators are in the form:

]]></Field>

This was done to enable passing those text values for this fields 
that would otherwise cause XML parser in the adapter to fail (such as 
text values that contain '<' and '>' characters). Note that the 
substring "]]>" must not appear in the field's text value because it 
serves as the CDATA section closing marker.

All the fields are always represented as items, except the fields of
byte[] type. They are represented as groups of items, where the items
have <element> initiator and </element> terminator.

The fields in the stream message are always stored and retrieved in
the same, fixed order.

Therefore, the Group Subclass of the "Body" group is defined as 
Sequence and not as Unordered.

The correlation id of the output message is set to
"Stream message ID"

Run the map. A stream message with three fields will be stored on
the output queue.


Example6 - getsmsg
---------------------------

In this example, the stream message that was previously stored on
the queue is retrieved. The body of the message is placed in the
file StreamMessage.xml.

Run the map and open the output file StreamMessage.xml to see its XML
structure and the values of the stream fields.


Example7 - putmmsg
------------------------

Map messages are very similar to the Stream messages. The difference
is that the fields in the Map message body are named.

The fields in the Map messages can be stored and read by the adapter
in any order, because every field has a unique name.

All the fields are represented by the components that have the 
<FieldName type="FieldType"> initiator and the </FieldName> 
terminator, where FieldName is the name of the actual field and 
FieldType is its type. 

The only exception to this rule are the fields of java.lang.String 
type. Their initiators are in the form:

<FieldName type="java.lang.String"><![CDATA[

and the terminators are in the form:

]]></FieldName>

This was done to enable passing those text values for this fields 
that would otherwise cause XML parser in the adapter to fail (such as 
text values that contain '<' and '>' characters). Note that the 
substring "]]>" must not appear in the field's text value because it 
serves as the CDATA section closing marker.

The allowed types are same as for the Stream message fields:

 - boolean
 - byte
 - short
 - int
 - long
 - float
 - double
 - char
 - java.lang.String
 - byte[]

In this type tree, the "Body" group has Unordered Group SubClass,
because the Map message fields can be read in any order.

Run the map to store a Map message on the queue.


Example8 - getmmsg
------------------------

In this example, the Map message that was previously stored on the
queue is retrieved.

The message's correlation id and the values of the message's intField
field are stored in the output file MapMessage.txt


Example9 - putomsg
---------------------------

Object messages are specific in a way that the type trees for them
can and normally are generated using the JMS Importer. The content
of the Object message body is basically a Java object.

This example uses Book class for which the source code and compiled
class file are provided (Book.java and Book.class)
This class file has to be copied to a directory that is included in
the CLASSPATH.

The Book class is a public class that has two constructors and four
public fields:  title, author, price and instock.

Note also that the Book class implements java.io.Serializable
interface which is the prerequisite for the Object message types.

The reason for this is that the JMS subsystem has to serialize the
Java object before it is stored in a JMS message.

In this example, an object of Book type is created and stored to the
queue in an Object JMS message.

The Body group has three main components:

 - "this"
item is used to specify a reference id for the object. Users
choose a string by which the generated object will be identified in
the internal adapter's pool of objects.

 - "Constructor"
group describes the constructor that is to be used to
instantiate the object of the Book type. The chosen constructor has
two String parameters that represent the book's title and author.

 - "Fields"
group represents four public fields of the class. In the
map, the first two fields are set to NONE. This is done because the
constructor has already set these two fields internally (see the
Book.java file). Providing values for these two fields would override
the values set by the constructor ("Exotic Birds" and "John Smith")
The other two fields (price and instock) are explicitly set to the
values 12.25 and "true"

Another item that this example displays is the use of the Type
header field. The application can declare the message to be of
a certain type that is meaningful to the receiving application.

Because the object that is stored in the message body is of the
Book class type, the message type is simply called "Book" in this
example, but it can also be called differently.

Run the map. An object of Book class will be instantiated and stored
on the output queue within an Object message. The message will have
the user specified "Book" type.


Example10 - getomsg
----------------------------

This example reads the Object message from the previous example
from the queue. Note the difference between the type tree used in
this example and the previous one: the "Constructor" group is
missing in the type tree in this example.

This is because in this example an object is retrieved from the
queue which means that this object already exists (in the serialized
form) when the map is ran, so there is no instantiating of the new
objects.

Once the map is ran, the message is retrieved from the queue,
the Java object extracted from the message, stored in the internal
pool of objects, assigned a unique reference id and the type tree on
the input card is populated with the Object message data.

The "this" item is assigned a reference value by the adapter in a 
form Ref.x where x is the unique positive integer that identifies the 
retrieved object.

Users need to avoid using reference id values in a Ref.x form where
x is a positive integer value, because reference id values of this
format are used internally by the adapter.

This reference can be used on the output cards. The output card can
be another JMS card that stores an object message. If this same
reference is used on the output (as a "this" value), there is
no need for the "Constructor" group on the output card. The JMS
adapter retrieves this object from the pool of objects based on
the reference id instead of instantiating it and it uses it as a body
for the output message.

The references are particularly useful when Java Class adapter
is used on output. For example, a message can be retrieved
in the input card, and the generated reference could be
used on the output to invoke Java Class adapter and call a public
method on the object that was retrieved on the input.

Running the map in this example will retrieve the Object message from
the queue and store the retrieved book's title and price as well as
the retrieved message's type in the output file ObjectMessage.txt.



=====================================================================
                             END OF FILE
=====================================================================
