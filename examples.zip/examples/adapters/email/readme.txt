IBM WebSphere Transformation Extender 
E-mail Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of E-mail Adapter sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

File included in this example:

       rawinet.mtt      
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example shows how the sample type tree file is used to create 
a MIME header. The tree can be used to create the MIME header when 
using the Internet protocol (-PROTO INET) and the -RAW command. The 
-RAW command indicates to the E-mail adapter that the data being 
passed to the adapter contains MIME headers and that the adapter 
should not attempt to add additional headers.

This type tree has a single text item called 'Body' that represents
the body of the e-mail message. This can be replaced with any
structured types, if desired.


=====================================================================
                             END OF FILE
=====================================================================
