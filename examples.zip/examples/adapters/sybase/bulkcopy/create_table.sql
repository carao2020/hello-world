CREATE TABLE bulkcopy
(
state CHAR(2) NULL,
name VARCHAR(80) NULL,
type VARCHAR(9) NULL,
county VARCHAR(60) NULL,
st_code INTEGER NULL,
county_code INTEGER NULL,
platitude_dms CHAR(7) NULL,
plongitude_dms CHAR(8) NULL,
platitude_dec VARCHAR(10) NULL,
plongitude_dec VARCHAR(10) NULL,
slatitude_dms CHAR(7) NULL,
slongitude_dms CHAR(8) NULL,
slatitude_dec VARCHAR(10) NULL,
slongitude_dec VARCHAR(10) NULL,
elevation VARCHAR(10) NULL,
population VARCHAR(10) NULL,
cell_name VARCHAR(30) NULL
)
go
