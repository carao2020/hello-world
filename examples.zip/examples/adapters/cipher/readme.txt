Transformation Extender (TX) Cipher Adapter Readme

Licensed Materials - Property of HCL
(c) Copyright HCL Technologies Ltd. 2017.  All Rights Reserved.

This example shows how to use the Transformation Extender (TX) Cipher adapter. 
The Cipher adapter encrypts and decrypts data by using an Advanced Encryption 
Standard (AES) 256-bit cipher. The AES standard was established by the U.S. 
National Institute of Standards and Technology (NIST).

Because AES uses a symmetric cipher, one cryptographic key is used to both 
encipher (encrypt) and decipher data. The cryptographic key is stored in a 
master key file (MKF) in an AES-based encrypted format. As long as the MKF 
is not compromised or lost, the enciphered data is cryptographically secure. 
It is critically important to safeguard the encrypted master key.

The -MKF option of the CIPHER command locates an existing master key or stores 
a new master key. If you omit the -MKF option, the Cipher adapter automatically 
creates a new cryptographic key. 

When the MKF contains multiple master keys, 
TX uses the last key in the MKF by default.  Use the -ID option to select a 
different key.

Encrypted data is preceded by a unique header that identifies the specific 
master key used for encryption.  To decrypt the data, the specified MKF must 
contain the key ID that is  specified in the header of the encrypted data. 
The encryption mode can be ASCII or binary. After ASCII encryption, the 
encrypted datais HEX-encoded. After binary encryption, the encrypted data is 
binary-encoded. ASCII is the default encryption mode. Decryption automatically 
uses the mode that is appropriate for the encrypted data. 

   
==============================================================================
CONTENTS
==============================================================================

    1. Example Files
    2. GSKit Configuration
    3. Map Execution
    4. Usage Notes
  
==============================================================================
1. Example Files
==============================================================================

1) Readme
    readme.txt  		- this readme file

2) Map source and data
    cipher.mms 		        - map source file
    Test.mtt    		- type tree
    bulk_key.mkf		- sample cryptographic key
    test.txt    		- sample data


==============================================================================
2. GSKit Configuration
==============================================================================

In order for TX to use the encryption capabilities of the Cipher adapter,
IBM GSKit is locally installed and automatically used by TX executables.

To use the Cipher adapter in an API or RMI environment, you must run the
"dtxcommon.bat" (on Windows) or "setup" script (on UNIX) before map execution 
to ensure that the library and executable path of your platform points to the 
local GSKit drivers.  In an Integrated Server environment, you must manually 
adjust the paths to point to the GSKit drivers. 

A "locally" installed GSKit enables TX to run with a specific version of GSKit.
Other IBM products might use their own "local" version of GSKit. When invoking
TX with other IBM products that are configured to use GSKit, you can configure 

the environment to use the latest or most appropriate version. 

To prevent TX from using its locally installed version of GSKit, rename the 

"GSKit" sub-directory under the TX installation directory 
(<tx_install_dir>\GSKit)
to any other name.  At runtime, TX automatically 
detects the missing GSKit 
directory and searches the platform-specific 
environment path for the GSKit modules.

When you have a "global" version of GSKit installed on the same system due 
to the requirements of another IBM product, renaming the <tx_install_dir>\GSKit 
directory likewise ensures that the TX "local" GSKit is bypassed.  The "global" 
version is managed by the GSKit installation program, which makes the security 
modules available on a system-wide basis.  

To determine the version of the local GSKit that TX installed: 
1)  Start a command line session
2)  Run the TX "dtxcommon.bat" or "setup" script
3)  Run "gsk8ver_64"
         
  
==============================================================================
3. Map Execution
==============================================================================

    Compile the maps by doing one of the following: 
    - From the command line, run the command "mcompile cipher.mms -a"
    - Open the cipher.mms file in Design Studio and select "Map->Build All"

    
    Map descriptions:

    encipher.mmc:
   
    This map uses a GET rule to encipher data. The encrypted content
    is sent to an output card and stored in the Encipher_Output.txt file. 
    
    By default, the map uses ASCII encryption mode. 
   
    encipher_BIN.mmc:
   
    This map uses a GET rule to encipher data. The encrypted content
    is sent to an output card and stored in the Encipher_Output.txt file. 
    
    The map uses binary mode encryption (-BIN option).

    decipher.mmc:
   
    This map uses a GET rule to decipher the results of either the encipher.mmc 
    map or the encipher_BIN.mmc map by automatically detecting the encryption 
    format of the enciphered data. The decrypted content is sent to an output 
    card and stored in the Decipher_Output.txt file.
   
    encipher_InFile.mmc:
   
    This map uses a Cipher input card to encrypt a file. The results are
    sent to an output card and stored in the Encipher_InFile_Output.txt file. 
   
    decipher_InFile.mmc:
   
    This map uses a Cipher input card to decrypt the results of the 
    encipher_InFile.mmc map. The decrypted content is stored in the 
    Decipher_InFile_Output.txt file.
   
    encipher_OutFile.mmc:
   
    This map uses a Cipher output card to encrypt data. The content is
    stored by the Cipher adapter in the Encipher_OutFile_Output.txt file.
   
    decipher_OutFile.mmc:
   
    This map uses a Cipher output card to decrypt the results of the 
    encipher_OutFile.mmc map. The decrypted content is stored in the 
    Decipher_OutFile_Output.txt file.
	   

==============================================================================
4. Usage Notes
==============================================================================



Options:

    -MKF     <filename>   Optional - defaults to itx.mkf in the TX installation directory

    -ID      <key id>     Optional - defaults to the last key in the MKF

    -T       <filename>   Optional - specifies the trace file name

    -BIN                  Optional - specifies binary encryption; defaults to ASCII

    -ACTION  [encipher | decipher]  
                          
                          Specifies data encryption or decryption 
                          
                          Optional on GET and PUT rules
                          
                          Required on input and output cards

    -FILE    <filename>   Used only for input or output cards
                          On input card: data is read from this file
                          On output card: data is written to this file

1)  If you omit the "-MKF" option, TX attempts to use the itx.mkf master key file.
    
    By default, itx.mkf is in the TX installation directory on Windows, and in the 
    "config" sub-directory on Unix platforms.
   
2)  If TX does not find the MKF when enciphering, it automatically creates a new key in 
    the specified MKF file or in itx.mkf, if no MKF is specified.
 
3)  If the MKF has multiple key entries, use the "-ID" option to identify which
    key to use.  
    
    For example, a GET rule can explicitly identify key 13104 in the default bulk 
    
    encryption key file as follows:

    = GET("CIPHER","-MKF bulk_key.mkf -ID 13104", InputFile)
    
4)  The -ACTION option specifies whether to encrypt or decrypt data. For example: 

    
    = GET("CIPHER","-MKF bulk_key.mkf -ID 13104 -ACTION encipher", InputFile))

    -ACTION is optional on GET and PUT rules. If you omit, TX encrypts or decrypts 
    the data based on whether the specified file has an encryption header.    

==============================================================================
                             END OF FILE
==============================================================================
