IBM WebSphere Transformation Extender 
PORTDATA Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of PORTDATA.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    convert.mms        map source file
    
    convert.mtt        type tree

    readme.txt  (this readme file)

    ascii.txt 
    ebcdic.txt 
    convert.txt
    text.txt

    atoetabl
    etoatabl



=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example demonstrates how to define character set properties to 
an item and it will automatically convert from one character set to
another. It converts text data from ASCII to EBCDIC, and from 
ASCII to EBCDIC, using the examples\general\portdata directory. The 
a2ebcdic map uses the conversion table, atoetabl, which is 
the conversion table used in the port map used to convert a compiled 
map to EBCDIC for the MVS and AS/400 port commands.

The ebcdic2a map uses the conversion table, etoatabl.

How to run the example:

If you want to run any of the examples in the examples directory on a
MVS or AS/400 platform, try the following steps:

1)  Compile the example map to MVS or AS/400.

2)  Port each input data file. For each input data file, use the
    a2ebcdic map, replacing the file name of the first input
    card with the file name of the example input data file. (Remember
    to change the output file name of the a2ebcdic map, so 
    that the PC input data files will not be overwritten.)

3)  Binary transfer the ported map and ported data to the EBCDIC
    platform, and run the PC example on the EBCDIC platform.


There is also an example that converts EBCDIC text data to ASCII. If
you want to run EBCDIC data on the PC, you can use either procedure 1
or 2, outlined below:

1)  Compile the ebcdic2a map. On an EBCDIC platform, run the
    ebcdic2a map, using your EBCDIC data files as input. Then,
    binary tranfer the ported data files to the PC and run your PC
    map version, using your ported data files.

- or, try this -

2)  Binary tranfer your EBCDIC data files to the PC. Run the PC
    version of the ebcdic2a map, once for each binary
    tranferred data file. After the data files have been converted to
    be used on the PC, run the PC version of your MVS or AS/400 map.


=====================================================================
                             END OF FILE
=====================================================================
