IBM WebSphere Transformation Extender 
Programming COM Interface ASP Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of IBM WebSphere Transformation 
Extender Programming COM Interface ASP example sample files. It 
describes how to run a map using COM API from an Active Server Page 
(ASP). 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    quote.asp           - stock quotation input asp file

    quoteOut.asp        - stock quotation output asp file

    quote.mtt           - type tree file for the stock quotation 
                          example

    quotesample.mms     - map source file for the stock quotation 
                          example

    nasd0309.txt        - stock quotation input files

    nasdaq.sym

    nyse.sym

    nyse0309.txt

    symbol.txt

    tickers.txt

    readme.txt          - this readme file


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

Configuring the IIS Environment
-------------------------------

The following steps are necessary to configure your environment to
run the example using IIS (Internet Information Server). This 
includes running the example using an ASP file on IIS server.

    1. Install Internet Information Server (IIS) 5.0.
    2. From the start menu, select Start > Settings > Control Panel >
       Administrative Tools > Personal Web Manager. 
       The Personal Web Manager window opens at the Main view.
    3. In the left pane, click Advanced.
       The Advanced Options view opens.
    4. Click Add.
       The Add Directory window opens.
    5. Enter the following information:
       Directory: <TX_INSTALL_DIR>\examples\dk\dtxpi\com\asp
       Alias:     dtxcom
       Select the following choices:
       Access permissions:      Read
       Application permissions: Scripts
    6. Click OK.
    7. In the left pane, click Main.
       The Main view opens.
    8. Click Start to run the IIS server.
    9. Close the Personal Web Manager.


Running the Example Using IIS
-----------------------------

The following steps are necessary to run the Stock Quotation example 
using IIS.

    1. Add the directory in which the SDK is installed to the system
       environment PATH variable.
    2. Launch Windows Explorer.
    3. Navigate to the install_dir\examples\dk\dtxpi\com\asp 
       directory.
    4. Right-click on the asp directory and select properties from 
       the context menu. 
       The asp Properties window opens. 
    5. Ensure that the required permissions are granted so that you
       can access the asp directory, select the option to allow 
       inheritable permissions from parent to propagate to this 
       object, and then click OK.
    6. Edit the quote.asp and outtemplate.htm files by specifying the 
       proper host path http://localhost/ibm/quoteOut.asp
    7. Open the QuoteSample.mms file in Map Designer and build the 
       QuoteSample map.
    8. Edit the quoteOut.asp file by specifying the full path of the 
       map in MapFileName variable.
    9. Restart the machine.
   10. Launch InternetExplorer and enter the following
       URL http://localhost/dtxcom/qout.asp in the Address field. 
   11. Enter a company symbol in the symbol field and click 
       Get Quote. For the example, enter IBM.


Expected Output Using IIS
-------------------------

If you enter IBM in the company symbol field for this example, when 
you run the ASP page using IIS, you will see the IBM Quotes view in
the web page with the stock quotation information for International 
Business Machines. It will list the following fields and values:

                                IBM Quotes
Symbol       Name                                   High       Low
IBM          International Business Machines       81.3750    80.3750


=====================================================================
                             END OF FILE
=====================================================================
