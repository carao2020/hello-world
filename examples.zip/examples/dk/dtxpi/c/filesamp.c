/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

/* 
 * Sample Adapter
 * --------------------------------------------------------------------------
 * This file contains code for a simple file adapter. Its purpose is to show
 * the structures and code required to implement an adapter, and how properties
 * are set and obtained.
 *
 * The concept of a connection does not apply very well for files.  In most
 * adapters there is a very obvious concept (e.g. a database connection, or the
 * handle to a message queue).  In this file example case, a file handle is being
 * treated as a connection.
 *
 * The adapter can be built using Microsoft Developer Studio and the provided
 * makefile.  To build issue the following command from a Command Prompt:
 *
 *  nmake /f filesamp.mak
 *
 * Once built, copy the filesamp.dll to the IBM WebSphere Transformation Extender directory.
 * To register the adapter, copy the following line to the adapters.xml file,
 * under the UserAdapters section:
 *
 *   <UserAdapter name="Sample File" alias="SFILE" id="201" library="filesamp" vendor="IBM"/>
 *
 * To use the adapter, specify the FULL PATH of the file to retrieve in the adapter 
 * command line.
 *
 * When the adapter is used in Launcher scenarios the filename can contain wildcards.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <windowsx.h>
#include <io.h>

#include <dtxpi.h>

#define TRUE  1
#define FALSE 0
#define CHKERR(rc) if (rc != MPIRC_SUCCESS) goto EXCEPTION;

MPIRC SampInitializeLibrary(void);
MPIRC SampDestroyLibrary(void);
MPIRC SampCreateAdapterInstance(HMPIADAPT *phAdapter, HMPICARD hCard);
MPIRC SampDestroyAdapterInstance(HMPIADAPT hAdapter);
MPIRC SampCreateConnectionInstance(HMPICONNECT *phConnection);
MPIRC SampDestroyConnectionInstance(HMPICONNECT hConnection);
MPIRC	SampCompareWatches(HMPIADAPT hAdapter1,
                         HMPIADAPT hAdapter2,
                         MPICOMP *peComp);
MPIRC	SampCompareResources(HMPIADAPT hAdapter1,
                           HMPIADAPT hAdapter2,
                           MPICOMP *peComp);
MPIRC	SampGet(HMPIADAPT hAdapter,
              HMPICONNECT hConnection);
MPIRC	SampPut(HMPIADAPT hAdapter,
              HMPICONNECT hConnection);
MPIRC	SampBeginTransaction(HMPIADAPT hAdapter,
                           HMPICONNECT hConnection);
MPIRC	SampEndTransaction(HMPIADAPT hAdapter,
                         HMPICONNECT hConnection,
                         MPITRANS eAction);
MPIRC	SampListen(HMPIADAPT hAdapter,
                 HMPICONNECT hConnection);
MPIRC	SampValidateProperties(HMPIADAPT hAdapter);
MPIRC	SampValidateConnection(HMPIADAPT hAdapter,
                             HMPICONNECT hConnection);
MPIRC	SampCompareConnection(HMPIADAPT hAdapter,
                            HMPICONNECT hConnection,
                            MPICOMP *peComp);
MPIRC	SampOnNotify(HMPIADAPT hAdapter,
                 int iID,
                 int iParam,
                 HMPICONNECT hConnection);
MPIRC	SampConnect(HMPICONNECT hConnection, 
                  HMPIADAPT hAdapter);
MPIRC	SampDisconnect(HMPICONNECT hConnection);
void SplitDirectoryAndFile(char *lpszFullPath,
                           char *lpszDirectory,
                           char *lpszFile);
MPIRC ReadData (HMPISTREAM hStream,
                FILE       *fp);
void SetErrorCode(HMPIOBJ hObject, int iRC);

/*
** This structure defines the number and type of adapter properties.
** It is referenced in CreateAdapterInstance.
*/
static const int SampAdapterProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* AP_DIRECTORY */
   MPI_PROP_TYPE_TEXT,   /* AP_FILE */
   MPI_PROP_TYPE_TEXT    /* AP_MODE */
};
#define NUM_ADAPTER_PROPERTIES  sizeof(SampAdapterProperties)/sizeof(int)

/* Adapter object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
	AP_DIRECTORY = MPI_PROPBASE_USER,
   AP_FILE,
   AP_MODE
};

/*
** This structure defines the number and type of connection properties
** It is referenced in CreateConnectionInstance.
*/
static const int SampConnectProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* CP_DIRECTORY */
   MPI_PROP_TYPE_TEXT,   /* CP_FILE */
   MPI_PROP_TYPE_PTR,    /* CP_FILE_HANDLE */
   MPI_PROP_TYPE_TEXT,   /* CP_MODE */
   MPI_PROP_TYPE_INT     /* CP_FIND_HANDLE */
};
#define NUM_CONNECT_PROPERTIES  sizeof(SampConnectProperties)/sizeof(int)

/* Connection object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
	CP_DIRECTORY = MPI_PROPBASE_USER,
   CP_FILE,
   CP_FILE_HANDLE,
   CP_MODE,
   CP_FIND_HANDLE
};

/* Define adapter specific error messages */
#define ERR_E_CANT_CONNECT MAKEUSERERROR(1)

/* The size of each page of data written to the stream */
#define PAGE_SIZE  8192

/******  VTABLE for File Sample adapter  ******/

/* filesamp is the name of the library */
MPI_LIBRARY_VTABLE filesamp_config = 
{
   sizeof(MPI_LIBRARY_VTABLE),
   SampInitializeLibrary,          /* InitializeLibrary */
   SampDestroyLibrary,             /* Destroy Library */
   SampCreateAdapterInstance,      /* CreateAdapterInstance */
   SampDestroyAdapterInstance,     /* DestroyAdapterInstance */
   SampCreateConnectionInstance,   /* CreateConnectionInstance */
   SampDestroyConnectionInstance,  /* DestroyConnectionInstance */
   NULL,
   NULL,                     /* Command line mask */
   MPI_TRANSACTIONS_SINGLE,  /* Transactional mode */
   MPI_UNITOFWORK_LOGICAL,   /* Unit of work */
   TRUE,                     /* Listener interface supported */
   FALSE,                    /* Listener blocks */
   FALSE,                    /* Is the listener transactional */
   FALSE,                    /* Retries */

   /*** Source Settings ***/
   FALSE,   /* Resource manage source */
   FALSE,   /* Warnings */
   MPI_SCOPE_MAP,   /* Source scopes */
   MPI_ACTION_KEEP | MPI_ACTION_DELETE,   /* Source OnSuccess */
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT,   /* Source OnFailure */
   MPI_SCOPE_MAP,   /* Default scope */
   MPI_ACTION_KEEP,   /* Default OnSuccess */
   MPI_ACTION_ROLLBACK,   /* Default OnFailure */

   /*** Target Settings ***/
   FALSE,   /* Resource manage target */
   FALSE,   /* Warnings */
   MPI_SCOPE_MAP | MPI_SCOPE_CARD,   /* Target scopes */
   MPI_ACTION_CREATE,   /* Target OnSuccess */
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT,   /* Target OnFailure */
   MPI_SCOPE_MAP,   /* Default scope */
   MPI_ACTION_CREATE,   /* Default OnSuccess */
   MPI_ACTION_ROLLBACK   /* Default OnFailure */
};

/* The adapter object virtual table */
MPI_ADAPTER_VTABLE SampAdapterTable =
{
	sizeof(MPI_ADAPTER_VTABLE), /* size of this structure */
	SampCompareWatches,
	SampCompareResources,
	SampGet,
	SampPut,
	SampBeginTransaction,
	SampEndTransaction,
	SampListen,
	SampValidateProperties,
	SampValidateConnection,
	SampCompareConnection,
	SampOnNotify
};

/* The connection object virtual table */
MPI_CONNECTION_VTABLE SampConnectionTable = 
{
	sizeof(MPI_CONNECTION_VTABLE),
   SampConnect,
   SampDisconnect
};

/****************************************************************************/
/*                                                                          */
/* Function:    SampInitializeLibrary                                       */
/*                                                                          */
/* Description: Perform any library initialization that is required.        */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC SampInitializeLibrary(void)
{
   /* Do any initializition of the DLL here (creating critical sections etc) */
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampDestroyLibrary                                          */
/*                                                                          */
/* Description: Cleans up any resources allocated by the library.           */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC SampDestroyLibrary(void)
{
   /* Cleanup anything created in SampInitializeLibrary */
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampCreateAdapterInstance                                   */
/*                                                                          */
/* Description: Create an adapter object for this adapter.  It is here that */
/*              the list of properties is registered.                       */
/*                                                                          */
/* Inputs:      hCard - Card object                                         */
/*                                                                          */
/* Outputs:     phAdapter - Returned adapter object                         */
/*                                                                          */
/****************************************************************************/
MPIRC SampCreateAdapterInstance (HMPIADAPT *phAdapter,
                                 HMPICARD  hCard)
{
   MPIRC  rc;
   rc = mpiAdapterCreate(phAdapter, hCard, &SampAdapterTable);

   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = mpiObjectNewPropColl(*phAdapter, 
                                MPI_PROPBASE_USER, 
                                NUM_ADAPTER_PROPERTIES, 
                                SampAdapterProperties);

      /* Do any other initialization of instance of adapter object */
   }
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampDestroyAdapterInstance                                  */
/*                                                                          */
/* Description: Frees up any resources used by the adapter object, then     */
/*              destroys the object itself.                                 */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC SampDestroyAdapterInstance(HMPIADAPT hAdapter)
{
   /* Free up any memory or data structures use by the adapter instance */

   return(mpiObjectDestroy(hAdapter));   
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampCreateConnectionInstance                                */
/*                                                                          */
/* Description: Create a connection object for this adapter.  It is here    */
/*              that the list of properties is registered.                  */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     phConnection - Connection object                            */
/*                                                                          */
/****************************************************************************/
MPIRC SampCreateConnectionInstance(HMPICONNECT *phConnection)
{
   MPIRC  rc;
   rc = mpiConnectionCreate(phConnection, &SampConnectionTable);

   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = mpiObjectNewPropColl(*phConnection, 
                                MPI_PROPBASE_USER, 
                                NUM_CONNECT_PROPERTIES, 
                                SampConnectProperties);

      /* Do any other initialization of instance of connection object */
   }
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampDestroyConnectionInstance                               */
/*                                                                          */
/* Description: Frees up any resources used by the connection object, then  */
/*              destroys the object itself.                                 */
/*                                                                          */
/* Inputs:      hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC SampDestroyConnectionInstance(HMPICONNECT hConnection)
{
   /* Free up any memory or data structures use by the connection instance */

   return(mpiObjectDestroy(hConnection));   
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampCompareWatches                                          */
/*                                                                          */
/* Description: Compares 2 adapter objects to see if they correspond to the */
/*              same watch.  This method only needs to be provided if the   */
/*              adapter also provides a CombinedListen method.              */
/*                                                                          */
/*              It is provided here for completeness.                       */
/*                                                                          */
/* Inputs:      hAdapter1 - 1st adapter object                              */
/*              hAdapter2 - 2nd adapter object                              */
/*                                                                          */
/* Outputs:     peComp - indicates whether watches match                    */
/*                                                                          */
/****************************************************************************/
MPIRC	SampCompareWatches(HMPIADAPT hAdapter1,
                         HMPIADAPT hAdapter2,
                         MPICOMP *peComp)
{
   char *lpszFile1;
   char *lpszFile2;
   char *lpszDirectory1;
   char *lpszDirectory2;
   size_t nLen;
   MPIRC rc;

   /*
   ** Get the adapter properties to compare.  If the file and directory
   ** are the same, then it's the same resource
   */
   rc = mpiPropertyGetText(hAdapter1, AP_FILE, 0, &lpszFile1, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter1, AP_DIRECTORY, 0, &lpszDirectory1, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter2, AP_FILE, 0, &lpszFile2, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter2, AP_DIRECTORY, 0, &lpszDirectory2, &nLen); CHKERR(rc);

   if ((rc = strcmp(lpszDirectory1, lpszDirectory2)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszFile1, lpszFile2)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   *peComp = MPI_CMP_EQUAL;

EXCEPTION:

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampCompareResources                                        */
/*                                                                          */
/* Description: This function is not required for Merator 5.1.              */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampCompareResources(HMPIADAPT hAdapter1,
                           HMPIADAPT hAdapter2,
                           MPICOMP *peComp)
{
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampGet                                                     */
/*                                                                          */
/* Description: Get data from the resource and put out to the stream.       */
/*              This may be called in response to a trigger event (the      */
/*              SampListen function detecting an event and adding to the    */
/*              message collection) or else it may be called directly for   */
/*              an input card in a map, or a GET function call.             */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampGet(HMPIADAPT   hAdapter,
              HMPICONNECT hConnection)
{
   HMPISTREAM hStream;
   HMPIMSGCOLL hMsgColl;
   char   szDirectory[MAX_PATH];
   char   szFile[MAX_PATH];
   char   *lpszFileName;
   FILE   *fp;
   size_t nLen;
   int    bIsEnd;
   int    iContext;
   MPIRC  rc;

   /* Get the stream object to which pages will be written */
   rc = mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_FROM_ADAPT, 0, &hStream); CHKERR(rc);

   /* Get the context to see whether this is in response to an input event */
   rc = mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);

   if (iContext == MPI_CONTEXT_SOURCE_EVENT)
   {
      /* 
      ** This is a source event - 
      ** Get the message collection object and get all files from the 
      ** collection.  Note that because there's not a good concept of a 
      ** 'connection' with files we have to make a 'connection' here.  Normally,
      ** this would not be the case - a connection to a database or message queue
      ** would be made, and the message collection would contain message ID's or
      ** some other concept that uniquely identifies some resource.
      */
      rc = mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_MSG_COLLECTION, 0, &hMsgColl); CHKERR(rc);
      if (hMsgColl == NULL)
      {
         /* Nothing to get */
         return MPIRC_SUCCESS;
      }

      /* Loop until we hit the end of the collection */
      while (TRUE)
      {
         rc = mpiMsgCollIsEnd(hMsgColl, &bIsEnd); CHKERR(rc);
         if (bIsEnd)
            break;
         rc = mpiMsgCollGetNext(hMsgColl, &lpszFileName, &nLen, NULL, NULL, NULL, NULL); CHKERR(rc);

         /* Separate out directory and filename */
         SplitDirectoryAndFile(lpszFileName, szDirectory, szFile);
         rc = mpiPropertySetText(hAdapter, AP_DIRECTORY, 0, szDirectory, strlen(szDirectory)); CHKERR(rc);
         rc = mpiPropertySetText(hAdapter, AP_FILE, 0, szFile, strlen(szFile)); CHKERR(rc);

         /* 
         ** 'Connect' to the file (ie open it).  This will set the filehandle
         ** in the connection object
         */
		/* In order to make a "connection" to the file the context is temporarly switched to MPI_CONTEXT_SOURCE
		 * so that the SampConnect function will open the file 
		 * The file could have been open here with a simple call to fopen but we call SampConnect 
		 * just to show the manipulation of the file handle using the connection object
		 */
		iContext = MPI_CONTEXT_SOURCE;
	    rc = mpiPropertySetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, iContext); CHKERR(rc);

        rc = SampConnect(hConnection, hAdapter); CHKERR(rc);
		
		iContext = MPI_CONTEXT_SOURCE_EVENT;
	    rc = mpiPropertySetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, iContext); CHKERR(rc);

         /* Get the filehandle */
         rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, &fp); CHKERR(rc);

         rc = ReadData(hStream, fp); CHKERR(rc);
         rc = mpiPropertySetInteger(hAdapter, MPIP_ADAPTER_NUM_MESSAGES , 0, 1); CHKERR(rc);

         /* This will close the file again */
         rc = SampDisconnect(hConnection); CHKERR(rc);
     }
   }
   else
   {
      /* 
      ** It's not a source event -
      ** Get the file handle that was setup in the SampConnect call 
      */
      rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, &fp); CHKERR(rc);
      rc = ReadData(hStream, fp); CHKERR(rc);

      /* Set the number of messages to be 1 - the whole file corresponds to a single message */
      rc = mpiPropertySetInteger(hAdapter, MPIP_ADAPTER_NUM_MESSAGES , 0, 50);

      /* Return end of data to inform resource manager that the input data is exhausted */
      return (MPIRC_W_END_OF_DATA);
   }

EXCEPTION:
   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampPut                                                     */
/*                                                                          */
/* Description: Gets data from the stream and outputs it.  This function is */
/*              called for output cards or PUT function calls.              */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampPut(HMPIADAPT   hAdapter,
              HMPICONNECT hConnection)
{
   FILE *fp;
   char *pData;
   HMPISTREAM hStream;
   HMPISTREAMPAGE hPage;
   int bIsEnd;
   size_t nSizeOfData;
   MPIRC  rc;

   /* Get the file handle that was setup in the SampConnect call */
   rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, &fp); CHKERR(rc);

   /* Get the stream object from which data will be obtained */
   rc = mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_TO_ADAPT, 0, &hStream); CHKERR(rc);

   /* write data from stream to the file in a loop */
   while(TRUE)
   {
 	 	rc = mpiStreamIsEnd (hStream, &bIsEnd); CHKERR(rc);
      if (bIsEnd)
         break;
	   rc = mpiStreamReadPage (hStream, &hPage); CHKERR(rc);
	   rc = mpiStreamPageGetInfo (hPage, &pData, &nSizeOfData); CHKERR(rc);
	   fwrite (pData, 1, nSizeOfData, fp);
   }

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampBeginTransaction                                        */
/*                                                                          */
/* Description: Start a transaction - this is called on an open connection  */
/*              before any get or put calls.  For this adapter there is     */
/*              nothing to do.                                              */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampBeginTransaction(HMPIADAPT hAdapter,
                           HMPICONNECT hConnection)
{
   /* Nothing to do in this case - this function could be omitted completely */
   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampEndTransaction                                          */
/*                                                                          */
/* Description: Commit or rollback the transaction.  This is called at the  */
/*              point defined by the card's scope (end of the card, map or  */
/*              burst).                                                     */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*              eAction - MPI_ACTION_COMMIT or MPI_ACTION_ROLLBACK          */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampEndTransaction(HMPIADAPT hAdapter,
                         HMPICONNECT hConnection,
                         MPITRANS eAction)
{
   char   *lpszFile;
   char   *lpszDirectory;
   char   szFile[100];
   int    iContext;
   int    iOnSuccess;
   FILE   *fp;
   size_t nLen;
   MPIRC  rc;

   /* 
   ** If this is output card then close the file.
   ** If input and action is to delete, then do so.
   */
   rc = mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   rc = mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_ON_SUCCESS, 0, &iOnSuccess); CHKERR(rc);
   if (iContext == MPI_CONTEXT_TARGET || iContext == MPI_CONTEXT_PUT)
   {
      rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, (const void *) &fp); CHKERR(rc);
      fclose(fp);
	  rc = mpiPropertySetPtr (hConnection, CP_FILE_HANDLE, 0, NULL); CHKERR(rc);
   }
   else if (iOnSuccess == MPI_ACTION_DELETE && eAction == MPI_COMMIT)
   {
      /* 
      ** Close the handle so we can delete it - this will break the 'connection'
      ** so we must return indicating that the connection is now bad.
      */
      rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, (const void *) &fp); CHKERR(rc);
      fclose(fp);
	  rc = mpiPropertySetPtr (hConnection, CP_FILE_HANDLE, 0, NULL); CHKERR(rc);

      /* Get the filename so we can delete it */
      rc = mpiPropertyGetText(hConnection, CP_FILE, 0, &lpszFile, &nLen); CHKERR(rc);
      rc = mpiPropertyGetText(hConnection, CP_DIRECTORY, 0, &lpszDirectory, &nLen); CHKERR(rc);
      sprintf(szFile, "%s\\%s", lpszDirectory, lpszFile);
      {
         _unlink(szFile);
	       SetErrorCode (hAdapter, MPIRC_E_BAD_CONNECTION);
		   return MPIRC_SUCCESS;
      }
   }

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampListen                                                  */
/*                                                                          */
/* Description: "Listen" for a file to arrive in the specified directory.   */
/*              When a file is found, add its descriptor to the message     */
/*              collection.  The 'Get' function will be called in response  */
/*              to actually pick up the file.  The code in SampGet gets     */
/*              the message from the collection.                            */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampListen(HMPIADAPT hAdapter,
                 HMPICONNECT hConnection)
{
   HMPIMSGCOLL hMsgColl;
   char   szWildcard[MAX_PATH];
   size_t nWildLen;
   size_t nLen;
   char   *lpszDirectory;
   char   *lpszFile;
   char   szFile[100];
   struct _finddata_t fd;
   long   hFind;
   BOOL   bEvent = FALSE;
   MPIRC  rc;

   rc = mpiPropertyGetText(hAdapter, AP_DIRECTORY, 0, &lpszDirectory, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_FILE, 0, &lpszFile, &nLen); CHKERR(rc);
   sprintf(szFile, "%s\\%s", lpszDirectory, lpszFile);

   /* Get the find handle */
   rc = mpiPropertyGetInteger(hConnection, CP_FIND_HANDLE, 0, (int *) &hFind); CHKERR(rc);

   /* Listen in directory for files of given name */
   if (hFind == 0)
   {
      hFind = _findfirst(szFile, &fd);
      if (hFind != -1)
      {
         /* We've found something! Store the find handle in the connection object */
         rc = mpiPropertySetInteger(hConnection, CP_FIND_HANDLE, 0, (int) hFind); CHKERR(rc);
         bEvent = TRUE;
      }
   }
   else
   {
      if (_findnext(hFind, &fd) != -1)
      {
         /* Found something */
         bEvent = TRUE;
      }
   }

   if (bEvent)
   {
      /* 
      ** Add a message to the collection.  If the filename contains a wildcard
      ** then this is extracted by calling mpiExtractWildcard.
      */
      nWildLen = sizeof(szWildcard);
      rc = mpiExtractWildcard(lpszFile, strlen(lpszFile), fd.name, strlen(fd.name), 
                              szWildcard, &nWildLen); CHKERR(rc);
	  sprintf(szFile, "%s\\%s", lpszDirectory, fd.name);
      rc = mpiPropertyGetObject(hAdapter, MPIP_ADAPTER_MSG_COLLECTION, 0, &hMsgColl); CHKERR(rc);
      rc = mpiMsgCollNewMsg(hMsgColl, szFile, strlen(szFile) + 1, szWildcard, nWildLen, NULL, NULL); CHKERR(rc);
   }

EXCEPTION:

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampValidateProperties                                      */
/*                                                                          */
/* Description: Ensure that the properties are valid and consistent.        */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampValidateProperties(HMPIADAPT hAdapter)
{
   size_t nLen;
   char   *lpszCmdLine;
   char   szDirectory[MAX_PATH];
   char   szFile[MAX_PATH];
   char   *lpszMode;
   int    iContext;
   MPIRC  rc;

   /* Get the command line */
   rc = mpiPropertyGetText(hAdapter, MPIP_ADAPTER_COMMANDLINE, 0, &lpszCmdLine, &nLen); CHKERR(rc);

   /* 
   ** Should really validate that the command line is valid, but will assume that it 
   ** contains a file and directory path
   */

   /* Separate out directory and filename */
   SplitDirectoryAndFile(lpszCmdLine, szDirectory, szFile);
   rc = mpiPropertySetText(hAdapter, AP_DIRECTORY, 0, szDirectory, strlen(szDirectory)); CHKERR(rc);
   rc = mpiPropertySetText(hAdapter, AP_FILE, 0, szFile, strlen(szFile)); CHKERR(rc);

   rc = mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   if (iContext == MPI_CONTEXT_PUT || iContext == MPI_CONTEXT_TARGET)
     lpszMode = "wb";
   else
     lpszMode = "rb";
   rc = mpiPropertySetText(hAdapter, AP_MODE, 0, lpszMode, strlen(lpszMode)); CHKERR(rc);

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampValidateConnection                                      */
/*                                                                          */
/* Description: "Ping" the connection to make sure that it is still valid.  */
/*              This gets called periodically when a connection is to be    */
/*              reused.  The Event Server configuration determines whether  */
/*              this should be called, and if so how frequently.            */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampValidateConnection(HMPIADAPT   hAdapter,
                             HMPICONNECT hConnection)
{
   FILE  *fp;
   MPIRC rc;

   /* Get the filehandle */
   rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, &fp); CHKERR(rc);

   /* 'ping' the connection to ensure it's valid */
   if (ferror(fp) != 0)
   {
      rc = MPIRC_E_BAD_CONNECTION;
   }

EXCEPTION:

   SetErrorCode (hConnection, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampCompareConnection                                       */
/*                                                                          */
/* Description: Compare the properties of the connection with those of the  */
/*              adapter.  The connection is an existing, open connection.   */
/*              The adapter object is one which has not yet been associated */
/*              with a connection object.  If this call returns             */
/*              MPI_CMP_EQUAL then this connection will be used for this    */
/*              adapter object.                                             */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     peComp - MPI_CMP_*                                          */
/*                                                                          */
/****************************************************************************/
MPIRC	SampCompareConnection(HMPIADAPT   hAdapter,
                            HMPICONNECT hConnection,
                            MPICOMP     *peComp)
{
   char   *lpszDirectoryNew;
   char   *lpszDirectoryExisting;
   char   *lpszFileNew;
   char   *lpszFileExisting;
   char   *lpszModeNew;
   char   *lpszModeExisting;
   size_t nLen;
   int    bActive;
   int    rc;

   /*
   ** Connections can only be shared if within same map - we know that this is the
   ** same map if the connection is 'active' (if it is inactive it means that the
   ** connection is in a 'pool' of open but inactive connections 
   */
   rc = mpiPropertyGetInteger(hConnection, MPIP_CONNECTION_INUSE, 0, &bActive); CHKERR(rc);
   if (!bActive)
   {
      *peComp = MPI_CMP_LESS;
      return MPIRC_SUCCESS;
   }

   /*
   ** The connection is the same if the file and directory and openmode are the same.
   */
   rc = mpiPropertyGetText(hConnection, CP_DIRECTORY, 0, &lpszDirectoryExisting, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hConnection, CP_FILE, 0, &lpszFileExisting, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hConnection, CP_MODE, 0, &lpszModeExisting, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_DIRECTORY, 0, &lpszDirectoryNew, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_FILE, 0, &lpszFileNew, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_MODE, 0, &lpszModeNew, &nLen); CHKERR(rc);

   if ((rc = strcmp(lpszModeExisting, lpszModeNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszDirectoryExisting, lpszDirectoryNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszFileExisting, lpszFileNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   /* Everything matches!  The file can be shared */
   *peComp = MPI_CMP_EQUAL;

EXCEPTION:

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampOnNotify                                                */
/*                                                                          */
/* Description: An entry point to perform initialization for listeners,     */
/*              sources or targets.  The starts and stops are called        */
/*              before/after all calls to get, put or listen.               */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              iID - the event                                             */
/*              iParam - not used.                                          */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampOnNotify(HMPIADAPT hAdapter,
                   int iID,
                   int iParam,
                   HMPICONNECT hConnection)
{
   switch (iID)
   {
   case MPIN_ADAPTER_GETSTART:	 /* Prior to any Get calls for the card */
      break;
   case MPIN_ADAPTER_GETSTOP:		 /* After all Get calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTART: 	 /* Prior to any Put calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTOP:		 /* After all Put calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTART: /* Prior to any Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTOP:	 /* After all Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENABORT: /* Called to abort a non-polling listener */
      break;
   case MPIN_ADAPTER_MAPABORT:    /* Called to notify that map has been aborted */
      break;
   default:
      break;
   }

   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampConnect                                                 */
/*                                                                          */
/* Description: Connect to the resource and store the connection context    */
/*              in the connection object.                                   */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampConnect(HMPICONNECT hConnection,
                  HMPIADAPT hAdapter)
{
   size_t nLen;
   char   *lpszDirectory;
   char   *lpszFile;
   char   *lpszMode;
   char   szFile[100];
   int    iContext;
   FILE   *fp;
   MPIRC  rc;

   /* Context says where the call is coming from */
   rc = mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   if (iContext == MPI_CONTEXT_SOURCE_EVENT)
   {
      /*
      ** If this is a source event, we can't use the concept of a connection -
      ** See SampGet for more explanation
      */
      SetErrorCode (hConnection, MPIRC_SUCCESS);
      return MPIRC_SUCCESS;
   }

   rc = mpiPropertyGetText(hAdapter, AP_DIRECTORY, 0, &lpszDirectory, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_FILE, 0, &lpszFile, &nLen); CHKERR(rc);
   rc = mpiPropertyGetText(hAdapter, AP_MODE, 0, &lpszMode, &nLen); CHKERR(rc);

   sprintf(szFile, "%s\\%s", lpszDirectory, lpszFile);

   /* Open the file */
   if ((fp = fopen(szFile, lpszMode)) == NULL)
   {
      return ERR_E_CANT_CONNECT;
   }

   /* 
   ** Store the file pointer for the get or put functions.
   ** Store the file and directory names and the open mode so that they
   ** can be compared in SampCompareConnection.
   */
   rc = mpiPropertySetPtr (hConnection, CP_FILE_HANDLE, 0, (const void *) fp); CHKERR(rc);
   rc = mpiPropertySetText(hConnection, CP_DIRECTORY, 0, lpszDirectory, strlen(lpszDirectory)); CHKERR(rc);
   rc = mpiPropertySetText(hConnection, CP_FILE, 0, lpszFile, strlen(lpszFile)); CHKERR(rc);
   rc = mpiPropertySetText(hConnection, CP_MODE, 0, lpszMode, strlen(lpszMode)); CHKERR(rc);

   /* Set this to 0 to initialize */
   rc = mpiPropertySetInteger(hConnection, CP_FIND_HANDLE, 0, 0); CHKERR(rc);

EXCEPTION:

   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SampDisconnect                                              */
/*                                                                          */
/* Description: Disconnect from the resource.                               */
/*                                                                          */
/* Inputs:      hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	SampDisconnect(HMPICONNECT hConnection)
{
   FILE  *fp;
   MPIRC rc;

   rc = mpiPropertyGetPtr (hConnection, CP_FILE_HANDLE, 0, (const void *) &fp); CHKERR(rc);
   if(fp) 
   {
	   fclose(fp);
       rc = mpiPropertySetPtr (hConnection, CP_FILE_HANDLE, 0, NULL); CHKERR(rc);
   }

EXCEPTION:

   SetErrorCode (hConnection, rc);
   return rc;
}


/****************************************************************************/
/*                                                                          */
/* Function:    SplitDirectoryAndFile                                       */
/*                                                                          */
/* Description: Separates the directory from the filename. This works only  */
/*              for Windows paths.                                          */
/*                                                                          */
/* Inputs:      lpszFullPath - full path including directory and file       */
/*                                                                          */
/* Outputs:     lpszDirectory - the directory                               */
/*              lpszFile - the filename                                     */
/*                                                                          */
/****************************************************************************/
void SplitDirectoryAndFile(char *lpszFullPath,
                           char *lpszDirectory,
                           char *lpszFile)
{
   char *pc;

   /* 
   ** Assume that there is a full path and split the file from the directory.  If the path
   ** is null then use current directory 
   */
   pc = strrchr(lpszFullPath, '\\');
   if (pc == NULL)
   {
      GetCurrentDirectory(MAX_PATH, lpszDirectory);
      strcpy(lpszFile, lpszFullPath);
   }
   else
   {
      strcpy(lpszDirectory, lpszFullPath);
      lpszDirectory[(int)pc - (int)lpszFullPath] = '\0';
      strcpy(lpszFile, pc+1);
   }
}

/****************************************************************************/
/*                                                                          */
/* Function:    ReadData                                                    */
/*                                                                          */
/* Description: Reads data from the file and puts it out to the stream.     */
/*              The chosen page size is 8K, but it need not be this size.   */
/*                                                                          */
/* Inputs:      hStream - the stream object to which data is added.         */
/*              fp - file pointer for a file opened for read access.        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC ReadData (HMPISTREAM hStream,
                FILE       *fp)
{
   HMPISTREAMPAGE hPage;
   size_t nLen;
   char   *lpData;
   MPIRC  rc = MPIRC_SUCCESS;
   
   do
   {
      /* Create an 8K page */
      rc = mpiStreamNewPage (hStream, &hPage, PAGE_SIZE); CHKERR(rc);

      /* Get the address of the buffer */
      rc = mpiStreamPageGetInfo (hPage, &lpData, &nLen); CHKERR(rc);

	  nLen = fread(lpData, 1, PAGE_SIZE, fp);

      /* Add the page to the stream */
      rc = mpiStreamWritePageEx (hStream, hPage, nLen); CHKERR(rc);

   } while (nLen == PAGE_SIZE);

EXCEPTION:

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    SetErrorCode                                                */
/*                                                                          */
/* Description: Sets the error code and message properties of the object.   */
/*                                                                          */
/* Inputs:      hObject - object in error (adapter or connection)           */
/*              iRC     - the return code to set in the object              */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
void SetErrorCode(HMPIOBJ hObject, int iRC)
{
   int  i;
   char *lpszMsg = NULL;
   struct
   {
      int  rc;
      char *szErrMsg;
   } stErrors[] = 
   {
      MPIRC_SUCCESS,      "Success",
      ERR_E_CANT_CONNECT, "Failed to connect",
   };
   #define NUM_ERRORS (sizeof(stErrors)/sizeof(stErrors[0]))
   
   for (i = 0;  i < NUM_ERRORS;  i++)
   {
      if (iRC = stErrors[i].rc)
      {
         lpszMsg = stErrors[i].szErrMsg;
         break;
      }
   }

   if (lpszMsg == NULL)
   {
      lpszMsg = "Failure";
   }

   mpiPropertySetInteger(hObject, MPIP_OBJECT_ERROR_CODE, 0, iRC);
   mpiPropertySetText(hObject, MPIP_OBJECT_ERROR_MSG, 0, lpszMsg, strlen(lpszMsg));
}
