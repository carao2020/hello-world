package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;

import com.ibm.websphere.dtx.ds.MDSException;
import com.ibm.websphere.dtx.ds.typetree.TTComponent;
import com.ibm.websphere.dtx.ds.typetree.TTGroup;
import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTType;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.TYPE_CLASS;

/**
 * This example demonstrates how to open a type tree, perform an update and save to a file.
 * 
 *
 */
public class AddComponentExample {
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	// by default output files are located in 'DefaultLocation' relative to class file
	
	private static String DefaultSourceLocation = "files/example.mtt";
	private static String DefaultTargetLocation = "output/example.mtt";
	
	private String _sourceLocation = DefaultSourceLocation;
	private String _targetLocation = DefaultTargetLocation;
	
	public AddComponentExample() {
		super();
	}

	/**
	 * This method runs the example
	 */
	public void run(){
		
		TTSource typeTreeSource = TTSource.openTypeTree(getSourceLocation());
	
		if(typeTreeSource == null){
			System.out.println("Can not open type tree from location: " + getSourceLocation());
			return;
		}
		TTGroup group = null;
		TTType type = typeTreeSource.getType("grp Fields");
		if(type.getTypeClass() == TYPE_CLASS.TI_GROUP){
			group = (TTGroup)type;
		}
		
		TTItem item = (TTItem)typeTreeSource.getType("simple Fields");
		
		try {
			TTComponent comp = group.addComponent(item);
			comp.setRestart(true);
			comp.setIdentifier(true);
		} catch (MDSException e) {
			System.out.println(e);
		}
		
		typeTreeSource.saveAs(getTargetLocation());
		
		typeTreeSource.close();
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultSourceLocation;
		AddComponentExample target = new AddComponentExample();
		target.setSourceLocation(location);
		target.run();
	}

	public String getSourceLocation() {
		if(_sourceLocation != null && _sourceLocation.equals(DefaultSourceLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("./");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _sourceLocation);
				_sourceLocation = sourceFile.getAbsolutePath();
			}
		}
		return _sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		_sourceLocation = sourceLocation;
	}

	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getClassLoader().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}
}
