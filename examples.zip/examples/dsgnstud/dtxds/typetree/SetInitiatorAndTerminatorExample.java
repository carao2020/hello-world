package typetree;
/**
* Licensed Materials - Property of IBM 
* 5724-Q23
* �Copyright IBM Corp. 2012
* ALL RIGHTS RESERVED
*/


import java.io.File;
import java.net.URL;

import com.ibm.websphere.dtx.ds.MDSException;
import com.ibm.websphere.dtx.ds.typetree.TTItem;
import com.ibm.websphere.dtx.ds.typetree.TTSource;
import com.ibm.websphere.dtx.ds.typetree.TTType;
import com.ibm.websphere.dtx.ds.typetree.TTTypeSyntax;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.CONTROL_CHAR;
import com.ibm.websphere.dtx.ds.typetree.TTConstants.SYNTAX_CHAR_TYPE;

/**
 * This example demonstrates setting of initiator and terminator on all item types, where INITITATOR = ItemName
 * <p>
 * For example if we have an item called CurrentDate and we want an initiator to be: <HT><OWSP><CurrentDate> and 
 * then next item is CurrentTime where we want an initiator to be: <HT><OWSP><CurrentTime> as well as
 * for each of those we would have a terminator like <HT><OWSP></CurrentDate><NL>
 * <p>
 * So we have as a list all of the items, and then a rule that says for each item set initiator 
 * to <HT><OWSP>{Item name} and a rule for each item to set terminator 
 * to <HT><OWSP></{Item name}><NL>
 *
 */
public class SetInitiatorAndTerminatorExample {
	
	/**
	 * Copyright
	 */
	public static final String copyright=
        "Licensed Materials - Property of IBM 5724-Q23 �Copyright IBM Corp. 2012 ALL RIGHTS RESERVED";

	private static String DefaultSourceLocation = "files/Contact.mtt";
	private static String DefaultTargetLocation = "output/Contact_init_term.mtt";
	
	private String _sourceLocation = DefaultSourceLocation;
	private String _targetLocation = DefaultTargetLocation;
	
	TTSource _typeTreeSource = null;
	
	/**
	 * @param fileLocation
	 */
	public SetInitiatorAndTerminatorExample() {
		super();
	}

	/**
	 * This method runs the example
	 */
	public void run(){
		
		loadTypeTree();
		if(_typeTreeSource == null){
			System.out.println("Can not open type tree with location: " + getSourceLocation());
			return;
		}
		
		try {
			
			TTWalker walker = new TTWalker() {
				
				@Override
				public void processType(TTType type) {
					
					switch (type.getTypeClass()) {
					case TI_ITEM:
						TTItem item = (TTItem)type;
					
						TTTypeSyntax typeSyntax = item.getTypeProperties().getTypeSyntax();
						try {
							typeSyntax.setInitiator(SYNTAX_CHAR_TYPE.LITERAL);
							//setting non-printable characters
							String initator = getDisplaySymbolFromRealSymbol("HT") +
											getDisplaySymbolFromRealSymbol("OWSP") +
											getDisplaySymbolFromRealSymbol(item.getTypeName());
							
							typeSyntax.getInitiator().setValue(initator);
							
							String terminator = getDisplaySymbolFromRealSymbol("HT") +
							getDisplaySymbolFromRealSymbol("OWSP") +
							getTerminatorFromSymbol(item.getTypeName()) +
							getDisplaySymbolFromRealSymbol("NL");
			
							typeSyntax.setTerminator(SYNTAX_CHAR_TYPE.LITERAL);
							typeSyntax.getTerminator().setValue(terminator);
							
						
						} catch (MDSException e) {
							
							e.printStackTrace();
						}
						
						break;
					default:
						break;
					}
				}
			};
			walker.walkType(_typeTreeSource.getRootType());
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		_typeTreeSource.saveAs(getTargetLocation());
		
		_typeTreeSource.close();
	}
	
	protected void loadTypeTree(){
		
		// Load type tree from a file.
		String fileLocation = getSourceLocation();
		if(DefaultSourceLocation.equals(getSourceLocation())){
			URL url = getClass().getResource(DefaultSourceLocation);
			fileLocation = url.getFile().replace("%20", " ").substring(1);
		}
		File sourceFile = new File(fileLocation);
		if(sourceFile.exists()){
			/* Open Type Tree */
			_typeTreeSource = TTSource.openTypeTree(sourceFile.getAbsolutePath());
		}

	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String location = args.length == 1 ? args[0] : DefaultSourceLocation;
		SetInitiatorAndTerminatorExample target = new SetInitiatorAndTerminatorExample();
		target.setSourceLocation(location);
		target.run();
	}

	public String getSourceLocation() {
		return _sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		_sourceLocation = sourceLocation;
	}

	public String getTargetLocation() {
		if(_targetLocation != null && _targetLocation.equals(DefaultTargetLocation)){
			// by default output files are located in 'DefaultLocation' relative to class file
			URL url = getClass().getResource("../../");
			if (url != null) {
				String basePath = url.getFile().replace("%20", " ").substring(1);
				
				File sourceFile = new File(basePath + _targetLocation);
				_targetLocation = sourceFile.getAbsolutePath();
			}
		}
		return _targetLocation;
	}

	public void setTargetLocation(String targetLocation) {
		_targetLocation = targetLocation;
	}

	private static String getTerminatorFromSymbol(String aSymbol)
	{
		if(aSymbol == null) return "<>";
		return "</"+aSymbol+">";
	}
	

	private static String getDisplaySymbolFromRealSymbol(String aSymbol)
	{
		if(aSymbol == null) return "<>";
		return "<"+aSymbol+">";
		
	}

}
