/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MException;
import com.ibm.websphere.dtx.dtxpi.MConstants;

public class Example2 implements Runnable
{
    private static int num_maps;
    private static Object lock = new Object();
    private MMap map;

    public Example2(MMap map)
    {
        this.map = map;
    }

    public static void main(String[] args)
    {
        try
        {
            // this defines what resource configuration file to use
            String resCfgFile = null;

            // Initialize the API
            MMap.initializeAPI(resCfgFile);

            // Load a map twice
            MMap map1 = new MMap("test2.mmc");
            MMap map2 = new MMap("test2.mmc"); /* This 2nd call will not read the MMC file.*/

            // enable resource manager for common file resources
            map1.setIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);
            map2.setIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);

            // Run the maps
            num_maps = 1;
            new Thread(new Example2(map1)).start();
            synchronized (lock)
            {
                num_maps++;
            }
            new Thread(new Example2(map2)).start();

            // Wait for map threads to complete 
            while( num_maps > 0 )
                Thread.sleep(100);

            // Check the return status
            int iRC = map1.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map1.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            iRC = map2.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            szMsg = map2.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            map1.unload();
            map2.unload();
            MMap.terminateAPI();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }

    public void run()
    {
        RunMap();
    }

    private void RunMap()
    {
        try
        {
            map.run();
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }

        synchronized (lock)
        {
            num_maps--;
        }

        return;
    }
}
