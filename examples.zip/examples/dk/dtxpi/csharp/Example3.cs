/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */
using System;
using com.ibm.websphere.dtx.dtxpi.dtxinterop;

namespace com.ibm.websphere.dtx.dtxpi.example
{
    /// <summary>
    /// This example overides a card in a map
    /// </summary>
    class Example3
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                MFactoryClass imFactory = new MFactoryClass();
                imFactory.InitializeAPI(null);

                // Load a map file 
                MMap map = imFactory.MapLoadFile("test3.mmc");    

                // Turn on burst and summary execution audit on the map instance 
                map.SetIntegerProperty(MConstants.MPIP_MAP_AUDIT_SWITCH, 0, MConstants.MPI_SWITCH_ON);
                map.SetIntegerProperty(MConstants.MPIP_MAP_AUDIT_BURST_EXECUTION, 0, MConstants.MPI_SWITCH_ON);
                map.SetIntegerProperty(MConstants.MPIP_MAP_AUDIT_SUMMARY_EXECUTION, 0, MConstants.MPI_SWITCH_ON);

                // Get the adapter object handle 
                MCard card = map.GetInputCard(1);
                card.OverrideAdapter("GZIP", 0);

                // set a command line for the adapter
                MAdapter adapter = card.GetAdapter();
                adapter.SetTextProperty(MConstants.MPIP_ADAPTER_COMMANDLINE, 0, "-FILE input.gz");

                // Run the map
                map.Run();

                // Check the return status
                string responseMessage = map.GetTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
                int resuleCode = map.GetIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);

                Console.Out.WriteLine("Map Status: " + responseMessage + " " + resuleCode);

                // Unload the Map 
                map.MapUnload();          

                // Exit the API 
                imFactory.TerminateAPI();
            }
            catch (Exception e)
            {
                Console.Out.WriteLine("Error Description: "+e);
            }


        }
    }
}
