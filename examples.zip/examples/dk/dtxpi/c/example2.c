/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#ifdef WIN32
#include <windows.h>
#include <process.h>

#define CRITICAL_SECTION CRITICAL_SECTION
#define INITIALIZE_CRITICAL_SECTION(x) InitializeCriticalSection(x)
#define ENTER_CRITICAL_SECTION(x) EnterCriticalSection(x)
#define LEAVE_CRITICAL_SECTION(x) LeaveCriticalSection(x)
#define DELETE_CRITICAL_SECTION(x) DeleteCriticalSection(x)
#define CREATE_THREAD(a,b) _beginthread((a),0,(b))
#define SLEEP(x) Sleep(x)

void RunMap(HMPIMAP hMap);

#else /* UNIX defines */
#include <pthread.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>

pthread_t tid;

#define CRITICAL_SECTION pthread_mutex_t
#define INITIALIZE_CRITICAL_SECTION(x) pthread_mutex_init((x),NULL)
#define ENTER_CRITICAL_SECTION(x) pthread_mutex_lock(x)
#define LEAVE_CRITICAL_SECTION(x) pthread_mutex_unlock(x)
#define DELETE_CRITICAL_SECTION(x) pthread_mutex_destroy(x)
#define CREATE_THREAD(a,b) pthread_create(&tid,NULL,(void*(*)(void*))(a),(void*)(b))
#ifdef LINUX
#define SLEEP(x) poll(NULL,(int)NULL,(x))
#else
#define SLEEP(x) poll(NULL,NULL,(x))
#endif

void* RunMap(HMPIMAP hMap);
#endif


CRITICAL_SECTION	crit_sec;
int num_maps;

#define CHECK_ERR(rc) if(MPIRC_FAILED(rc)) 	{ printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

int main()
{
	const char 	*szMsg;
	int			iRC;
	HMPIMAP	hMap1;
	HMPIMAP	hMap2;
	MPIRC	rc;
	/* this defines what resource configuration file to use */
	char *szResourceAliasFile=NULL;

	INITIALIZE_CRITICAL_SECTION( &crit_sec);

	rc = mpiInitAPI(szResourceAliasFile); 
	CHECK_ERR(rc);


	rc = mpiMapLoadFile (&hMap1, "test2.mmc");
	CHECK_ERR(rc);
	rc = mpiMapLoadFile (&hMap2, "test2.mmc");   /* This 2nd call will not read the MMC file.*/
	CHECK_ERR(rc);

	/* enable externalized resource manager for common file resources */
	rc = mpiPropertySetInteger(hMap1, MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);
	CHECK_ERR(rc);
	rc = mpiPropertySetInteger(hMap2, MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);
	CHECK_ERR(rc);

	num_maps = 1;
	CREATE_THREAD(RunMap,hMap1);

	ENTER_CRITICAL_SECTION(&crit_sec);
	num_maps++;
	LEAVE_CRITICAL_SECTION(&crit_sec);

	CREATE_THREAD(RunMap,hMap2);

	/* Wait for map threads to complete */
	while(num_maps)
		SLEEP((int)100);

	rc = mpiPropertyGetText (hMap1, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, NULL);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap1, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);

	rc = mpiPropertyGetText (hMap2, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, NULL);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap2, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);

	rc = mpiMapUnload (hMap1);
	CHECK_ERR(rc);
	rc = mpiMapUnload (hMap2);
	CHECK_ERR(rc);

	rc = mpiTermAPI();
	CHECK_ERR(rc);

	DELETE_CRITICAL_SECTION(&crit_sec);
	return 0;
}

#ifdef WIN32
void RunMap(HMPIMAP hMap)
#else /* UNIX version of the function */
void* RunMap(HMPIMAP hMap)
#endif
{
	MPIRC	rc;

	rc = mpiMapRun (hMap);

	ENTER_CRITICAL_SECTION(&crit_sec);
	num_maps--;
	LEAVE_CRITICAL_SECTION(&crit_sec);

#ifdef WIN32
	return;
#else
	return NULL;
#endif

}
