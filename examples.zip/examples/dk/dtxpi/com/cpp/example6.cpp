/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "common.h"

int main()
{
   // Initialize the com libraries
	CoInitialize(NULL);

	try
	{
    IMFactoryPtr pMFactory(__uuidof(MFactory));
		BSTR bstrName = NULL;
    CComBSTR ccbstrName;

    /* Initialize the API */
    pMFactory->InitializeAPI(bstrName);

    /* Load the Map */
    VARIANT varTemp;
    varTemp.vt = VT_UI1 | VT_ARRAY;

    FILE *fp = fopen("test6.mmc", "rb");
    fseek( fp, 0, SEEK_END );

    int nSizeOfData = ftell( fp );
    char* szInputBuffer = (char *)malloc( nSizeOfData );

    fseek( fp, 0, SEEK_SET );
    fread( szInputBuffer, sizeof(char), nSizeOfData, fp );
    fclose( fp );

    SAFEARRAYBOUND bound;
    bound.cElements = nSizeOfData; /* length of the byte array*/
    bound.lLbound = 0;
    varTemp.parray = SafeArrayCreate(VT_UI1, 1, &bound);

    // create the array
    BYTE* pDest;
    SafeArrayAccessData(varTemp.parray, (void**)&pDest);
    memcpy((void*)pDest, szInputBuffer, nSizeOfData);
    SafeArrayUnaccessData(varTemp.parray);

    /* Load the Map */
    IMMapPtr pMMap = pMFactory->MapLoadMemory(_bstr_t("test6"), _bstr_t("."), varTemp, bound.cElements);

    /* Get the adapter object handle for input card #1*/
	  IMCardPtr pMInputCard;
    pMInputCard = pMMap->GetInputCard(1);

	  /* Override the adapter in input card #1 to be a stream */
	  pMInputCard->OverrideAdapter(_bstr_t(bstrName), MPI_ADAPTYPE_STREAM);

	  /* Read the local data file */
    fp = fopen("input.txt", "r");
    fseek( fp, 0, SEEK_END );
    nSizeOfData = ftell( fp );
    realloc( szInputBuffer, nSizeOfData );
    fseek( fp, 0, SEEK_SET );
    fread( szInputBuffer, sizeof(char), nSizeOfData, fp );
    fclose( fp );

	  /* Get the handle to the adapter object */
	  IMAdapterPtr pMInputAdapter = NULL;
	  pMInputAdapter = pMInputCard->GetAdapter();

	  /* Get the handle to the stream object */
	  IMStreamPtr pMInputStream = NULL;
	  pMInputStream = pMInputAdapter->GetStream(MPIP_ADAPTER_DATA_FROM_ADAPT, 0);

     /* Send a single large page */
    varTemp.vt = VT_UI1 | VT_ARRAY;

    bound.cElements = strlen(szInputBuffer);
    bound.lLbound = 0;
    varTemp.parray = SafeArrayCreate(VT_UI1, 1, &bound);

    // create the array
    SafeArrayAccessData(varTemp.parray, (void**)&pDest);
    memcpy((void*)pDest, szInputBuffer, sizeof(TCHAR) * strlen(szInputBuffer));
    SafeArrayUnaccessData(varTemp.parray);
	  pMInputStream->Write(varTemp, strlen(szInputBuffer));

	  /* Get the adapter object handle for output card #1*/
    IMCardPtr pMOutputCard = NULL;
	  pMOutputCard = pMMap->GetOutputCard(1);

	  /* Override the adapter in output card #1 to be a stream */
	  pMOutputCard->OverrideAdapter(_bstr_t(bstrName), MPI_ADAPTYPE_STREAM);

    /* Run the Map */
  	pMMap->Run();

    /* Get the Error Response */
    ccbstrName = (BSTR)pMMap->GetTextProperty(MPIP_OBJECT_ERROR_MSG, 12);
    int nResultCode = pMMap->GetIntegerProperty(MPIP_OBJECT_ERROR_CODE, 123);

    LPCTSTR lpszError = (LPCTSTR)_com_util::ConvertBSTRToString(ccbstrName);
    printf("Map status: %s (%d)\n", lpszError, nResultCode);


    IMAdapterPtr pMOutputAdapter;
    pMOutputAdapter = pMOutputCard->GetAdapter();

    /* Get the handle to the stream object */
    IMStreamPtr pMOutputStream = NULL;
	  pMOutputStream = pMOutputAdapter->GetStream(MPIP_ADAPTER_DATA_TO_ADAPT, 0);

	  /* Get the data in pieces from the stream */
	  pMOutputStream->Seek(0,SEEK_SET);

    long bIsEnd = 0;

	  while (1)
	  {
		  bIsEnd = pMOutputStream->IsEnd();

      /*Clean and Break*/
		  if (bIsEnd)
      {
        pMOutputStream->SetSize(0);
        break;
      }

      /* Get the Stream Page*/
      IMStreamPagePtr pMStreamPage = NULL;
      pMStreamPage = pMOutputStream->ReadPage();

      /* To Get as a array of bytes*/
      pMStreamPage->GetData(FALSE, &varTemp);
      fwrite(varTemp.parray->pvData, 1 , varTemp.parray->rgsabound[0].cElements, stdout);
      /*	      DoSomethingWithData (pData, nSizeOfData); */
	  }

    /* Unload the Map */
	  pMMap->MapUnload();

    /* Exit the API */
    pMFactory->TerminateAPI();
	}

	catch (const _com_error Err)
	{
    printf("Error Description: %s\n", (LPCTSTR)Err.Description());
	}

	CoUninitialize();

	return 0;
}
