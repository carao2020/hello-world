/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import com.ibm.websphere.dtx.dtxpi.MAdapter;
import com.ibm.websphere.dtx.dtxpi.MCard;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.MMap;
import com.ibm.websphere.dtx.dtxpi.MStream;
import com.ibm.websphere.dtx.dtxpi.MException;

public class Example5
{
    private static String szInputBuffer = "This is my input data";

    public static void main(String[] args)
    {
        try
        {
            // Initialize the API
            MMap.initializeAPI(null);

            // Load a map 
            MMap map = new MMap("test5.mmc");

            // Get the adapter object handle for input card #1
            MCard card = map.getInputCardObject(1);

            // Override the adapter in input card #1 to be a stream 
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Get the handle to the stream object 
            MAdapter adapter = card.getAdapter();
            MStream stream = adapter.getOutputStream();

            // Send a single large page 
            stream.write(szInputBuffer.getBytes(), 0, szInputBuffer.length());

            // Get the adapter object handle for output card #2
            card = map.getOutputCardObject(2);

            // Override the adapter in output card #2 to be a stream 
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Get the adapter object handle for output card #2
            adapter = card.getAdapter();
            stream = adapter.getInputStream();

            // Get the data in pieces from the stream 
            stream.seek(0, MConstants.MPI_SEEK_SET);
            while( true )
            {
                boolean bIsEnd = stream.isEnd();

                // Clean and Break
                if( bIsEnd )
                {
                    stream.setSize(0);
                    break;
                }

                byte[] page = stream.readPage();
                System.out.println(new String(page));
/*              DoSomethingWithData (page, page.length); */
            }

            // Clean up
            map.unload();
            MMap.terminateAPI();
        }
        catch( MException e )
        {
            e.printStackTrace();
        }
    }
}
