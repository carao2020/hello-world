IBM Transformation Extender 
Launcher HTTP Listener Example Readme

(c) Copyright International Business Machines Corporation 2016.
All Rights Reserved.

This example readme demonstrates how to use the Launcher HTTP Listener.

===============================================================================
CONTENTS
===============================================================================

    1.  Example Files
    2.  Using This Example
    3.  Notes

===============================================================================
1: EXAMPLE FILES
===============================================================================

Files included in this example:

    lsnrtest.mtt	- Type Tree
    lsnrtest.mms	- Maps
    lsnrtest.msd	- System Definition File
    failinput.html	- HTML response file
    readme.txt  	- This readme file

===============================================================================
2: USING THIS EXAMPLE
===============================================================================

This example contains sample files to be used with the Launcher HTTP Listener.
Refer to the Launcher documentation in the knowledge center for additional 
information: http://www.ibm.com/support/knowledgecenter/SSVSD8

How to run the example:

1)  Update the system definition file (.msd) with the host/port of the Launcher
    HTTP Listener. The default host and port combination is "localhost:5018".
   
2)  Deploy the system
   
3)  Configure the Launcher HTTP Listener.  Choose between the Command Line or
    Launcher Studio steps.  Command line is geared for fast startup and testing.
    The Launcher Studio steps enables tight integration with Launcher startup
    and shutdown.

    Command Line Steps:
    a. Change to the installation directory 
    b. On UNIX, run "setup" script and then change to "bin" sub-directory
    c. For new settings, run "httplsnr test.cfg"
       To modify, run "httplsnr test.cfg -edit -clntport 5017 -lnchport 5018"
    
    Launcher Studio Steps:
    a. Start Launcher Administration
    b. Define settings from the "Listeners" section of the Options tab.
    c. Make sure the new definition has a mode of "Enabled"
    
4)  Run the Launcher HTTP Listener

    Command Line: Run "httplsnr test.cfg"
    
    Launcher Studio: Start Launcher (which also starts the HTTP Listener)
    
5)  (Optional) Monitor the Launcher HTTP Listener and Map Execution Results
    The Browser option can be used for monitoring both Command Line and 
    Launcher Studio configurations, especially from a remote machine. 
    All the options below allow tracing and auditing to be turned on and off
    as needed.

    Browser: Open a browser to this URL, http://localhost:5017/admin/status.
    Change the "host:port" combination as required.
    
    Command Line: Enter '?' at the console for a list of map monitoring,
    tracing and auditing commands.
    
    Launcher Studio: The Management Console "Status" tab can be used to monitor
    map execution and to activate tracing and auditing.
    
6)  (Optional) Start the Launcher monitor to watch the map run.

7)  Execute the Sample Maps From a new Browser window

    1. Enter http://localhost:5017/example for a simple test page
    2. Enter http://localhost:5017/spexample for a customized test page
    3. Enter http://localhost:5017/failinput for a customized failure response
    4. Enter http://localhost:5017/failmap for a generic failure response
    
===============================================================================
3: NOTES
===============================================================================

1. The "spexample" map uses the "-status_page" option to generate a custom HTML
   response.  This response can combine runtime data along with map-specific
   information, such as map name, exit code, and response time.  Refresh the 
   screen to see a change in the map response time and session identifier.

2. The "failinput" example is designed to fail during the validation of the
   HTTP input card.  It highlights how invalid user data can cause a customized
   response to get returned.  The response can be dynamically altered by 
   changing the failinput.html file while the Launcher is running.
   
3. The "failmap" example relies on the installation's m4http_statuspage.html
   file.  Changes to this file only take effect at Launcher startup.  It is
   primarily used for HTTP-based maps that need a default failure response.
   
4. For each watched URL, the HTTP Listener can display the number of map runs
   and the average execution time.  If individual map completion codes and
   times are needed, enable the audit log.  Monitoring and trace activation is
   available at the Command Line, the Management Console and the browser status
   screen.

5. Whenever trace is enabled from the HTTP Listener command line (via "-trace"
   option), HTTP requests and responses will show up on the console.  Enter the
   "p" command at the console to disable the trace output from appearing on the
   screen.  Entering "p" again will toggle the trace output to reappear.  
   Regardless of screen output, trace results continue to get logged to the 
   trace file until tracing is turned off.
    
===============================================================================
                             END OF FILE
===============================================================================

