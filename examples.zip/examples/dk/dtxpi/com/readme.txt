IBM WebSphere Transformation Extender 
Programming COM Interface Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of IBM WebSphere Transformation 
Extender Programming COM Interface example sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    asp subdirectory    contains all source code and supporting files
                        for ASP

    cpp subdirectory    contains all source code and supporting files
                        for C++

    readme.txt          this file


Examples for Loading, Running, and Controlling Maps
---------------------------------------------------
The purposes of the examples are as follows:
    
    example1.cpp - Simplest case of running a map.
    
    example2.cpp - Running multiple instances of a map.
    
    example3.cpp - Overriding a card in a map.
    
    example4.cpp - Using a user-provided status method.
    
    example5.cpp - Using streams to override inputs and outputs.
    
    example6.cpp - Loading a map from memory.
    
    example7.cpp - Getting and setting properties.
    
    example8.cpp - Running a map using DCOM. 


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to be used with the IBM WebSphere 
Transformation Extender Programming Interface C examples. 

This example contains sample files to use the IBM WebSphere 
Transformation Extender. Programming COM Interface to run and control 
maps from C++ and ASP. All source code,and supporting files for C++ 
and ASP are provided in the "cpp" and "asp" subdirectories.

IBM WebSphere Transformation Extender Component Object Model (COM) API
dtxCOM.dll has to be registered using regsrv32.exe utility.
regsrv32.exe is a registry application present in the windows system
directory.
regsrv32.exe %DTXHOME%\dtxCOM.dll

How to build and run the C++ examples, follow these steps:

    1) Build the executables.

        For Windows:

        From a DOS command prompt, build the examples by executing

            nmake /f win32.mk

    2) Copy the executables to the IBM WebSphere Transformation 
       Extender installation directory.

    3) Using the Map Designer, open
    
       install_dir\examples\dk\dtxpi\dtxpiex.mms 
    
       and build the following maps:

        test1.mmc
        test2.mmc
        test3.mmc
        test4.mmc
        test5.mmc

    Note: Ensure that you build the maps for the specific platform 
          for which you will run them on.

    4) Place the compiled map files in the same directory as the 
       example program executable files.

    5) Copy input.txt, input2.txt, and input.gz to the same 
       directory.

    6) Add the IBM WebSphere Transformation Extender Install 
       directory 
       to PATH to execute example 8.

    7) Execute the examples. 


=====================================================================
                             END OF FILE
=====================================================================
