/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.io.*;

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;


public class Example8
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example8 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load a local map file
            String mapPath = makeMapPath(args[2], "test10.mmc");

			// Create a map
            IMMap map = factory.loadMapFile(mapPath);


            // Override the input card so that a local file
            // containing input data can be sent to the remote server
            IMCard card = map.getInputCardObject(1);
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Create a local Object
            AnObject anObject = new AnObject();
            anObject.setString(".. and they all lived happily ever after");

            // serialize the local Object
            ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
            ObjectOutputStream objectOutput=new ObjectOutputStream(byteOutput);
            objectOutput.writeObject(anObject);
            byte[] inputData = byteOutput.toByteArray();
            objectOutput.close();
            byteOutput.close();

            // Pass it to the server via a stream
            IMAdapter adapter = card.getAdapter();
            IMStream stream = adapter.getOutputStream();
            stream.write(inputData, 0, inputData.length);

            // Get the adapter object handle for output card #2
            card = map.getOutputCardObject(2);

            // Override the adapter in output card #2 to be a stream
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Get the output as a stream
            adapter = card.getAdapter();
            stream = adapter.getInputStream();

            // Get the data in pieces from the stream
            int iSize = stream.getSize();
            byte[] page = new byte[(int)iSize];
            stream.seek(0, MConstants.MPI_SEEK_SET);
            while ( true )
            {
                boolean bIsEnd = stream.isEnd();

                // Clean and Break
                if ( bIsEnd )
                {
                    stream.setSize(0);
                    break;
                }

                page = stream.readPage();

            }

            //Create another local Object
            AnObject anotherObject = new AnObject();
            ByteArrayInputStream byteInput = new ByteArrayInputStream(page);

            //Deserialize the data received from map
            ObjectInputStream objectInput=new ObjectInputStream(byteInput);
            anotherObject=(AnObject) objectInput.readObject();
            objectInput.close();
            byteInput.close();

            //print to screen
            System.out.println(anotherObject.getString(""));

            // Clean up
            map.unload();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}