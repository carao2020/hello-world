/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example2 implements Runnable
{
    private static int num_maps;
    private static Object lock = new Object();
    private IMMap map;

    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public Example2(IMMap map)
    {
        this.map = map;
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example2 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load a map twice
            String mapPath = makeMapPath(args[2], "test2.mmc");
            IMMap map1 = factory.loadMapFile(mapPath);
            IMMap map2 = factory.loadMapFile(mapPath);

            // enable resource manager for common file resources
            map1.setIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);
            map2.setIntegerProperty(MConstants.MPIP_MAP_USE_RESOURCE_MANAGER, 0, 1);

            // Run the maps
            num_maps = 1;
            new Thread(new Example2(map1)).start();
            synchronized (lock)
            {
                num_maps++;
            }
            new Thread(new Example2(map2)).start();

            // Wait for map threads to complete
            while ( num_maps > 0 )
                Thread.sleep(100);

            // Check the return status
            int iRC = map1.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map1.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            iRC = map2.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            szMsg = map2.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Clean up
            map1.unload();
            map2.unload();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void run()
    {
        try
        {
            map.run();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }

        synchronized (lock)
        {
            num_maps--;
        }

        return;
    }

}


