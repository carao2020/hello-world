IBM WebSphere Transformation Extender 
Java Class Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Java Class Adapter sample 
files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    testjavaclass.mms    -  Map file
    subclass.mtt         -  Type tree for the SubClass class
    mainclass.mtt        -  Type tree for the MainClass class
    SubClass.java        -  Java source code for the SubClass class
    MainClass.java       -  Java source code for the MainClass class
    SubClass.class       -  SubClass Java class file
    MainClass.class      -  MainClass Java class file
    readme.txt           -  Readme file for the Java Class adapter 
                            examples

Note: All the listed .class files can be generated from the
      corresponding .java files using the Java Compiler (javac). 
      After the class files are placed in the CLASSPATH, the 
      corresponding .mtt files listed here can be generated using 
      the Java Class Importer.


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example explains the main concepts of the Java Class adapter,
such as passing parameters to the class constructors and 
instantiating objects, setting public field values on the objects,
invoking methods, getting public field values, getting method return
values and sharing Java objects in the map.

The example uses primitive Java types, complex Java types (classes)
and arrays of primitive types.

Before running the examples verify that all the listed class files
are in a directory that is included in the CLASSPATH.

Open testjavaclass.mms in the Map Designer.

There are two defined maps:

 - invkadpt
 - procout

procout map is invoked from the invkadpt map.


Map1 - invkadpt
--------------------

invkadpt map has 4 output cards


Output card1 - GenerateSubClass
-------------------------------

This card is invoked first when the map is ran.

The adapter type for this card is Java Class. This cards creates a
Java object of the SubClass type. The source code for this class as
well as the binary file are provided with the example (SubClass.java
and SubClass.class). The type tree for this card was created using
Java Class importer and specifying the SubClass as the input class.

The type tree contains three main components:

 - "this" item
 - "Constructor" group
 - "Fields" group

"this" item:
Contains a reference id that the user specifies. After
the adapter instantiates the SubClass object, it stores it in the
internal pool of objects under the specified reference id. Later,
the adapter can retrieve this object from the pool by using the
reference id. In this example, an id "id1" is chosen, but it can
be any other string. The only format that needs to be avoided
is "Ref.x" where x is a positive integer value. References with
this format are used internally by the adapter. This is explained
later in the readme.

"Constructor" group:
Represents the constructor that the adapter uses to instantiate
the SubClass object. Looking at the type tree it can be seen
that the constructor has one parameter of the int Java type.
If you open the SubClass.java file, you will be able to see that
the SubClass class indeed has a public constructor with a single int
argument.
A value 1 is being passed as the constructor parameter values in
this example.

"Fields" group:
represents the public fields of the object. There
are two public fields in the SubClass class:

 - _intField
 - _byteArrayField

The names of the type tree components match the actual names
of the fields in the class.

The _intField item represents the _intField public field and it
has been assigned the value 5 in the map.

The _byteArrayField group represents the _byteArrayField public
field.

This is a group and not an item because it represents an array of
values. In this case, it is an array of byte values.
In this example, an array of two bytes is created with the values
8 and 9, and this array is then assigned to the _byteArrayField
field on the instantiated SubClass object.

After the card is invoked, the adapter uses the provided data
to instantiate a SubClass object and set the public field values on
it. The adapter also stores this object in the internal pool
of objects under the "id1" reference (key) value.

Note the -T SubClass.log adapter command. This command tells the
adapter to trace the internal operations to the log file that has the
name, SubClass.log. This log file will be stored in the map directory
by default.

Analyze the log file to see the sequence of the operations that the
adapter is performing while executing this card.


Output card2 - PrepareInputForAdapter
-------------------------------------

The first output card was invoking the Java Class adapter directly.
In this second card, the adapter is not actually invoked, but the
data is being prepared for the later adapter invocation.

The type of this card is Sink. If the type of the card is
changed to "File", the example will still work, and you will be able
to analyze the data that is being passed to the adapter by analyzing
the file to which this data was stored.

The type tree for this card was created using
Java Class importer and specifying the MainClass as the input class.

This type tree is similar to the type tree in the first card. It also
has the "this" item, the "Constructor" group and the "Fields" group.
The main difference is that this type tree has the "Methods"
group.

The type tree in this card represents the MainClass class for
which the source code and binary file are also provided
(MainClass.java and MainClass.class)

This card prepares the data to instantiate an object of the MainClass
type, set its public fields, AND ALSO invokes the methods on the
object.

The "this" value for this object is "id2". This means that after the
object of MainClass is instantiated, it will be stored to the pool
under the "id2" reference. At the time this occurs, the SubClass
object created in the first card will already reside in the pool.

The constructor used for this object has two parameters, the first 
one being int and the second one being of the SubClass type.

The first parameter receives the value 1 and there is nothing special
about it. However, the second parameter is not of a primitive type,
but of the complex class type - SubClass. It is receiving the value 
"id1".

This means, when the adapter needs to invoke the constructor to 
create the MainClass object, it will pass the value 1 for the first 
parameter, but it will pick up the "id1" object from the pool to use 
it as a value for the second parameter.

The name of the first parameter is P1_int which means: the int value
for the first constructor parameter.

The name of the second item is ref.P2_SubClass. This means a 
reference to the SubClass object value for the second constructor 
parameter.

This is an indicator that the item's value "id1" is not the real
parameter's value, but rather the reference to the value that needs 
to be retrieved from the pool.

This practically means that the object sharing is taking place in the
adapter. The same object is shared between the first and the second
card. The first card is creating the object and storing it in the
pool so that any subsequent output card can reuse it.

References are used to enable the object sharing. Java primitive
values are always passed by value to the adapter, and class type 
values are always passed by reference.

The only exception to this is the java.lang.String class, in which 
the values are also passed directly by value and not by reference.

Three fields are being set on the MainClass object.

The first one is _booleanField and it receives the boolean "true" 
value.

The second public field is _SubClassField, and like with the 
constructor,a reference value is needed to pass this value. The only 
object in the pool at the time when this public field is set is 
"id1" object. Another output card before this card could be added 
that looks exactly like the first output card, but that is creating 
another SubClass object with another reference id. Then this other 
reference id could be used instead of "id1".

The third public field is _StringField of java.lang.String Java type,
which has the text value "testing adapter"

Note that the java.lang.String is a special case in the Java Class
adapter. Although it is really a Java class, the adapter is treating
it as any other Java primitive value, such as int or byte. The value
for it must be specified directly and not through a reference.

After the object has been instantiated (Constructor) and the public
field values set on it (Fields), the last task for the adapter for 
this card is to invoke some methods on the object (Methods).

The type tree shows that five methods are being invoked in total:

 - function1
 - function2.1
 - function 2.2
 - function3
 - function4

Note that all these names represent the actual method names of the
MainClass class, except function2.1 and function2.2

This is because the function2 method in the MainClass has two forms,
the first one that accepts short[] parameter, and the second one
that accepts int parameter. They also return values of the different
Java types.

The first one returns an object of the char type and
the second one of the SubClass type.

Because these are really two different methods with the same name
(overloading) they both have to be represented in the type tree.

Because it is not possible to have two groups with the same name,
the adapter appends unique integer identifiers to the group names
to distinguish between the various methods that have the same
name.

Passing values to the methods is the same as passing values to the
constructor parameters and public fields. The only new item with
invoking methods in this example is shown in the function1.
This method does not accept any arguments. So it is represented
as a group with the #NullArgList item that is assigned NONE value.

After this card is executed, the data is prepared to be passed to
the Java Class adapter.


Output card3 - GetResultValues
------------------------------

The third card is also of Sink type, but it has a GET function
call that calls the Java Class adapter.

The data that was formatted in the previous card is passed to the
Java Class adapter as the third argument of the GET call using the
PACKAGE map function.

The return value that the adapter returns (and hence the GET call)
are the return values of SOME of the methods that were invoked.
The decision what methods to invoke and what method return values
to include in the adapter's output data is made during the type tree
generation process.

In this example, all the return values are returned except for
the method function3. This method is a void method and it was not
possible to select it in the step where it is decided what
method return values the adapter returns to the map.
All the other methods are included, but they did not have to be.

By analyzing the initiators of the method groups in the type tree,
it can be seen which methods will have their return values returned
from the adapter and which will not.

For example:
function3 has the initiator
<function3 type="void" returnValue="no">

while the function4 has the initiator
<function4 type="byte[]" returnValue="yes">

Both function3 and function4 are invoked, but only the later one
will have its value returned to the map from the adapter.

When this card is executed, the MainClass object is instantiated,
and stored in the pool under the "id2" reference. Public fields are
being set on it, and finally the specified methods are being
invoked.

The return values of the chosen methods (function1, function2.1,
function2.2 and function4) are returned back from the GET rule.


Output card4 - CallProcessMap
-----------------------------

This map passes the data retrieved in the previous card as the
input data for the first input card of the ProcessOutput map.
ProcessOutput map is invoked using the RUN function.



Map2 - procout
--------------------

The second map displays some of the values that the invoked
methods returned. In addition, it is providing the public field 
values of the MainClass object after the methods were invoked on it. 
This is represented with the "this.MainClass" group.

During the type tree generation process a decision is made whether
to include these fields or not in the data that the adapter
is returning to the map when the GET map function is called.

When the InvokeAdapter map is ran, the Result.txt file will be
generated by the output card of the ProcessOutput map.

This file has the following content:

The result from function1 is: 2
The result from function2.1 is: A
and the reference to the return value for the function2.2 is: Ref.1

This means that the method function1 returned value 2, and the
method function2.1 returned 'A'.

The method function2.2 that has the return value of SubClass type
returned all the public fields of the return value PLUS A REFERENCE
to this object. The reference was automatically generated by
the adapter and it has the Ref.1 value. All the references that
the adapter generated are in the form Ref.x, where x is the unique
integer value.

This means that users should never user the Ref.x syntax when
generating reference identifiers for the objects.

Although both the public fields and the reference are provided for
the object returned by the method function2.2 (which can be seen
by looking at the type tree in the input card of the ProcessOutput
map), only the reference is mapped to the Result.txt file,
and that is "Ref.1".



=====================================================================
                             END OF FILE
=====================================================================
