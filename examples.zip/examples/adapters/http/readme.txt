IBM WebSphere Transformation Extender 
HTTP Adapter Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of HTTP Adapter sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

File included in this example:

       http.mms  - The map source file http.mms is provided as an 
                   example map and can be modified or replaced with a 
                   map more suitable to your specific needs. 
                   The http.mms file contains the following maps:
                   httpget  - Gets the source for a Web page.
                   httpgetc - Gets cookies from a Web page.
                              Note: You must point to an actual 
                              server that has a list of user names 
                              and passwords.
                   httpgeth - Gets header information from a Web 
                              page.
                              Note: You must be able to access the 
                              Web from this server and have the 
                              appropriate security permission. 
                              Otherwise, you must point to a server 
                              that you have access to.
                  httppost  - Posts a request to a Web server and 
                              stores the response.
                              Note: You must be able to access the 
                              Web from this server and have the 
                              appropriate security permission. 
                              Otherwise, you must point to a server 
                              that you have access to and modify the 
                              POST request accordingly.
       
       http.mtt  - Type tree used with the httpgetc map.      
        
=====================================================================
2: USING THIS EXAMPLE
=====================================================================

In this example, the Header adapter command (-HDR) is used. The
httpgetc map retrieves a form that sets cookies and then submits the
form. The form includes typical fields of forms found on Web sites
and uses cookies to maintain login information.

How to run the example:

    1)  Open http.mms in the Map Designer.

    2)  Modify the URL command on each card as needed. Be sure to
        point to a Web server or to a server for which you have the
        appropriate security permissions.

    3)  Build and run all maps.

    4)  View the output file results.


=====================================================================
                             END OF FILE
=====================================================================
