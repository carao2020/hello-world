/* 
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

#include "dtxpi.h"

#define CHECK_ERR(rc) if(MPIRC_FAILED(rc)) 	{ printf("Last error is: %s\n",mpiErrorGetText(rc)); return -1;}

int main()
{
	const char  	*szMsg;
	int		iRC;
	MPIRC           rc;
	HMPIMAP 	hMap;
	/* this defines what resource configuration file to use */
	char *szResourceAliasFile=NULL;

	rc = mpiInitAPI(szResourceAliasFile); 
	CHECK_ERR(rc);


	rc = mpiMapLoadFile (&hMap, "test1.mmc");
	CHECK_ERR(rc);
	
	rc = mpiMapRun (hMap);
	CHECK_ERR(rc);
	
	rc = mpiPropertyGetText (hMap, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, NULL);
	CHECK_ERR(rc);
	rc = mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
	CHECK_ERR(rc);
	printf("Map status: %s (%d)\n", szMsg, iRC);
	
	rc = mpiMapUnload (hMap);
	CHECK_ERR(rc);
	
	rc = mpiTermAPI();
	CHECK_ERR(rc);
	return 0;
}
