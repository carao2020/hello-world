IBM WebSphere Transformation Extender 
COBOL Copybook Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage input for the COBOL Copybook 
Importer. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example

=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    readme.txt     - this readme file

    unwrappd.cpy   - an unwrapped copybook file

    wrapped.cpy    - a wrapped copybook file


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The two copybook files in the copybook folder are examples of an
unwrapped copybook file and a wrapped copybook file. They are defined 
in the COBOL Copybook Importer topic of the Type Tree Importers 
documentation.


=====================================================================
                             END OF FILE
=====================================================================
