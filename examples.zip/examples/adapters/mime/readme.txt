IBM WebSphere Transformation Extender 
MIME Adapter Example Readme


� Copyright International Business Machines Corporation 2006, 2009, 2015.
All Rights Reserved.


This example demonstrates the usage of the MIME Adapter sample files. 

=====================================================================
CONTENTS
=====================================================================

    1.  Example File
    2.  Using This Example


=====================================================================
1: EXAMPLE FILE
=====================================================================

There is one example contained in this directory:

    emailatt.mms    - Contains examples to demonstrate using the MIME 
                      adapter to handle multiple attachments in MIME 
                      data.

=====================================================================
2: USING THIS EXAMPLE
=====================================================================

The example maps show how to use the MIME adapter to build MIME
messages and decode MIME messages.


How to run the example:

EMAILATT.MMS FILE
-----------------

The purpose of the maps in this map source file is to demonstrate how
to send multiple attachments in an e-mail, and how to decode incoming
e-mail to extract any attachments which may be provided.

SendMultipleAttachments
-----------------------

This map builds a MIME multi-part message using the MIME adapter, and
then uses the e-mail adapter with the -raw command to send the MIME
data to the e-mail recipient.

1. In output card #1, change the rule of BuildMIME:Message Header:To
   Field to specify a valid e-mail address to whom you wish to send 
   the e-mail.

2. In output card #3, edit the card settings and change the host in
   the adapter command line to a valid e-mail host.

3. Build SendMultipleAttachments

4. Execute the map. An e-mail will be sent to the specified
   destination. The e-mail will contain 2 JPEG images and a simple 
   text message.

SimulateEmailReceipt
--------------------

This map takes a MIME input (which is captured from a real MIME
message) and uses the MIME adapter to parse it and extract the
attachments which are then written to files as JPEG images.

1. Build ParseMIMEData map

2. Build SimulateEmailReceipt

3. Execute the SimulateEmailReceipt map. The map will execute the
   MIME adapter to return data that corresponds to the type tree
   mime.mtt. The map ParseMIMEData is invoked through the RUN 
   function to extract the attachment data and write it to the 
   filenames specified in the MIME headers.

=====================================================================
                             END OF FILE
=====================================================================
