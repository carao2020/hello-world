/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example7
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example7 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }

            // Initialize the API

            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));


            // Load a map
            String mapPath = makeMapPath(args[2], "test7.mmc");
            IMMap map = factory.loadMapFile(mapPath);

            // Get an adapter object
            IMCard card = map.getInputCardObject(1);
            IMAdapter adapter = card.getAdapter();

            // Get the adapter command line in raw format
            System.out.println( "The adapter command line is....\n" +
                                adapter.getTextProperty( MConstants.MPIP_ADAPTER_COMMANDLINE, 0 ) +
                                "\n");

            // Get it in XML format
            int[] properties = new int[]{ MConstants.MPIP_ADAPTER_COMMANDLINE};
            String xml = adapter.getPropertiesXML( properties, 0, properties.length );
            System.out.println("The adapter command line in XML is....\n" + xml + "\n");

            // Modify the command line using XML
            xml = "<Adapter>" +
                  "<CommandLine id=\"" + MConstants.MPIP_ADAPTER_COMMANDLINE + "\" type=\"text\">" +
                  "input2.txt" +
                  "</CommandLine>" +
                  "</Adapter>";
            adapter.setPropertiesXML( xml );

            // Print all of the Adapter's properties in XML format
            String xmlProps = adapter.getAllPropertiesXML(false);
            System.out.println("The modified, complete set of adapter properties is....\n" + xmlProps + "\n");

            // Clean up
            map.unload();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}
