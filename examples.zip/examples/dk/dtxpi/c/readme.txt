IBM WebSphere Transformation Extender 
Programming Interface C Examples Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


These examples demonstrate the usage of IBM WebSphere Transformation 
Extender Programming Interface C examples sample files.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example
    3.  Example of an IBM WebSphere Transformation Extender Custom 
        Adapter


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in these examples:

example1.c - Simplest Case of Running a Map

example2.c - Running Multiple Instances of a Map in Parallel

example3.c - Overriding a Card in a Map and CodePageFallback property

example4.c - Using a User-provided Status Method

example5.c - Using Streams to Override Inputs and Outputs

example6.c - Loading a map from a byte array

example7.c - Getting and setting Properties

    Note: example3.c is written to be used with the GZIP adapter
          which is not available on all platforms. If necessary, 
          override the GZIP adapter type in this example with a 
          substitute adapter to correctly run the example.

    Note: example2.c, example3.c and example7.c are not available
          on the NonStop ZLE platform.


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example contains sample files to be used with the IBM
DTX Programming Interface C examples.

How to build and run the examples:

1. Build the executables:

   For Windows 32 bits:

       From a DOS command prompt, build the examples by executing:

          nmake /f win32.mk

   For Windows 64 bits:

       From a DOS command prompt, build the examples by executing:

          nmake /f win64.mk

   For Solaris:

       From a command prompt, build the examples by executing:

          make -f sun.mk

   For HP-UX (Itanium):

       From a command prompt, build the examples by executing:

          make -f hp11i.mk

   For AIX:

       From a command prompt, build the examples by executing:

          make -f aix.mk

   For z/OS

       From a command prompt, build the examples by executing:

          make -f os390.mak

2. Either copy the executables to the IBM WebSphere Transformation 
   Extender directory or ensure that the DTX directory is in the 
   path.

3. In the IBM WebSphere Transformation Extender Designer, open 
   dtxpiex.mms and build the following maps:

   - test1.mmc
   - test2.mmc
   - test3.mmc
   - test4.mmc
   - test5.mmc
   - test6.mmc
   - test7.mmc

   Ensure that you build them for the specific platform on which
   you are running them.

4. Place the compiled map files in the same directory as the example
   program executables.

5. Copy input.txt, input.gz and input2.txt to the same directory.

6. Execute the examples.


=====================================================================
3: EXAMPLE OF AN IBM WebSphere Transformation Extender CUSTOM ADAPTER
=====================================================================

The filesamp.c file contains code for a simple file adapter. Its
purpose is to show the structures and code required to implement an
IBM WebSphere Transformation Extender custom adapter and how 
properties are set and obtained.

The concept of a connection is not totally applicable for files. In
most adapters, there is a very obvious concept (for example, a
database connection or the handle to a message queue). In this file
example, a file handle is being treated as a connection.

The adapter can be built using Microsoft Developer Studio and the
provided makefile. The adapter can also be built as a shared library
for Unix platforms. However, no makefile is currently provided.

To build on Windows, issue the following command from a
Command Prompt:

   nmake /f filesamp.mak

Once built, copy the filesamp.dll to the WebSphere Transformation 
Extender directory.

To register the adapter, copy the following line to the adapters.xml
file under the UserAdapters section:

   <UserAdapter name="Sample File" alias="SFILE" id="201"
   library="filesamp" vendor="IBM"/>

To use the adapter, specify the full path of the filename to read
from(input card) or to write to (output card) in the adapter command
line.

When the adapter is used in Launcher scenarios, the filename can
contain wildcards.


=====================================================================
                             END OF FILE
=====================================================================
