/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.io.FileInputStream;

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example6
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example6 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load a local map file
            String mapPath = makeMapPath(args[2], "test6.mmc");
            FileInputStream fis = new FileInputStream(mapPath);
            byte[] mapData = new byte[fis.available()];
            fis.read(mapData);
            fis.close();

            // Create a map
            IMMap map = factory.loadMapMemory("test6", null, mapData);

            // Override the input card so that a local file
            // containing input data can be sent to the remote server
            IMCard card = map.getInputCardObject(1);
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Read the local data file
            fis = new FileInputStream("input.txt");
            byte[] inputData = new byte[fis.available()];
            fis.read(inputData);
            fis.close();

            // Pass it to the server via a stream
            IMAdapter adapter = card.getAdapter();
            IMStream stream = adapter.getOutputStream();
            stream.write(inputData, 0, inputData.length);

            // Get the adapter object handle for output card #1
            card = map.getOutputCardObject(1);

            // Override the adapter in output card #1 to be a stream
            card.overrideAdapter(null, MConstants.MPI_ADAPTYPE_STREAM);

            // Run the map
            map.run();

            // Check the return status
            int iRC = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);
            String szMsg = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            System.out.println("Map status: " + szMsg + " (" + iRC + ")");

            // Get the adapter object handle for output card #1
            adapter = card.getAdapter();
            stream = adapter.getInputStream();

            // Get the data in pieces from the stream
            stream.seek(0, MConstants.MPI_SEEK_SET);
            while ( true )
            {
                boolean bIsEnd = stream.isEnd();

                // Clean and Break
                if ( bIsEnd )
                {
                    stream.setSize(0);
                    break;
                }

                byte[] page = stream.readPage();
                System.out.println(new String(page));
            }

            // Clean up
            map.unload();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }
    }
}
