/*
 * Copyright (C) 2006 IBM Corporation.  All rights reserved.
 *
 * This software is the property of IBM Corporation and its
 * licensors and contains their confidential trade secrets.  Use, examination,
 * copying, transfer and disclosure to others, in whole or in part, are
 * prohibited except with the express prior written consent of
 * IBM Corporation.
 *
 */

import java.rmi.*;
import com.ibm.websphere.dtx.dtxpi.MConstants;
import com.ibm.websphere.dtx.dtxpi.rmi.*;

public class Example3
{
    public static String makeMapPath(String mapDir, String name)
    {
        StringBuffer mapName = new StringBuffer(mapDir);
        if (mapDir.indexOf(":\\") != -1)
        {
            mapName.append("\\");
        }
        else
        {
            mapName.append("/");
        }
        mapName.append(name);
        return mapName.toString();
    }

    public static void main(String[] args)
    {
        try
        {
            if ( args == null || args.length != 3 )
            {
                System.err.println("Unable to run the example. Format: java Example3 " +
                                   "<host_name> <port_number> <map_dir>");
                System.exit(-1);
            }


            IMFactory factory = MRMIAPI.getFactory(args[0], Integer.parseInt(args[1]));

            // Load the Map
            String mapPath = makeMapPath(args[2], "test3.mmc");
            IMMap map = factory.loadMapFile(mapPath);

            // Turn on burst and summary execution audit on the map instance
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_SWITCH, 0, MConstants.MPI_SWITCH_ON);
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_BURST_EXECUTION, 0, MConstants.MPI_SWITCH_ON);
            map.setIntegerProperty(MConstants.MPIP_MAP_AUDIT_SUMMARY_EXECUTION, 0, MConstants.MPI_SWITCH_ON);

            // Get the adapter object handle
            IMCard card = map.getInputCardObject(1);
            card.overrideAdapter("GZIP", 0);

            // set a command line for the adapter
            IMAdapter adapter = card.getAdapter();
            adapter.setTextProperty(MConstants.MPIP_ADAPTER_COMMANDLINE, 0, "-FILE input.gz");

            // Run the map
            map.run();
            String responseMessage = map.getTextProperty(MConstants.MPIP_OBJECT_ERROR_MSG, 0);
            int resuleCode = map.getIntegerProperty(MConstants.MPIP_OBJECT_ERROR_CODE, 0);

            System.out.println("Map Status: " + responseMessage + " " + resuleCode);

            // Unload the Map
            map.unload();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}


