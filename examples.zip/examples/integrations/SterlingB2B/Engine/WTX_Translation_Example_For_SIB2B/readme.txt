IBM WebSphere Transformation Extender Translation Service Example


� Copyright IBM Corporation 2011. All Rights Reserved.


=====================================================================
CONTENTS
=====================================================================

   1.  Overview
   2.  What this example contains
   3.  Running this example from IBM WebSphere Transformation Extender
   4.  Running this example from Sterling B2B Integrator
   5.  Expected results
   6.  Other Notes

=====================================================================
1. OVERVIEW
=====================================================================

This example provides an IBM� WebSphere� Transformation Extender 
translation map that can be used within the Translation service 
of IBM Sterling B2B Integrator (SI).

The example map transforms a fixed-length, positional-format file
to a delimited-format file. The output format is a comma-separated
value (CSV) file.

The input for the translation example should look like the following:


Field			Min		Max
-------------------------------------------
TransactionID    4       4
TransactionCode  2       2
SellerID         6       6
BuyerID          6       6
PONumber        12      12
SellerPartNumber 6       6
Description     10      10
Cost             1      12

For example:
666606666666666666163456789000SENDR6DESCRIPT0132.78       
777705555555555555153456789000SENDR7DESCRIPT0154.78       
888803333333333333133456789000SENDR8DESCRIPT0121.22       
999902222222222222103456789000SENDR9DESCRIPT0120.33       
000001111111111111113456789000SENDR0DESCRIPT0178.32       
.
.

DUPLICATE PURCHASE ORDER HANDLING:
----------------------------------

The example translation map requires all of the incoming purchase order 
records to contain unique Purchase Order Numbers (PONumber field). 
If the incoming file contains duplicate Purchase Order Numbers, or 
if the file contains Purchase Order Numbers which were processed previously,
the translation flags the duplicate records.

Two files are included: one has duplicate purchase order numbers and 
the other has unique purchase order numbers. Refer to section 2 for 
more details.



=====================================================================
2. WHAT THIS EXAMPLE CONTAINS
=====================================================================

In addition to this readme file, this example contains the following
directories and files:

Maps
---
The maps directory contains the following file:

- SampleTranslation.mms - The map that translates the positional-format
  data to CSV-format data.

Trees
-----
The trees directory contains the following files:

- FixedRecord.MTT - Metadata that describes the format of the
  positional-format file.
			
- CSVRecord.MTT - Metadata that describes the format of
  the CSV output file. 

Data
----
The data directory contains the following files:

- InputFileWithNoDuplicate.txt - The input file to the example 
  translation map. This file contains Purchase Order records in the 
  positional format. Individual records in this input file contain 
  unique purchase orders. 

- InputFileWithDuplicates.txt - The structure of this file is the same
  as InputFileWithNoDuplicate.txt.  This file contains one duplicate 
  purchase order.

- SampleTranslationOutput.txt - The expected output of the example 
  translation map when it transforms the InputFileWithNoDuplicate.txt  
  input file for the first time.


Import
----
The import directory contains the following file:

- ExportTranslationSIObjects.xml - This is the Sterling B2B Integrator 
  resource file, which must be imported into the system. This file 
  contain the following artifacts:

  Code List : WTX
  Business Process : Translation_bp

  Section 4 of this readme file explains how to import the resource
  file.


=====================================================================
3. RUNNING THIS EXAMPLE FROM IBM WEBSPHERE TRANSFORMATION EXTENDER
=====================================================================

This example map calls the Sterling adapter to write values to
Sterling B2B Integrator tables.  The map fails if you try to run 
it outside of Sterling B2B Integrator. However, you can test the map 
from WTX Design Studio by using the "Run on Sterling B2B Integrator" 
option.

1. Configure the WTX Design Studio preferences to connect to the
Sterling B2B Integrator server.  See the Other Notes section of this 
readme for more information.

2. Open the SampleTranslation.mms source map in WTX Design Studio.

3. Right-click on the SampleTranslation source map, choose
"Run on Sterling B2B Integrator", and enter the id/password if
prompted.  Processing completes successfully.

4. The map creates the following file:
- The SampleTranslationOutput.txt file in the data directory.
This file contains the output from the map.  

Note: Refer to the Other Notes section of this readme file 
for details about how to handle duplicate records when this map 
and input file have run previously.


=====================================================================
4. RUNNING THIS EXAMPLE FROM STERLING B2B INTEGRATOR
=====================================================================

Deploying the map to Sterling B2B Integrator
--------------------------------------------

1. You must configure the WTX Design Studio preferences to connect to
to the Sterling B2B Integrator server. See the Other Notes section of 
this readme file for more information.

2. Open the SampleTranslation.mms source map in WTX Design Studio.

3. Right-click on the SampleTranslation source map. Choose
"Deploy to Sterling B2B Integrator" and enter the id/password if
prompted.  Processing completes successfully.


Alternate Method to check the map into Sterling B2B Integrator
--------------------------------------------------------------

1. Compile the source maps for the platform on which Sterling 
Integrator is installed. 

2. In the Sterling B2B Integrator dashboard, go to 
Deployment > Maps > Check in new Map from Map Editor.


Importing the Sterling B2B Integrator objects
---------------------------------------------

The ExportTranslationSIObjects.xml contains an exported Code List
and the Business Process that runs the example map. To import these 
files into your Sterling B2B Integrator system:

1. Login to the Sterling B2B Integrator Dashboard.

2. In the Administration Menu, expand the Deployment and
Resource Manager sections and select the Import/Export option.

3. Select the Import Resources option.

4. Select ExportTranslationSIObjects.xml for the file name. Enter
"password" as the passphrase  and check the Import All Resources box.
You can use the default settings for the remaining options.  The
Import should complete successfully.

5. From the Trading Partner page, search for the "WTX" Code List 
to see the newly imported Code List.


Running the map on Sterling B2B Integrator
------------------------------------------

The Translation_bp example business process calls the Translation 
service that runs the map.

1. Login to the Sterling B2B Integrator Dashboard.

2. From the Administration Menu, go to the Business Process Manager
page.

3. Search for the Translation_bp business process.

4. Select the "execution manager" for the Translation_bp business
process, then select the "execute" option.

5. Select either the InputFileWithNoDuplicate.txt or the 
InputFileWithDuplicates.txt files as input.  Both of these files are
in the data directory.  See the "Expected Results" section below
for the expected output for each of these input files.

6. The Execute Business Process results should show a Status of
"Success" for all steps in the business process.  You can
see more details by viewing the Document and Instance Data for the
Translation service.
- The Document information is the output of the translation service.
- The Instance Data information is the "process data" values that the
service set, including the WTXPONumber values that the map set.

Note: Refer to the Other Notes section of this readme file 
for details about how to handle duplicate records when this map 
and input file have run previously.


=====================================================================
5. EXPECTED RESULTS
=====================================================================

- When the input file is InputFileWithNoDuplicate.txt, the example 
translation map generates a CSV-format file that contains
the translated Purchase Order records. This file generates 12 purchase 
order records. The generated output should resemble the 
SampleTranslationOutput.txt file, which is included in the data folder. 

- When the input file is InputFileWithDuplicates.txt, the example 
translation map generates a CSV-format file that contains the 
translated Purchase Order records. The first time that the map 
processes the InputFileWithDuplicates.txt file, it generates  
12 purchase orders. One record is flagged as a DUPLICATE record. 
This record should look like:

5555,07,777777,777777,183456789000,UNIV01,DESCRIPT01,54.22,DUPLICATE

Note: If this example has been run previously, then the purchase order
number values may already exist in the transaction register table.
If this is the case, all records might be flagged as DUPLICATE records.
Refer to the Other Notes section of this readme file for details on
the handling of duplicate records, and how to delete the values from
the transaction register table.


=====================================================================
6.  OTHER NOTES
=====================================================================

STERLING B2B INTEGRATOR UI RESOURCE PERMISSIONS:
------------------------------------------------

Many of the actions that use the Sterling B2B Integrator dashboard 
require specific permission settings. See the description of the 
permissions needed to access UI resources in the 
Sterling B2B Integrator Security documentation.


EXTERNAL DATA LOOKUP:
--------------------

This example uses GET and PUT calls to the "Sterling" adapter in order
to get and set certain values that are maintained in the Sterling
B2B Integrator database tables.  These calls can be specified either
in type tree component rules, or in map rules.  Whether you use
component rules in the type tree depends on various factors, including:
- How you want to handle errors 
- Whether you also use the type tree for maps that run outside of the
  Sterling B2B Integrator environment.
- Whether you reuse the type tree for multiple maps that run inside
  the Sterling B2B Integrator environment.
- Personal preference

When you run the translation example, a component rule writes the 
Purchase Order Numbers into the Sterling B2B Integrator Correlation
Set table.  This component rule is on the PONumber Field item in the
FixedRecord group of the FixedRecord.MTT type tree.  The component
rule will FAIL the map if there is an error on the PUT function,
so this type tree cannot be used for maps that run outside of the
Sterling B2B Integrator environment.

You can use the Sterling Integrator UI to access the values that were
written to the Correlation Set table by selecting 
Business Process > Monitor > Advanced Search  > Correlation.
Use WTXPONumber as the Name and any processed Purchase Order Number 
as the value.

The service also sets Purchase Order Numbers in the Process Data. 
Map rules are used to set the Process Data values.

To view the process data, view the Instance Data as described in 
step 5 in the 'Running the map on Sterling B2B Integrator' section
of this readme file. 
 
The Process Data resembles the following:

<WTXPONumber>123456789000</WTXPONumber>
<WTXPONumber>143456789000</WTXPONumber>
<WTXPONumber>193456789000</WTXPONumber>
<WTXPONumber>183456789000</WTXPONumber>
.
.

The example translation map also uses map rules to perform an external
data lookup of the SellerPartNumber data, and maps it to a Universal 
Part Number field. The map uses the WTX Code List in the Export file
to translate the SellerPartNumber data into Universal Part Numbers.
If the lookup fails, the map sets the Universal Part Number to the 
value "******".

For example, a SellerPartNumber (SENDR1) in the following record:

666606666666666666163456789000SENDR1DESCRIPT0132.78       
			                  ------
is translated into a UniversalPartNumber (UNIV01) using the WTX 
Code List:

6666,06,666666,666666,163456789000,UNIV01,DESCRIPT01,32.78
				                   ------
 
You can enter or view the values for the Code List by using
the Sterling Integrator Code List user interface.

To add a code to the Code List:

1. Log into Sterling B2B Integrator and go to Trading Partner > Code Lists.

2. In the Search screen, search for the code list with name 'WTX'.

3. Click on Source Manager and click edit for the default version. 

4. Navigate to the codes screen and select 'add new code'.

5. Enter the value of the SellerPartNumber in the Sender Code field.

6. Enter the value of UniversalPartNumber in the Text1 field.

7. Enter values of your choice in the Receiver Code and Description
   fields.  These fields are required, but are not used by this 
   example.
   
8. Click Save to save the new code.

9. Click Next and set the new code list version as the default version.

10. Click Next again and click Finish to save the Code List.


To test the new code that you added to the Code List:

1. Create a copy of one of the input files in the data directory.

2. Edit the new file and change the value of one of the SellerPartNumber
   values to the new Sender Code that you added.
   
3. Run the example again on Sterling B2B Integrator, using the new
   file as input.

4. The new UniversalPartNumber that you entered in the Text1 field
   appears in the output data. 


CONFIGURING THE CONNECTION TO STERLING B2B INTEGRATOR:
------------------------------------------------------

Sterling B2B Integrator-specific options are available in 
Design Studio only when WebSphere Transformation Extender for 
Integration Servers is installed.

For instructions about how to configure these options, see the
WebSphere Transformation Extender Map Designer documentation.


THE EXHAUST_INPUT PARAMETER OF THE BUSINESS PROCESS:
----------------------------------------------------

The example business process sets the exhaust_input parameter to YES.
The Translation service does not support exhaust_input=NO when using
WebSphere Transformation Extender maps.

If you want to simulate the exhaust_input=NO capabilities of the 
Sterling B2B Integrator maps, you can define the input type tree on
the WTX map to process only the first block of input data and ignore
the remaining input data.


HANDLING DUPLICATE RECORDS:
------------------------------

The map uses external data harness calls to invoke the Sterling B2B Integrator 
native duplicate-check logic. When the Translation service successfully processes
a record, the service enters the Purchase Order Number of the record in the 
transaction register table. When another record has the same Purchase Order Number 
value, the Translation service flags the record as DUPLICATE and does not create an 
entry in the transaction register table. To use a file that the service already 
processed, you delete the records from transaction register table.

To use the SQL Manager to delete the records from the transaction register table:

1. Login into Sterling B2B Integrator and go to 
Operations > System >  Support Tools > SQL Manager.

2. In the command field, enter the following script and click Execute.
"select * from TRANSACT_REGISTER where FIELD5='WTXEXAMPLE'"

The screen displays the list of processed Purchase Order records.

3. In the command box, enter the following script and click Execute.
"delete from TRANSACT_REGISTER where FIELD5='WTXEXAMPLE'"
 
4. Click OK in the alert box.

If all of the records in the input file were processed already, then
all of the output records are flagged as a DUPLICATE.


SPECIAL MAP AND TYPE TREE SETTINGS
----------------------------------

Some of the map and type tree settings used in this example are
particularly important for running within the Translation service:

- In the FixedRecord type tree, the RecordFile group specifies the
Restart flag on the FixedRecord component.  The Restart flag allows 
the WTX map to continue to process the remaining records after it 
finds an invalid record in the input file.

- In the map settings, the MapAudit Switch is set to ON, the 
BurstdAudit and SummaryAudit settings are set to Always, and the 
AuditLocation is set to Memory.  In addition, the Data Audit Settings
for the map are set as follows:
  Audit      FixedRecord:RecordFile
  Track      Occurrence
  Details    Occurrence
  Item Data  Occurrence
With these audit settings, the Translation service can recognize 
errors that the WTX map found.
 
