#!/bin/sh
# 
# Copyright (C) 2012 IBM Corporation.  All rights reserved.
#
# This software is the property of IBM Corporation and its
# licensors and contains their confidential trade secrets.  Use, examination,
# copying, transfer and disclosure to others, in whole or in part, are
# prohibited except with the express prior written consent of
# IBM Corporation.
#

# **************************************************************************
# The following variables must be set before running the file:
#
# JDKHOME			J2SE1.6.0 JDK Home Directory
# **************************************************************************

JDKHOME=$JAVA_HOME
JAVACCMD=$JDKHOME/bin/javac
JAVAJCMD=$JDKHOME/bin/jar

echo Compiling the examples
$JAVACCMD -g -classpath .:../../libs/dtxpi.jar *.java
$JAVAJCMD -cvf TestJExit.jar *.class

