IBM WebSphere Transformation Extender 
Sink Map Example Readme


(c) Copyright International Business Machines Corporation 2006-2008.
All Rights Reserved.


This example demonstrates the usage of the Sink Map.

=====================================================================
CONTENTS
=====================================================================

    1.  Example Files
    2.  Using This Example


=====================================================================
1: EXAMPLE FILES
=====================================================================

Files included in this example:

    allemps.txt
    employee.txt
    readme.txt  (this readme file)
    sinkmap.mms
    sinkmap.mtt


=====================================================================
2: USING THIS EXAMPLE
=====================================================================

This example will use the the sinkmap to select an employee's 
timesheet out of the allemps.txt file, based on which employee name 
is located in the employee.txt file. It will then return the 
employee's name and the total number of hours that employee worked 
for the week. 

The total number of hours is determined by passing the week to the 
first output card (week), which is then utilized by the second 
output card (ttlhours), which then passes this information to the 
third output card (emp_hours) for output. The first two cards are 
set to SINK because the information is not needed after calculating
the employee's total hours worked.

How to run the example:

1)  Using the Map Designer, open sinkmap.mms.  
    There are three output cards:
   a)  week - This card is used to figure out which timesheet needs
              processing.
   b)  ttlhours - This card calculates the total hours worked based
                  on the information determined in the first output 
                  card (week)
   c)  emp_hours - This card is used to place the processed 
                   information into a text file (emphours).

2)  Build and Run sinkmap.
    The following outbound data is generated:
   a)  Ouput Card 1 (week) - none (the card is set to SINK)
   b)  Ouput Card 2 (ttlhours) - none (the card is set to SINK)
   c)  Ouput Card 3 (emp_hours) - "Work A.     |Holic        |90.45"

3)  For additional practice, you can look up other names in the
    allemps.txt file and place them in the employee.txt file.


=====================================================================
                             END OF FILE
=====================================================================
