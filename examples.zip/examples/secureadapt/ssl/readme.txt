IBM Transformation Extender (ITX) Secure Adapter SSL Example Readme

(c) Copyright International Business Machines Corporation 2015.
All Rights Reserved.


This example demonstrates how to use the m4gskssl module, which complies
with NIST standards and provides advanced SSL/TLS security protocols.

This example also includes instructions for defining and importing X.509
certificates that can be used for running new and existing maps that require
SSL-based FTP and HTTP communications.

==============================================================================
CONTENTS
==============================================================================

    1. Example Files
    2. Configure GSKit Installation Path
    3. Define a Certificate Keystore
    4. Import External Certificates
    5. Define New Certificates
    6. (Optional) Miscellaneous Certificate Commands
    7. ITX Configuration
    8. ITX Execution

==============================================================================
1. Example Files
==============================================================================

Files included in this example:

    wtx_ssl.mms - map source file
    Test.mtt    - type tree
    test.txt    - sample data
    readme.txt  - this readme file

==============================================================================
2. Configure GSKit Installation Path
==============================================================================

Before running GSKit-specific commands, as contained in steps 3-6, the "setup"
script on UNIX or the "dtxcommon.bat" script on Windows needs to be run to set
the platform path to the appropriate GSKit installation.

In order for ITX to use the advanced SSL capabilities of the m4gskssl module,
the IBM GSKit drivers must be located on the appropriate library path for your
platform.  This step is automatically done via the UNIX and Windows setup
scripts, thereby enabling the ITX design tools, command server and launcher to
be automatically configured for SSL/TLS communications.

1)  Make sure the GSKit "bin" sub-directory is on the executable path for your
    platform.
    
2)  Make sure the GSKit "lib64" sub-directory is on the library path for your
    platform.
    
3)  Run the GSKit version command to confirm that the installed version of IBM
    GSKit is at an appropriate version, such as 8.0.50.52 or above.
    
    For example:
    gsk8ver_64
         
==============================================================================
3. Define a new Certificate Keystore
==============================================================================

One of the key aspects of SSL-based communications is the authentication of a
server's identity.  This is done by examining the server's certificate and
checking whether it was issued by a trusted certificate authority (CA).  

All trusted CA certificates are stored in a secure repository, which is called
the keystore.  The keystore also stores any personal certificates that were 
issued by a CA and signed by the CA's private key.

The ITX keystore must be defined before the m4gskssl module will initiate an
SSL-based connection.  A default repository is already defined, but may be
re-generated in this step.  The default password of "changeit" can be changed
in this step or as documented in Step 6 for an existing keystore.

1)  Create a PKCS12 database to store the SSL/TLS certificates.  The name of
    the default certificate database is wtx_keys.p12.

    For example:
    gsk8capicmd.exe -keydb -create -db wtx_keys.p12 -pw changeit -type pkcs12 -populate -stash

2)  Confirm that there is a pre-installed list of certificate authorities that
    will be used when validating certificates.  The ITX SSL-based modules
    will validate certificates once the "authentication" setting of the dtx.ini
    file is enabled.  Certificate validation will only succeed if the peer
    certificate was issued by a certificate authority that is in the 
    certificate store.
    
    For example:
    gsk8capicmd -cert -list -db wtx_keys.p12 -stashed -type pkcs12
    
3)  Consult the GSKit CapiCmd User Guide for detailed descriptions on the
    gsk8capicmd options.  This documentation is located under the ITX 
    installation sub-directory, "GSKit", with the file name,
    GSK_CapiCmd_UserGuide.pdf.

==============================================================================
4. Import External Certificates
==============================================================================

Any certificates that are defined on the HTTP/FTP adapter command line must be
imported into the certificate store in a PKCS12 format.

1)  Convert the certificate into a PKCS12 format.  The PEM-based format was 
    previously used as the default format for ITX-based SSL communications.  
    
    One way to convert a PEM-based certificate to a PKCS12 format is to use the
    "openssl" command, as provided by the OpenSSL Project (www.openssl.org).
     
    Example 1 - Import a personal certificate:                                                                 
    openssl pkcs12 -export -in mycert.pem -inkey mycert_pkey.pem -name "my_cert" -out mycert.p12
    
    The above openssl command presumes that your public certificate is in 
    mycert.pem and your private key is in mycert_pkey.pem.  When prompted, 
    make sure to enter a password.
    
    Example 2 - Import a 3rd party certificate authority:                                                                 
    openssl pkcs12 -export -in ftpserverca.pem -caname "ftp_server_ca" -out ftpserverca.p12 -nokeys
    
    The above openssl command presumes that the FTP Server's CA certificate is
    in ftpserverca.pem.  This import would be required if the "authentication"
    setting in the dtx.ini file is enabled.  When prompted, make sure to enter
    a password.

2)  Import the certificate into the certificate store.

    Example 1:                                                                 
    gsk8capicmd -cert -import -file mycert.p12 -type pkcs12 -target wtx_keys.p12 -target_pw changeit

    When prompted, use the password that was entered in the prior step.
    
    Example 2:                                                                 
    gsk8capicmd -cert -import -file ftpserverca.p12 -type pkcs12 -target wtx_keys.p12 -target_pw changeit

    When prompted, use the password that was entered in the prior step.
    

3)  Confirm that the new certificate(s) are installed.

    For example:
    gsk8capicmd -cert -list -db wtx_keys.p12 -stashed -type pkcs12

4)  Validate the new certificate(s).

    For example:
    gsk8capicmd -cert -validate -db wtx_keys.p12 -stashed -type pkcs12 -label "my_cert"
    gsk8capicmd -cert -validate -db wtx_keys.p12 -stashed -type pkcs12 -label "ftp_server_ca"

==============================================================================
5. Define New Certificates
==============================================================================

The ITX SSL subsystem now enables new certificates to be defined and signed by
known certificate authorities.  The example below defines a self-signed
certificate authority that can be used to sign the newly defined personal
certificate.

1) Define a self-signed certificate that will serve as a certificate authority.
   The certificate is labelled "my_ca".

   gsk8capicmd -cert -create -db wtx_keys.p12 -stashed -type pkcs12 -label "my_ca"  -size 2048 -x509version 3 -ca true -expire 1825 -sigalg SHA512WithRSA -dn CN=localhost,O=yourcompanyname,OU=yourdivision,L=Boca,ST=FL,C=US
   
2) Define new certificates for use by the ITX Adapters.
   
   Example 1 - Certificate Reqest for HTTP/FTP Adapter
   gsk8capicmd -certreq -create -db wtx_keys.p12 -stashed -type pkcs12 -label "my_client" -target my_client_req.arm -size 2048 -sigalg SHA512WithRSA -dn CN=ITX_HOST_NAME,O=mycompanyname,OU=mydivision1,L=Boca,ST=FL,C=US
   
   Example 2 - Certificate Reqest for external HTTP/FTP Server
   gsk8capicmd -certreq -create -db wtx_keys.p12 -stashed -type pkcs12 -label "my_server" -target my_server_req.arm -size 2048 -sigalg SHA512WithRSA -dn CN=ITX_LA_HOST_NAME,O=mycompanyname,OU=mydivision2,L=Boca,ST=FL,C=US

3) Sign the certificate request

   Example 1 - Sign the certificate request for the HTTP/FTP client certificate
   gsk8capicmd -cert -sign -db wtx_keys.p12 -stashed -type pkcs12 -label "my_ca" -target my_client.cer -file my_client_req.arm -sigalg SHA512WithRSA -expire 1825 -sernum 1
   
   Example 2 - Sign the certificate request for the external HTTP/FTP Server
   gsk8capicmd -cert -sign -db wtx_keys.p12 -stashed -type pkcs12 -label "my_ca" -target my_server.cer -file my_server_req.arm -sigalg SHA512WithRSA -expire 1825 -sernum 2
   
4) Import the new certificates

   Example 1:
   gsk8capicmd -cert -receive -file my_client.cer  -db wtx_keys.p12 -stashed -type pkcs12
   
   Example 2:
   gsk8capicmd -cert -receive -file my_server.cer  -db wtx_keys.p12 -stashed -type pkcs12
   
5) Validate the certificates

   For example:
   gsk8capicmd -cert -validate -db wtx_keys.p12 -stashed -type pkcs12 -label "my_ca" 
   gsk8capicmd -cert -validate -db wtx_keys.p12 -stashed -type pkcs12 -label "my_client" 
   gsk8capicmd -cert -validate -db wtx_keys.p12 -stashed -type pkcs12 -label "my_server" 

==============================================================================
6. (Optional) Miscellaneous Certificate Commands
==============================================================================

1) List certificate details

   For example:
   gsk8capicmd -cert -details -db wtx_keys.p12 -stashed -type pkcs12 -label "my_ca"

2) Delete unused certificate

   For example:
   gsk8capicmd -cert -delete -db wtx_keys.p12 -stashed -type pkcs12 -label "unused_ca"

3) Change the password of the certificate store

   For example:
   gsk8capicmd -keydb -changepw -db wtx_keys.p12 -type pkcs12 -pw changeit -new_pw mysecurepass -stash

4) Rename a certificate label.

   For example:
   gsk8capicmd -cert -rename -db wtx_keys.p12 -type pkcs12 -stashed -label "my_cert" -new_label "c:\mycert.pem"
   
   The above would enable any existing map that used the adapter command line
   option, "-CERT c:\mycert.pem", to run unmodified with the m4gskssl module.
   This requires the file, c:\mycert.pem, to have been imported into the 
   certificate store, as described in Example 1 of Step 4.

5) The IBM Key Management tool, iKeyman, can be used to visually inspect and
   update the certificate store from a graphical user interface.
   
   For example on Windows:
   %DTXHOME%\java\bin\ikeyman

   In the iKeyman tool, the ITX certificate store can be opened by pressing
   "Ctrl-O", entering the "wtx_keys.p12" file name and selecting "PKCS12" as
   the key database type.  When prompted, enter the appropriate password,
   which is "changeit" by default.
   
==============================================================================
7. ITX Configuration
==============================================================================

ITX SSL/TLS configuration options are specifed in the dtx.ini file and on the
ITX adapter command line.

Before running the FTP/HTTP adapters, apply global updates in the "SSL_CLIENT"
section of the dtx.ini file.
   
1) Set any mandatory security levels with the "secure_mode" entry.

   If a NIST compliant mode is necessary, set the "secure_mode" setting in the
   dtx.ini file accordingly.
   
   By default, the m4gskssl module will negotiate the highest security protocol
   that is acceptable to its peer and to any command line "-SPROTO" protocol
   settings.
   
2) Define the certificate store location with the "key_store" entry.

   Update the "key_store" and "key_stash" entries in the dtx.ini file.
   The key_stash file enables the key_store password to be automatically
   recovered during ITX execution.
   
   By default, the key_store and key_stash is loaded from the ITX installation
   directory.  On UNIX systems, the "config" sub-directory is used.
   
3) Set the authentication setting with the "authentication" entry.

   For added security, set the "authentication" entry to "on".  This ensures
   that the SSL peer's certificate is validated against the known set of
   trusted certificate authorities located in the keystore database.
   
   Only set this to "on" if you were able to import the external certificate
   authority, as in Example 2 of Step 4, or if the peer's certificate was
   issued by a CA that was populated in Step 3.

4) HTTP/FTP Adapters ONLY - Set a default certificate (if necessary)

   HTTP and FTP SSL operations do NOT require a certificate to be defined,
   unless the SSL peer requires it.
   
   If the SSL-based peer or adapter requires the use of a certificate,
   update the "cert_label" and "cert_label_global" entries to define a default
   certificate.  This will avoid having to make adapter command line changes.
   
   If more than one certificate is defined in the maps, then the label of the
   certificate in the keystore can be made to match the "-CERT" command line 
   value.
   
   For existing maps that have already defined multiple PEM-based certificates,
   define labels in the certificate store that match the command line's "-CERT"
   value.  In this way, map changes can be avoided.

5) Edit the map and specify the appropriate value for the "-URL" adapter
   command line option, which is required for connecting to the target server.

==============================================================================
8. ITX Execution
==============================================================================

1) Compile the maps.

        Map 1: ftpsput_no_cert
        
        This map represents a simple FTP/S operation that would easily execute
        from an existing map without any need to import a certificate.
        
        If a certificate was required by the peer, then simply modify the
        "cert_label" entry in the dtx.ini file to refer to "my_client".  This 
        will enable this map to use a default certificate without requiring
        map modification.
        
        Map 2: ftpsput_with_pem
        
        This map represents an older FTP/S command line that requires the
        PEM-based certificate to be imported into the certificate store, as
        described in Step 4.  Also the label would need to reflect the 
        exact file name, which is done in Step 6.4.
        
        Once imported, the map would execute under the m4gskssl module without
        the need for modification or recompilation.

2) Run the maps.  

3) Examine the generated adapter log files for execution details.

==============================================================================
                             END OF FILE
==============================================================================
